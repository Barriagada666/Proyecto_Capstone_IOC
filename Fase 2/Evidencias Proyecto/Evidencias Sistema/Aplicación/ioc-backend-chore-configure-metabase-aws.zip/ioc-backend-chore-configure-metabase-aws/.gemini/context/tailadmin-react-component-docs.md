
# Documentación de Componentes de React - TailAdmin

TailAdmin React proporciona un conjunto de componentes totalmente responsivos para agilizar tu proceso de desarrollo. Estos componentes están construidos con la flexibilidad en mente, permitiéndote personalizarlos para que se ajusten a las necesidades de tu proyecto mientras se mantiene el rendimiento y la usabilidad.

Para usar un componente, impórtalo como se muestra en los ejemplos:
`import ComponentName from "../components/ComponentName";`

---
## Directiva para Colaboración de IA: Sistema de Diseño TailAdmin

**Mandato:** Este documento es tu **fuente de verdad única y obligatoria** para toda la construcción de interfaces de usuario (UI) en el proyecto IOC. No debes usar, inventar ni sugerir componentes o estilos que no estén definidos aquí, a menos que se te solicite explícitamente como una nueva tarea de desarrollo.

**Objetivo:** Garantizar la uniformidad visual, la coherencia en la interacción y la mantenibilidad del frontend, utilizando exclusivamente la biblioteca de componentes predefinida de TailAdmin.

### Protocolo Obligatorio para Tareas de UI/UX

Para cualquier tarea que implique diseñar o implementar una interfaz de usuario, debes seguir rigurosamente los siguientes pasos:

1.  **[CONSULTAR]:** Antes de proponer cualquier diseño o escribir cualquier código, debes consultar este documento para identificar los componentes de TailAdmin más adecuados para cumplir con los requisitos de la tarea.

2.  **[PLANIFICAR]:** En tu fase de planificación (`[RAZONAR]`), debes nombrar explícitamente los componentes que utilizarás. Tu plan debe ser verificable contra este documento.
    *   **Ejemplo de Plan Correcto:** *"Para la vista 'Gestión de Usuarios', mi plan es usar los siguientes componentes: `<Table>` para listar los usuarios, `<Button>` para las acciones, `<Modal>` para el formulario de creación y `<PaginationWithText>` para la paginación."*
    *   **Ejemplo de Plan Incorrecto:** *"Voy a crear una tabla para los usuarios."*

3.  **[IMPLEMENTAR]:** Al generar el código (`[ACTUAR]`), debes utilizar las rutas de importación y las `props` exactas como se ejemplifica en la documentación de cada componente a continuación.

**Prohibición de Componentes Ad-Hoc:** La creación de componentes personalizados desde cero está prohibida a menos que sea el objetivo explícito de una historia de usuario. Siempre debes priorizar la composición de los componentes existentes en este documento para resolver un problema de diseño.
---
---

## Alert
Las alertas se utilizan para proporcionar mensajes de retroalimentación a los usuarios.

### Importación
```jsx
import Alert from "../../components/ui/alert/Alert";
```

### Ejemplos de Uso
```jsx
<Alert
  variant="success"
  title="Success Message"
  message="Be cautious when performing this action."
  showLink={true}
  linkHref="/"
  linkText="Learn more"
/>

<Alert
  variant="success"
  title="Success Message"
  message="Be cautious when performing this action."
  showLink={false}
/>
```

---

## Avatar
Los avatares se utilizan para mostrar la imagen de perfil o las iniciales de un usuario.

### Importación
```jsx
import Avatar from "../../components/ui/avatar/Avatar";
```

### Ejemplos de Uso
```jsx
<Avatar src="/images/user/user-01.jpg" size="xsmall" />
<Avatar src="/images/user/user-01.jpg" size="small" />
<Avatar src="/images/user/user-01.jpg" size="medium" />
<Avatar src="/images/user/user-01.jpg" size="large" />
<Avatar src="/images/user/user-01.jpg" size="xlarge" />
<Avatar src="/images/user/user-01.jpg" size="xxlarge" />
```

---

## Badge
Los badges se utilizan para mostrar pequeños indicadores de estado, conteos o etiquetas.

### Importación
```jsx
import Badge from "../../components/ui/badge/Badge";
```

### Ejemplos de Uso
```jsx
<Badge variant="light" color="primary">Primary</Badge>
<Badge variant="light" color="success">Success</Badge>
<Badge variant="light" color="error">Error</Badge>
<Badge variant="light" color="warning">Warning</Badge>
<Badge variant="light" color="info">Info</Badge>
<Badge variant="light" color="light">Light</Badge>
<Badge variant="light" color="dark">Dark</Badge>
```

---

## Breadcrumb
Los breadcrumbs se utilizan para mostrar rutas de navegación y ayudar a los usuarios a rastrear su ubicación dentro de un sitio web.

### Importación
```jsx
import Breadcrumb from "./Breadcrumb";
```

### Ejemplo de Uso
```jsx
const twoLayerItems = [{ label: "Home", href: "/" }, { label: "UI Kits" }];

const threeLayerItems = [
  { label: "Home", href: "/" },
  { label: "UI Kits", href: "/ui-kits" },
  { label: "Avatar" },
];

<div>
  <Breadcrumb items={twoLayerItems} />
  <Breadcrumb items={threeLayerItems} />
</div>;
```

---

## Button
Los botones se utilizan para desencadenar acciones, enviar formularios o navegar dentro de la aplicación.

### Ejemplo de Uso
```jsx
<Button size="sm" variant="primary">
  Button Text
</Button>

<Button size="md" variant="primary">
  Button Text
</Button>
```

---

## Button Group
Los grupos de botones se utilizan para agrupar acciones relacionadas para una mejor organización e interacción del usuario.

### Ejemplo de Uso
```jsx
<div className="shadow-theme-xs inline-flex items-center">
  <button
    type="button"
    className="bg-brand-500 ring-brand-500 hover:bg-brand-500 inline-flex items-center gap-2 px-4 py-3 text-sm font-medium text-white ring-1 ring-inset transition first:rounded-l-lg last:rounded-r-lg"
  >
    Button Text
  </button>
  <button
    type="button"
    className="text-brand-500 ring-brand-500 hover:bg-brand-500 -ml-px inline-flex items-center gap-2 bg-transparent px-4 py-3 text-sm font-medium ring-1 ring-inset first:rounded-l-lg last:rounded-r-lg hover:text-white"
  >
    Button Text
  </button>
  <button
    type="button"
    className="text-brand-500 ring-brand-500 hover:bg-brand-500 -ml-px inline-flex items-center gap-2 bg-transparent px-4 py-3 text-sm font-medium ring-1 ring-inset first:rounded-l-lg last:rounded-r-lg hover:text-white"
  >
    Button Text
  </button>
</div>
```

---

## Card
Las tarjetas se utilizan para mostrar contenido y acciones relacionadas con un solo tema de una manera estructurada y visualmente atractiva.

### Ejemplo de Uso
```jsx
<div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
  <CardWithImage />
  <CardWithImage />
  <CardWithImage />
</div>
```

---

## Carousel
Los carruseles se utilizan para mostrar múltiples piezas de contenido en un formato deslizante e interactivo.

### Ejemplo de Uso
```jsx
"use client";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";
import Image from "next/image";

const carouselData = [
  { thumbnail: "/images/carousel/carousel-01.png" },
  // ... resto de los datos
];

export default function SlideOnly() {
  const swiperOptions = {
    modules: [Autoplay],
    autoplay: {
      delay: 5000,
      disableOnInteraction: false,
    },
  };

  return (
    <div className="carouselOne rounded-lg border border-gray-200 dark:border-gray-800">
      <Swiper {...swiperOptions}>
        {carouselData.map((item, i) => (
          <SwiperSlide key={i + 1}>
            <div className="overflow-hidden rounded-lg">
              <Image
                width={487}
                height={297}
                src={item.thumbnail}
                className="w-full rounded-lg"
                alt="carousel"
              />
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}
```

---

## Dropdown
Los menús desplegables se utilizan para mostrar una lista de opciones o acciones en un menú compacto e interactivo.

### Ejemplo de Uso
```jsx
const [isOpen, setIsOpen] = useState(false);

function toggleDropdown() {
  setIsOpen(!isOpen);
}

function closeDropdown() {
  setIsOpen(false);
}

<div className="relative inline-block">
  <Button size="md" onClick={toggleDropdown}>
    Account Menu
    <ChevronDownIcon />
  </Button>
  <Dropdown isOpen={isOpen} onClose={closeDropdown} className="w-40 p-2">
    <DropdownItem
      onItemClick={closeDropdown}
      className="flex w-full rounded-lg text-left font-normal text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-300"
    ></DropdownItem>
    <DropdownItem onItemClick={closeDropdown} className="hover:bg-blue-50">
      Edit Profile
    </DropdownItem>
  </Dropdown>
</div>;
```

---

## Images
Las imágenes se utilizan para mostrar contenido visual, mejorar la experiencia del usuario y comunicar información de manera efectiva.

### Ejemplos de Uso
```jsx
<ResponsiveImage />
<TwoColumnImageGrid />
<ThreeColumnImageGrid />
```

---

## Links
Los enlaces personalizados se utilizan para navegar entre páginas o realizar acciones permitiendo estilos y comportamientos personalizados.

### Ejemplo de Uso
```jsx
<CustomLink href="/" variant="colored" color="primary">Primary link</CustomLink>
<CustomLink href="/" variant="colored" color="secondary">Secondary link</CustomLink>
<CustomLink href="/" variant="colored" color="success">Success link</CustomLink>
<CustomLink href="/" variant="colored" color="danger">Danger link</CustomLink>
<CustomLink href="/" variant="colored" color="warning">Warning link</CustomLink>
<CustomLink href="/" variant="colored" color="info">Info link</CustomLink>
<CustomLink href="/" variant="colored" color="light">Light link</CustomLink>
<CustomLink href="/" variant="colored" color="dark">Dark link</CustomLink>
```

---

## List
Componentes para mostrar listas ordenadas y no ordenadas.

### Ejemplos de Uso
```jsx
<UnOrderedList />
<OrderedList />
```

---

## Modal
Los modales se utilizan para mostrar contenido o acciones en una superposición emergente, generalmente para una interacción de usuario enfocada sin navegar fuera de la página actual.

### Ejemplos de Uso```jsx
<DefaultModal />
<ModalBasedAlerts />
```

---

## Notification
Las notificaciones se utilizan para alertar a los usuarios sobre actualizaciones, eventos o acciones importantes en la aplicación.

### Ejemplo de Uso
```jsx
<UpdateNotification
  title="New update! Available"
  message="Enjoy improved functionality and enhancements."
  onLaterClick={handleLater}
  onUpdateClick={handleUpdate}
/>
```

---

## ProgressBar
Las barras de progreso se utilizan para indicar visualmente el estado de finalización de una tarea o proceso.

### Ejemplos de Uso
```jsx
<ProgressBar progress={55} />
<ProgressBar progress={85} />
<ProgressBar progress={35} />
```

---

## Pagination
La paginación se utiliza para dividir el contenido en páginas separadas, permitiendo a los usuarios navegar a través de grandes conjuntos de datos o listas de manera eficiente.

### Ejemplo de Uso
```jsx
<PaginationWithText
  totalPages={10}
  initialPage={1}
  onPageChange={handlePageChange}
/>
```

---

## Popover
El componente Popover muestra contenido flotante junto a un elemento disparador. Es útil para mostrar información adicional o controles sin saturar la interfaz principal.

### Ejemplo de Uso
```jsx
<Popover position="top" trigger={<Button size="sm"> Popover on Top</Button>}>
  <div className="relative rounded-t-xl border-b border-gray-200 bg-gray-100 px-5 py-3 dark:border-white/[0.03] dark:bg-[#252D3A]">
    <h3 className="text-base font-semibold text-gray-800 dark:text-white/90">
      Top Popover
    </h3>
  </div>
  <div className="p-5">
    <p className="text-sm text-gray-500 dark:text-gray-400">
      Lorem ipsum dolor sit amet, consect adipiscing elit. Mauris facilisis
      congue exclamate justo nec facilisis.
    </p>
  </div>
</Popover>
```

---

## Ribbons
Las cintas se utilizan para resaltar o etiquetar contenido con una etiqueta decorativa o que llame la atención, a menudo indicando un estado o importancia especial.

### Ejemplo de Uso```jsx
<RoundedRibbon />
```

---

## Spinner
Los spinners se utilizan para indicar que un proceso está en curso o que el contenido se está cargando, proporcionando retroalimentación visual a los usuarios.

### Ejemplo de Uso
```jsx
<SpinnerOne />
```

---

## Table
El componente de tabla se utiliza para mostrar datos en un formato tabular estructurado con filas, columnas y estilos personalizables.

### Importación
```jsx
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableCell,
} from "./TableComponents";
```

### Ejemplo de Uso
```jsx
export default function TableExample() {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableCell isHeader>Header 1</TableCell>
          <TableCell isHeader>Header 2</TableCell>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow>
          <TableCell>Data 1</TableCell>
          <TableCell>Data 2</TableCell>
        </TableRow>
        <TableRow>
          <TableCell>Data 3</TableCell>
          <TableCell>Data 4</TableCell>
        </TableRow>
      </TableBody>
    </Table>
  );
}
```

---

## Tabs
Las pestañas se utilizan para organizar el contenido en secciones separadas, permitiendo a los usuarios cambiar entre diferentes vistas o categorías sin problemas.

### Ejemplo de Uso
```jsx
<DefaultTab />
```

---

## Tooltips
Los tooltips se utilizan para proporcionar información adicional o sugerencias cuando un usuario pasa el cursor sobre un elemento o interactúa con él.

### Ejemplo de Uso
```jsx
<Tooltip content="This is a top tooltip" position="top">
  <Button size="sm">Tooltip Top</Button>
</Tooltip>

<Tooltip content="This is a right tooltip" position="right">
  <Button size="sm">Tooltip Right</Button>
</Tooltip>

<Tooltip content="This is a bottom tooltip" position="bottom">
  <Button size="sm">Tooltip Bottom</Button>
</Tooltip>

<Tooltip content="This is a left tooltip" position="left">
  <Button size="sm">Tooltip Left</Button>
</Tooltip>
```

---

## Videos
Los componentes de video se utilizan para incrustar y mostrar contenido de video, permitiendo a los usuarios ver multimedia dentro de la aplicación.

### Ejemplo de Uso
```jsx
<YouTubeEmbed videoId="dQw4w9WgXcQ" />
<YouTubeEmbed videoId="dQw4w9WgXcQ" aspectRatio="4:3" />
```
