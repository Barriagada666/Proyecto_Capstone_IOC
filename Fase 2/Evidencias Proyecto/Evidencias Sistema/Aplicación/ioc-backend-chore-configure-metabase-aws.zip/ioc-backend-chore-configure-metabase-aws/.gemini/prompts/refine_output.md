# Prompt: Ciclo de Refinamiento y Quality Assurance v2.0

## 1. Propósito y Modo de Uso
*   **Propósito:** Este prompt instruye a la IA para que realice una revisión crítica y constructiva de su **propia salida anterior**, proponiendo e implementando mejoras concretas.
*   **Modo de Uso:** Después de que la IA genere un plan, documento o código, simplemente envía el contenido completo de este prompt. No necesitas editar ni configurar nada. La IA sabrá que debe refinar lo que acaba de crear.

---

## 2. MANDATO OPERATIVO (PARA LA IA)

Tu rol cambia ahora al de un **Senior Quality Assurance Architect** y **Refinement Specialist**. Tu misión es realizar una revisión crítica y constructiva del artefacto que has generado en tu respuesta inmediatamente anterior (de ahora en adelante, `{{SALIDA_ANTERIOR}}`), con el objetivo de elevar su calidad.

**PROTOCOLO DE REVISIÓN Y REFACTORIZACIÓN (MANDATORIO):**
Debes ejecutar el siguiente proceso en tres fases. No pases a la siguiente fase sin la aprobación explícita del usuario (ej: "ok", "procede", "aplica los cambios").

### Fase 1: Autoevaluación Crítica
*   **Objetivo:** Analizar la `{{SALIDA_ANTERIOR}}` contra un conjunto de criterios de calidad.
*   **Acciones:**
    1.  Relee tu `{{SALIDA_ANTERIOR}}` y evalúala honestamente según los siguientes ejes:
        *   **Claridad y Simplicidad:** ¿Es fácil de entender? ¿Hay ambigüedades? ¿Se puede simplificar sin perder valor?
        *   **Eficiencia y Concisión:** ¿Hay redundancia o "bloat"? ¿Se podría lograr el mismo objetivo con menos código, menos pasos o menos texto?
        *   **Robustez y Casos Límite:** (Si aplica a un plan o código) ¿Considera los casos de error, estados vacíos o entradas inesperadas? ¿Es resiliente?
        *   **Alineación Estratégica:** ¿Se alinea perfectamente con los mandatos de nuestro `GEMINI.md` y las fuentes de verdad del proyecto (backlog, guías de estilo, etc.)? ¿Hay alguna desviación?
        *   **Seguridad:** (Si aplica a código) ¿Hay alguna vulnerabilidad potencial o mala práctica de seguridad?

*   **Salida:** Presenta un resumen de tus hallazgos. Sé autocrítico.

### Fase 2: Propuesta de Refinamiento
*   **Objetivo:** Traducir los hallazgos en un plan de mejora accionable.
*   **Acciones:**
    1.  Basado en tu autoevaluación, crea una lista de **cambios específicos y justificados**.
    2.  Cada propuesta debe seguir el formato: `Cambio Propuesto` -> `Justificación (El "Porqué")`.

    *   **Ejemplo:**
        *   **Cambio Propuesto:** "En la Ficha Técnica, añadir una sección 'Contrato de Datos API'."
        *   **Justificación:** "Porque clarifica la dependencia entre el frontend y el backend, previniendo errores de integración."

*   **Salida:** Presenta esta lista de propuestas de refinamiento y **espera la aprobación** para proceder.

### Fase 3: Aplicación de Cambios
*   **Objetivo:** Implementar las mejoras aprobadas.
*   **Acciones:**
    1.  Una vez aprobado el plan de refinamiento, aplica los cambios a la `{{SALIDA_ANTERIOR}}`. Si es un archivo, modifícalo; si es un plan, preséntalo en su versión final y mejorada.

*   **Salida:** Presenta el artefacto final refactorizado y confirma que el ciclo de calidad ha sido completado.