# Diseño de la Vista de Administrador - Plataforma IOC (v3)

## 1. Racional de Diseño (Design Rationale)
El diseño se basa en el principio de **flujo de trabajo guiado**, estructurando la interfaz para reflejar el ciclo de vida de los datos en la plataforma: desde su origen hasta su consumo. La navegación principal aísla las tres responsabilidades clave del administrador:

1.  **Ingesta de Datos:** Gestionar la entrada de datos brutos.
2.  **Contenido Analítico:** Transformar esos datos en información visual (gráficos, KPIs).
3.  **Acceso y Seguridad:** Controlar quién puede acceder a esa información.

Esta separación no solo simplifica el modelo mental, sino que también crea un camino lógico que reduce la carga cognitiva, permitiendo al administrador enfocarse en una tarea a la vez (cargar, configurar o administrar) de manera eficiente.

## 2. Estructura de Navegación Propuesta (Menú Lateral)
*   **Panel Principal (Dashboard):** Vista de bienvenida con un resumen del estado del sistema: estado de la última carga de datos, número de usuarios activos y alertas de KPIs. Incluye accesos directos a las tareas más comunes.
*   **Ingesta de Datos:** Módulo dedicado a la carga, validación y monitorización de los archivos de producción CSV. Es el punto de entrada de toda la información.
*   **Contenido Analítico:** Suite de herramientas para la creación y gestión de todos los artefactos de BI. Aquí es donde los datos se convierten en conocimiento.
*   **Acceso y Seguridad:** Centro de control para la administración del ciclo de vida de los usuarios, sus roles y los permisos asociados.

---

## 3. Detalle de Secciones y Componentes

### 3.1 Sección: Ingesta de Datos
*   **Propósito:** Ofrecer un punto único y claro para la carga de datos, con feedback inmediato sobre la validez y el estado del proceso.
*   **Historias de Usuario Cubiertas:** `IOC-001`
*   **Funcionalidades y Componentes Clave Sugeridos (Frontend):**
    *   **Vista Principal: Carga de Archivos**
        *   `DataUploadDropzone`: Un componente `Dropzone` prominente para la selección de archivos CSV.
        *   `UploadStatusIndicator`: Un área de feedback que muestra el progreso (`ProgressBar`), el éxito (`Alert variant="success"`) o el detalle del error (`Alert variant="error"`).
    *   **Vista Secundaria: Historial de Cargas (Sugerencia)**
        *   `UploadHistoryTable`: Una tabla con el historial de cargas, mostrando fecha, usuario, estado y un botón "Ver Detalles" que abre un modal.
        *   `ErrorLogModal`: Un `Modal` que muestra un desglose detallado de los errores de validación por fila para una carga fallida.

### 3.2 Sección: Contenido Analítico
*   **Propósito:** Centralizar la creación y gestión de todos los elementos visuales, permitiendo al administrador construir y mantener la experiencia de BI de los usuarios finales.
*   **Historias de Usuario Cubiertas:** `IOC-019a`, `IOC-019b`, `IOC-020a`, `IOC-020b`, `IOC-002a`, `IOC-002b`, `IOC-002c`
*   **Funcionalidades y Componentes Clave Sugeridos (Frontend):**
    *   **Sub-sección: Diseño de Dashboards (Pestaña Principal):**
        *   `DashboardSelector`: Un `Dropdown` para seleccionar el dashboard a editar.
        *   `DashboardLayoutEditor`: Un lienzo interactivo con `react-dnd` que muestra la disposición actual de los gráficos.
        *   `AvailableChartsPanel`: Un panel lateral que lista los gráficos (desde `ChartsDataTable`) disponibles para ser arrastrados al lienzo.
    *   **Sub-sección: Gestión de Gráficos (Pestaña Secundaria):**
        *   `ChartsDataTable`: Una tabla paginada con todos los gráficos, incluyendo un campo de búsqueda y botones para "Editar", "Eliminar" y "Duplicar".
        *   `ChartBuilderModal`: Un `Modal` con un formulario multi-paso para la creación/edición de gráficos, con previsualización en tiempo real.
    *   **Sub-sección: Gestión de KPIs (Pestaña Terciaria):**
        *   `KpiSettingsTable`: Una tabla con los KPIs, un `Switch` para activar/desactivar alertas y un `Input` para el umbral.

### 3.3 Sección: Acceso y Seguridad
*   **Propósito:** Administrar de forma segura y granular el ciclo de vida de los usuarios y sus permisos.
*   **Historias de Usuario Cubiertas:** `IOC-003a` a `IOC-003g`
*   **Funcionalidades y Componentes Clave Sugeridos (Frontend):**
    *   **Sub-sección: Gestión de Usuarios (Pestaña Principal):**
        *   `UsersDataTable`: Una tabla paginada con búsqueda y filtros por rol.
        *   `UserCreateModal`: Un `Modal` con el formulario para crear nuevos usuarios.
        *   `UserActionsDropdown`: Un `Dropdown` en cada fila de la tabla con opciones para "Editar Rol" y "Eliminar Usuario".
    *   **Sub-sección: Gestión de Roles y Permisos (Pestaña Secundaria):**
        *   `RolesTable`: Una tabla con los roles y un botón "Editar Permisos" que abre un modal.
        *   `PermissionsMatrixModal`: Un `Modal` que contiene una matriz visual de `Checkbox` (permisos vs. rol) para una asignación clara y sin ambigüedades.

---

## 4. Oportunidades de Mejora Identificadas (Gap Analysis)
*   **Búsqueda y Filtrado Global:** Implementar un campo de búsqueda en la cabecera de cada tabla (`UsersDataTable`, `ChartsDataTable`, `KpiSettingsTable`) es una mejora de usabilidad crítica y de bajo costo.
*   **Acciones en Lote (Bulk Actions):** En la tabla de usuarios, permitir acciones en lote como "Asignar Rol a Seleccionados" o "Eliminar Seleccionados" (con doble confirmación) mejoraría drásticamente la eficiencia para administradores con muchos usuarios.
*   **Plantillas de Dashboards:** Añadir una funcionalidad "Guardar como Plantilla" en el `DashboardLayoutEditor`. Esto permitiría a los administradores crear nuevas configuraciones de dashboards a partir de diseños preexistentes, acelerando la creación de nuevas vistas.
