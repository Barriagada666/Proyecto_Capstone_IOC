// src/components/FileValidationResult.tsx
import React from 'react';
import type { ValidationResult, ValidationError } from '../types/file-validation.types';
import Button from './ui/button/Button'; // Asumiendo que tienes un componente Button

export interface FileValidationResultProps {
  result: ValidationResult;
  onConfirm?: () => void;
  onCancel?: () => void;
  className?: string;
  showButtons?: boolean;
}

// Helper para traducir mensajes (versión simplificada)
function translateMessage(issue: ValidationError): string {
  // En una app real, esto usaría una librería como i18next
  switch (issue.code) {
    case 'INVALID_EXTENSION': return `Extensión no válida. Se esperaba: ${issue.details}`;
    case 'FILE_TOO_LARGE': return `El archivo es demasiado grande. Máximo: ${issue.details}`;
    case 'FILE_EMPTY': return 'El archivo no puede estar vacío.';
    case 'HEADER_MISMATCH': return `El número de columnas no coincide. ${issue.details}`;
    case 'MISSING_COLUMNS': return `Faltan columnas requeridas: ${issue.details}`;
    case 'REQUIRED_FIELD_EMPTY': return `Línea ${issue.details}: El campo requerido está vacío.`;
    case 'INVALID_NUMERIC': return `Línea ${issue.details}: El valor no es un número válido.`;
    case 'INVALID_DATE': return `Línea ${issue.details}: El formato de fecha es incorrecto.`;
    default: return issue.message;
  }
}

// Componente auxiliar para mostrar un error o advertencia
const IssueItem: React.FC<{ issue: ValidationError }> = ({ issue }) => {
  const isError = issue.severity === 'ERROR';
  const theme = {
    bgColor: isError ? 'bg-red-50 dark:bg-red-900/20' : 'bg-yellow-50 dark:bg-yellow-900/20',
    borderColor: isError ? 'border-red-200 dark:border-red-800' : 'border-yellow-300 dark:border-yellow-700',
    textColor: isError ? 'text-red-800 dark:text-red-300' : 'text-yellow-800 dark:text-yellow-300',
    icon: isError ? '❌' : '⚠️',
  };

  return (
    <div className={`${theme.bgColor} border ${theme.borderColor} rounded p-3`}>
      <div className={`flex items-start ${theme.textColor}`}>
        <span className="text-lg mr-2 mt-0.5">{theme.icon}</span>
        <div className="flex-1">
          <div className="font-medium">{translateMessage(issue)}</div>
          {issue.details && <div className="text-sm mt-1 opacity-80">{issue.details}</div>}
        </div>
      </div>
    </div>
  );
};

// Componente auxiliar para el resumen
const SummaryItem: React.FC<{ label: string; value: string; isValid: boolean }> = ({ label, value, isValid }) => (
  <div className="flex items-center text-sm">
    <span className="text-lg mr-2">{isValid ? '✅' : '❌'}</span>
    <span className={isValid ? 'text-gray-700 dark:text-gray-300' : 'text-red-700 dark:text-red-300'}>
      <span className="font-medium">{label}:</span> {value}
    </span>
  </div>
);

export const FileValidationResult: React.FC<FileValidationResultProps> = ({
  result,
  onConfirm,
  onCancel,
  className = '',
  showButtons = true
}) => {
  const { isValid, errors, warnings, summary } = result;

  const theme = {
    bgColor: isValid ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20',
    borderColor: isValid ? 'border-green-200 dark:border-green-800' : 'border-red-200 dark:border-red-800',
    textColor: isValid ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300',
    icon: isValid ? '✅' : '❌',
  };

  return (
    <div className={`border rounded-lg ${theme.borderColor} ${className}`} role="region" aria-label="Resultado de validación">
      <div className={`${theme.bgColor} px-4 py-3 border-b ${theme.borderColor}`}>
        <div className={`flex items-center ${theme.textColor} font-medium text-lg`}>
          <span className="text-2xl mr-2">{theme.icon}</span>
          <span>{isValid ? 'Archivo válido y listo para subir' : 'Archivo con errores - No se puede subir'}</span>
        </div>
      </div>

      <div className="p-4 space-y-2 bg-white dark:bg-gray-900">
        <SummaryItem label="Extensión" value={summary?.fileName?.split('.').pop() || 'N/A'} isValid={!errors.some(e => e.code === 'INVALID_EXTENSION')} />
        <SummaryItem label="Tamaño" value={`${summary?.fileSizeMb?.toFixed(2) || 0} MB`} isValid={!errors.some(e => e.code === 'FILE_TOO_LARGE')} />
        <SummaryItem label="Codificación" value={summary?.encoding || 'N/A'} isValid={true} />
        <SummaryItem label="Encabezados" value={`${summary?.headers?.length || 0} columnas`} isValid={!errors.some(e => e.code === 'HEADER_MISMATCH' || e.code === 'MISSING_COLUMNS')} />
        <SummaryItem label="Datos de Muestra" value={`${errors.filter(e => e.code !== 'INTERNAL_ERROR').length} errores encontrados`} isValid={errors.length === 0} />
      </div>

      {(errors.length > 0 || warnings.length > 0) && (
        <div className="p-4 bg-white dark:bg-gray-900 border-t dark:border-gray-700">
          {errors.length > 0 && (
            <div>
              <h3 className="font-medium text-red-800 dark:text-red-300 mb-3">Errores Detectados ({errors.length})</h3>
              <div className="space-y-3">
                {errors.map((error, index) => <IssueItem key={`err-${index}`} issue={error} />)}
              </div>
            </div>
          )}
          {warnings.length > 0 && (
            <div className="mt-4">
              <h3 className="font-medium text-yellow-800 dark:text-yellow-300 mb-3">Advertencias ({warnings.length})</h3>
              <div className="space-y-3">
                {warnings.map((warning, index) => <IssueItem key={`warn-${index}`} issue={warning} />)}
              </div>
            </div>
          )}
        </div>
      )}

      {showButtons && (
        <div className="px-4 py-3 bg-gray-50 dark:bg-gray-800 border-t dark:border-gray-700 flex gap-3">
          {isValid ? (
            <>
              <Button onClick={onConfirm} variant="primary" className="flex-1">Confirmar y Subir</Button>
              <Button onClick={onCancel} variant="secondary">Cancelar</Button>
            </>
          ) : (
            <Button onClick={onCancel} variant="secondary" className="flex-1">Seleccionar otro archivo</Button>
          )}
        </div>
      )}
    </div>
  );
};
