import React from 'react';

interface QuickAccessButtonProps {
  title: string;
  icon: React.ReactNode;
  onClick: () => void;
  "data-testid"?: string;
}

const QuickAccessButton: React.FC<QuickAccessButtonProps> = ({ title, icon, onClick, "data-testid": dataTestId }) => {
  return (
    <button
      onClick={onClick}
      data-testid={dataTestId}
      className="flex flex-col items-center justify-center w-full h-32 gap-2 transition-colors border border-gray-200 rounded-2xl bg-gray-50 hover:bg-gray-100 dark:bg-white/[0.03] dark:border-gray-800 dark:hover:bg-white/5"
    >
      <div className="text-brand-500">{icon}</div>
      <span className="font-medium text-gray-800 dark:text-white/90">{title}</span>
    </button>
  );
};

export default QuickAccessButton;
