const MetricCardSkeleton: React.FC = () => {
  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-gray-200 rounded-xl animate-pulse dark:bg-gray-800"></div>
        <div className="w-full space-y-2">
          <div className="h-4 bg-gray-200 rounded w-3/4 animate-pulse dark:bg-gray-800"></div>
          <div className="h-6 bg-gray-200 rounded w-1/2 animate-pulse dark:bg-gray-800"></div>
        </div>
      </div>
    </div>
  );
};

export default MetricCardSkeleton;
