import React from 'react';
import Button from '../ui/button/Button';

interface EmptyStateProps {
  title: string;
  message: string;
  actionText?: string;
  onAction?: () => void;
}

const EmptyState: React.FC<EmptyStateProps> = ({ title, message, actionText, onAction }) => {
  return (
    <div className="text-center py-10 px-6 border-2 border-dashed border-gray-200 dark:border-gray-800 rounded-2xl">
      <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">{title}</h3>
      <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">{message}</p>
      {actionText && onAction && (
        <div className="mt-6">
          <Button onClick={onAction} size="sm">
            {actionText}
          </Button>
        </div>
      )}
    </div>
  );
};

export default EmptyState;
