import React from 'react';

const Spinner: React.FC = () => {
  return (
    <div
      className="h-8 w-8 animate-spin rounded-full border-4 border-solid border-brand-500 border-t-transparent"
      data-testid="spinner"
    ></div>
  );
};

export default Spinner;
