// src/components/admin/DataUploadDropzone.tsx
import { useState, useEffect, useRef } from 'react';
import { useDropzone } from 'react-dropzone';
import toast from 'react-hot-toast';
import { useFileValidation, ValidationState } from '../../hooks/useFileValidation';
import { FilePreview } from '../FilePreview';
import { FileValidationResult } from '../FileValidationResult';
import { DEFAULT_FILE_VALIDATION_CONFIG } from '../../services/FileValidator';
import { BoxIconLine } from '../../icons';
import Spinner from '../ui/Spinner';
import type { FileRejection } from 'react-dropzone';

interface DataUploadDropzoneProps {
  onFileSelect: (file: File) => Promise<boolean>;
  isUploading: boolean;
  maxSize?: number;
  "data-testid"?: string;
}

export function DataUploadDropzone({
  onFileSelect,
  isUploading,
  maxSize,
  "data-testid": dataTestId
}: DataUploadDropzoneProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [localError, setLocalError] = useState<string | null>(null);
  const [isUploadSuccess, setIsUploadSuccess] = useState(false);
  const localErrorTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (localErrorTimerRef.current) {
        clearTimeout(localErrorTimerRef.current);
      }
    };
  }, []);

  const showError = (message: string, duration = 4000) => {
    // Best-effort toast (may be flaky on some setups)
    try {
      toast.error(message, { duration });
    } catch { /* noop */ }

    // Always show local floating alert (authoritative UX)
    setLocalError(message);
    if (localErrorTimerRef.current) clearTimeout(localErrorTimerRef.current);
    localErrorTimerRef.current = window.setTimeout(() => {
      setLocalError(null);
      localErrorTimerRef.current = null;
    }, duration);
  };

  const {
    state: validationState,
    result: validationResult,
    isValidating,
    validate,
    reset: resetValidation,
  } = useFileValidation({
    maxSizeMb: DEFAULT_FILE_VALIDATION_CONFIG.maxSizeMb,
    allowedExtensions: DEFAULT_FILE_VALIDATION_CONFIG.allowedExtensions,
    delimiter: DEFAULT_FILE_VALIDATION_CONFIG.delimiter,
    expectedHeaders: DEFAULT_FILE_VALIDATION_CONFIG.expectedHeaders,
  });

  const maxSizeBytes = typeof maxSize === 'number' ? maxSize : DEFAULT_FILE_VALIDATION_CONFIG.maxSizeMb * 1024 * 1024;
  const maxSizeMb = Math.round(maxSizeBytes / (1024 * 1024));

  const handleDropRejected = (fileRejections: FileRejection[]) => {
    if (!fileRejections || fileRejections.length === 0) return;
    const rejection = fileRejections[0];
    const error = rejection.errors && rejection.errors[0];
    if (error && error.code === 'file-invalid-type') {
      showError('Solo se aceptan archivos .txt', 4000);
      return;
    }
    if (error && error.code === 'file-too-large') {
      showError(`El archivo es demasiado grande. El tamaño máximo es ${maxSizeMb}MB.`, 4000);
      return;
    }
    // fallback
    showError('El archivo fue rechazado.', 4000);
  };

  const handleFileDrop = async (acceptedFiles: File[], fileRejections: FileRejection[]) => {
    setIsUploadSuccess(false);
    // Primero manejar rechazos explícitos (react-dropzone)
    if (Array.isArray(fileRejections) && fileRejections.length > 0) {
      handleDropRejected(fileRejections);
      return;
    }

    const file = acceptedFiles && acceptedFiles[0];
    if (!file) return;

    // Validación manual de extensión (PRIMERO)
    if (!file.name.toLowerCase().endsWith('.txt')) {
      showError('Solo se aceptan archivos .txt', 4000);
      return;
    }

    // Validación manual de tamaño
    if (file.size > maxSizeBytes) {
      showError(`El archivo es demasiado grande. El tamaño máximo es ${maxSizeMb}MB.`, 4000);
      return;
    }

    setSelectedFile(file);
    try {
      await validate(file);
    } catch {
      showError('Error al validar el archivo.', 4000);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleFileDrop,
    onDropRejected: handleDropRejected,
    // no 'accept' to ensure files reach handlers; manual validation covers extension
    maxFiles: 1,
    disabled: isValidating || isUploading
  });
  
  const handleConfirmUpload = async () => {
    if (selectedFile && validationResult?.isValid) {
      const success = await onFileSelect(selectedFile);
      setIsUploadSuccess(!!success);
    }
  };
  
  const handleReset = () => {
    setSelectedFile(null);
    resetValidation();
    setIsUploadSuccess(false);
  };

  const showDropzone = validationState === ValidationState.IDLE;
  const showValidationInProgress = isValidating;
  const showResults = validationResult && !isValidating;

  return (
    <div className="space-y-4" data-testid={dataTestId}>
      {showDropzone && (
        <div
          {...getRootProps()}
          className={`p-5 sm:p-6 border-2 border-dashed rounded-2xl transition-colors duration-300 cursor-pointer text-center
            ${isDragActive 
              ? 'border-brand-500 bg-brand-50 dark:bg-brand-900/20' 
              : 'border-gray-300 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600 bg-gray-50 dark:bg-gray-800/20'
            }`
          }
        >
          <input {...getInputProps()} />
          <div className="flex flex-col items-center justify-center">
            <div className="flex items-center justify-center w-16 h-16 mb-4 bg-gray-100 rounded-full dark:bg-gray-800">
              <BoxIconLine className="text-gray-500 size-8 dark:text-gray-400" />
            </div>
            <h3 className="mb-2 text-lg font-semibold text-gray-800 dark:text-white/90">
              {isDragActive ? 'Suelta el archivo aquí' : 'Arrastra el reporte de producción o haz clic para seleccionar'}
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Formato requerido: .txt delimitado por pipe (|)
            </p>
          </div>
        </div>
      )}

      {showValidationInProgress && (
        <div className="flex items-center justify-center py-8 rounded-lg bg-gray-50 dark:bg-gray-800/20">
          <Spinner />
          <span className="ml-3 text-gray-600 dark:text-gray-300">
            Validando archivo...
          </span>
        </div>
      )}

      {showResults && selectedFile && (
        <div className="space-y-4">
          <FilePreview file={selectedFile} highlightLines={[4]} />
          <FileValidationResult
            result={validationResult}
            onConfirm={handleConfirmUpload}
            onCancel={handleReset}
            showButtons={!isUploading && !isUploadSuccess}
          />
        </div>
      )}
      
      {isUploading && (
        <div className="flex items-center justify-center py-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
          <Spinner />
          <span className="ml-3 text-blue-700 dark:text-blue-300">
            Subiendo y procesando archivo...
          </span>
        </div>
      )}

      {localError && (
        <div style={{ position: 'fixed', top: 16, right: 16, zIndex: 200000, minWidth: 220 }}>
          <div className="p-3 rounded-lg bg-red-600 shadow-lg text-white">
            <div className="text-sm">{localError}</div>
          </div>
        </div>
      )}
    </div>
  );
}

export default DataUploadDropzone;
