import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import toast from "react-hot-toast";
import { supabase } from "../../lib/supabaseClient";
import Label from "../form/Label";
import Input from "../form/input/InputField";
import Button from "../ui/button/Button";
import { ChevronLeftIcon } from "../../icons";

export default function UpdatePasswordForm() {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') {
        // La sesión ya está activa aquí, el usuario está autenticado temporalmente
        // para cambiar su contraseña.
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      toast.error("Las contraseñas no coinciden.");
      return;
    }
    if (password.length < 6) {
      toast.error("La contraseña debe tener al menos 6 caracteres.");
      return;
    }

    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: password });

    if (error) {
      toast.error("Error al actualizar la contraseña: " + error.message);
    } else {
      toast.success("Tu contraseña ha sido actualizada con éxito. Serás redirigido para iniciar sesión.");
      setTimeout(() => {
        navigate("/signin");
      }, 3000);
    }
    setLoading(false);
  };

  return (
    <div className="flex flex-col flex-1">
      <div className="w-full max-w-md pt-10 mx-auto">
        <Link
          to="/signin"
          className="inline-flex items-center text-sm text-gray-500 transition-colors hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
        >
          <ChevronLeftIcon className="size-5" />
          Volver a Iniciar Sesión
        </Link>
      </div>
      <div className="flex flex-col justify-center flex-1 w-full max-w-md mx-auto">
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white/90 mb-2">
            Restablecer Contraseña
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Define una nueva contraseña para acceder a tu cuenta.
          </p>
        </div>
        <div>
          <form onSubmit={handleUpdatePassword}>
            <div className="space-y-5">
              <div>
                <Label htmlFor="password">
                  Nueva Contraseña<span className="text-error-500">*</span>
                </Label>
                <Input
                  type="password"
                  id="password"
                  name="password"
                  placeholder="Ingresa tu nueva contraseña"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="confirmPassword">
                  Confirmar Nueva Contraseña<span className="text-error-500">*</span>
                </Label>
                <Input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  placeholder="Confirma tu nueva contraseña"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </div>
              <div>
                <Button className="w-full" size="sm" type="submit" disabled={loading}>
                  {loading ? "Actualizando..." : "Actualizar Contraseña"}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
