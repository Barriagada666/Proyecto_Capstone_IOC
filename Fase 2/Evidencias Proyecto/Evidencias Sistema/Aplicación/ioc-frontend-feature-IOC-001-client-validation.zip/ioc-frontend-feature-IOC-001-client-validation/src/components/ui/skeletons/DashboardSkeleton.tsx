import React from 'react';

const SkeletonCard = () => (
  <div className="p-4 bg-gray-200 rounded-lg dark:bg-gray-800 animate-pulse">
    <div className="h-6 bg-gray-300 rounded dark:bg-gray-700 w-3/4 mb-2"></div>
    <div className="h-10 bg-gray-300 rounded dark:bg-gray-700 w-1/2"></div>
  </div>
);

const SkeletonChart = () => (
  <div className="p-4 bg-gray-200 rounded-lg dark:bg-gray-800 animate-pulse">
    <div className="h-64 bg-gray-300 rounded dark:bg-gray-700"></div>
  </div>
);

const DashboardSkeleton: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div 
      className={`p-4 md:p-6 border border-gray-200 dark:border-gray-800 rounded-lg ${className}`}
    >
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <SkeletonCard />
          <SkeletonCard />
          <SkeletonCard />
          <SkeletonCard />
        </div>
        <SkeletonChart />
      </div>
    </div>
  );
};

export default DashboardSkeleton;
