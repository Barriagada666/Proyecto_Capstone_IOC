import { Modal } from '../ui/modal';
import Button from '../ui/button/Button';

interface ErrorLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  errors: string[];
  "data-testid"?: string;
}

const ErrorLogModal = ({ isOpen, onClose, errors, "data-testid": dataTestId }: ErrorLogModalProps) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} data-testid={dataTestId}>
      <div className="p-5 sm:p-6">
        <h3 className="mb-4 text-lg font-semibold text-gray-800 dark:text-white/90">
          Detalle de Errores en la Carga
        </h3>
        {errors.length > 0 ? (
          <ul className="pl-5 space-y-2 text-sm list-disc text-error-600 dark:text-error-500 max-h-64 overflow-y-auto">
            {errors.map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-gray-500 dark:text-gray-400">
            No se encontraron detalles de errores para esta carga.
          </p>
        )}
        <div className="flex justify-end mt-6">
          <Button onClick={onClose} size="sm">Cerrar</Button>
        </div>
      </div>
    </Modal>
  );
};

export default ErrorLogModal;
