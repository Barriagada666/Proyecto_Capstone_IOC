// src/components/FilePreview.tsx
import { useState, useEffect } from 'react';

export interface FilePreviewProps {
  file?: File;
  lines?: string[];
  fileName?: string;
  maxLines?: number;
  highlightLines?: number[];
  encoding?: 'UTF-8' | 'Windows-1252';
  className?: string;
  onError?: (error: Error) => void;
}

export function FilePreview({
  file,
  lines: propLines,
  fileName,
  maxLines = 7,
  highlightLines = [4],
  encoding = 'Windows-1252',
  className = '',
  onError
}: FilePreviewProps) {
  const [lines, setLines] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  
  useEffect(() => {
    const loadFileLines = async (fileToLoad: File) => {
      setIsLoading(true);
      setError(null);
      
      try {
        const chunk = await fileToLoad.slice(0, 10 * 1024).arrayBuffer();
        const decoder = new TextDecoder(encoding === 'Windows-1252' ? 'windows-1252' : 'utf-8');
        const text = decoder.decode(chunk);
        const allLines = text.split(/\r?\n/);
        setLines(allLines.slice(0, maxLines));
      } catch (err) {
        const error = err instanceof Error ? err : new Error('Error leyendo archivo');
        setError(error);
        onError?.(error);
      } finally {
        setIsLoading(false);
      }
    };

    if (file) {
      void loadFileLines(file);
    } else if (propLines) {
      setLines(propLines.slice(0, maxLines));
    }
  }, [file, propLines, maxLines, encoding, onError]);
  
  const displayFileName = fileName || file?.name || 'archivo.txt';
  
  if (isLoading) {
    return (
      <div className={`border rounded-lg p-4 bg-gray-50 dark:bg-gray-800 ${className}`}>
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
          <span className="ml-3 text-gray-600 dark:text-gray-300">Cargando preview...</span>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className={`border border-red-300 rounded-lg p-4 bg-red-50 dark:bg-red-900/20 ${className}`}>
        <div className="flex items-center text-red-700 dark:text-red-400">
          <span className="text-2xl mr-3">⚠️</span>
          <div>
            <div className="font-medium">Error al cargar preview</div>
            <div className="text-sm">{error.message}</div>
          </div>
        </div>
      </div>
    );
  }
  
  if (!file && (!propLines || propLines.length === 0)) {
    return null;
  }
  
  const hasSAPLine = highlightLines.some(lineNumber => lines[lineNumber - 1]?.includes('Total:'));
  
  return (
    <div className={`border rounded-lg overflow-hidden dark:border-gray-700 ${className}`}>
      <div className="bg-gray-100 dark:bg-gray-800 px-4 py-2 border-b dark:border-gray-700 flex items-center justify-between">
        <div className="font-medium text-gray-700 dark:text-gray-200">
          Preview del Archivo
        </div>
        <div className="text-sm text-gray-500 dark:text-gray-400">
          Mostrando primeras {lines.length} líneas de {displayFileName}
        </div>
      </div>
      
      <div className="bg-gray-50 dark:bg-gray-900 p-4 max-h-96 overflow-y-auto font-mono text-sm">
        {lines.map((line, index) => {
          const lineNumber = index + 1;
          const isHighlighted = highlightLines.includes(lineNumber);
          
          return (
            <div
              key={index}
              className={`flex py-1 ${ 
                isHighlighted ? 'bg-blue-50 dark:bg-blue-900/30 -mx-4 px-4 border-l-4 border-blue-500' : ''
              }`}
            >
              <div className="w-10 flex-shrink-0 text-right text-gray-500 dark:text-gray-400 select-none pr-3">
                {lineNumber}
              </div>
              
              <div className="flex-1 text-gray-900 dark:text-gray-200 overflow-x-auto whitespace-pre">
                {line.length > 200 ? line.substring(0, 200) + '...' : line}
              </div>
              
              {isHighlighted && line.includes('Total:') && (
                <div className="ml-2 flex-shrink-0">
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                    SAP
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>
      
      {hasSAPLine && (
        <div className="bg-blue-50 dark:bg-blue-900/30 px-4 py-2 border-t border-blue-200 dark:border-blue-800 text-sm text-blue-700 dark:text-blue-300 flex items-center">
          <span className="mr-2">ℹ️</span>
          La línea destacada contiene totales de SAP y no se valida.
        </div>
      )}
    </div>
  );
}
