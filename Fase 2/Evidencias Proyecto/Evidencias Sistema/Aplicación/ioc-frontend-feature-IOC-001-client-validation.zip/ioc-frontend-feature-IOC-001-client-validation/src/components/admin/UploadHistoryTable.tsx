import Button from '../ui/button/Button';
import { Table, TableHeader, TableRow, TableCell, TableBody } from '../ui/table';
import EmptyState from '../common/EmptyState';

type UploadRecord = {
  id: string;
  fileName: string;
  uploadDate: string;
  status: 'Éxito' | 'Fallo' | 'En Progreso';
  user: string;
  errorCount: number;
};

interface UploadHistoryTableProps {
  uploads: UploadRecord[];
  onViewDetails: (uploadId: string) => void;
  "data-testid"?: string;
}

const UploadHistoryTable = ({ uploads, onViewDetails, "data-testid": dataTestId }: UploadHistoryTableProps) => {
  if (uploads.length === 0) {
    return (
      <EmptyState
        title="No hay procesos de carga registrados"
        message="Para comenzar, inicie un nuevo proceso de carga en el panel superior."
      />
    );
  }

  return (
    <div className="max-w-full overflow-x-auto" data-testid={dataTestId}>
      <Table>
        <TableHeader>
          <TableRow>
            <TableCell isHeader className="px-4 py-3 text-start">Nombre del Archivo</TableCell>
            <TableCell isHeader className="px-4 py-3 text-start">Fecha de Carga</TableCell>
            <TableCell isHeader className="px-4 py-3 text-start">Usuario</TableCell>
            <TableCell isHeader className="px-4 py-3 text-start">Estado</TableCell>
            <TableCell isHeader className="px-4 py-3 text-start">Acciones</TableCell>
          </TableRow>
        </TableHeader>
        <TableBody>
          {uploads.map((upload) => (
            <TableRow key={upload.id}>
              <TableCell className="px-4 py-3 truncate">{upload.fileName}</TableCell>
              <TableCell className="px-4 py-3">{new Date(upload.uploadDate).toLocaleString()}</TableCell>
              <TableCell className="px-4 py-3">{upload.user}</TableCell>
              <TableCell className="px-4 py-3">
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  upload.status === 'Éxito' 
                    ? 'bg-success-50 text-success-600 dark:bg-success-500/15 dark:text-success-500' 
                    : upload.status === 'Fallo'
                    ? 'bg-error-50 text-error-600 dark:bg-error-500/15 dark:text-error-500'
                    : 'bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-400'
                }`}>
                  {upload.status}
                </span>
              </TableCell>
              <TableCell className="px-4 py-3">
                {upload.status === 'Fallo' && (
                  <Button variant="outline" size="sm" onClick={() => onViewDetails(upload.id)}>
                    Ver Detalles ({upload.errorCount})
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default UploadHistoryTable;
