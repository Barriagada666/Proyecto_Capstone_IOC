import React, { useState, useEffect, useCallback, useRef } from 'react';
import Alert from './ui/alert/Alert';
import type { DashboardEmbedProps, DashboardUrlResponse } from '../types/dashboard';
import { supabase } from '../lib/supabaseClient';
import DashboardSkeleton from './ui/skeletons/DashboardSkeleton';
import loggingService from '../services/loggingService';
import { fetchWithRetry } from '../utils/fetch';

const REQUEST_TIMEOUT_MS = 10000;
const TOKEN_REFRESH_INTERVAL_MS = 8 * 60 * 1000;

type AbortReason = 'none' | 'timeout' | 'superseded' | 'unmount';

const DashboardEmbed: React.FC<DashboardEmbedProps> = ({
  dashboardId,
  onError,
  onLoad,
  className = ''
}) => {
  const [iframeUrl, setIframeUrl] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isMountedRef = useRef(true);
  const requestIdRef = useRef(0);
  const abortReasonRef = useRef<AbortReason>('none');

  const clearPendingRequest = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    if (abortControllerRef.current) {
      abortReasonRef.current = 'superseded';
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
  }, []);

  const fetchDashboardUrl = useCallback(async (silent = false) => {
    if (!isMountedRef.current) return;
    const currentRequestId = ++requestIdRef.current;
    const session = await supabase.auth.getSession();
    const token = session?.data?.session?.access_token;
    if (!token) {
      if (isMountedRef.current) {
        setError('No authentication token available');
        setLoading(false);
      }
      return;
    }
    clearPendingRequest();
    abortControllerRef.current = new AbortController();
    abortReasonRef.current = 'none';
    timeoutRef.current = setTimeout(() => {
      if (isMountedRef.current && abortControllerRef.current) {
        abortReasonRef.current = 'timeout';
        abortControllerRef.current.abort();
      }
    }, REQUEST_TIMEOUT_MS);
    if (!silent) {
      setLoading(true);
    } else {
      setIsRefreshing(true);
    }
    setError(null);
    try {
      const response = await fetchWithRetry(`/api/v1/dashboards/${dashboardId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        signal: abortControllerRef.current.signal,
        retries: 2,
      });
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      if (!response.ok) {
        if (currentRequestId !== requestIdRef.current) return;
        const errorData = await response.json().catch(() => ({}));
        let errorMessage = errorData.message || `Error ${response.status}: ${response.statusText}`;
        if (response.status === 403) {
          errorMessage = 'You do not have permission to view this dashboard.';
        } else if (response.status === 404) {
          errorMessage = 'Dashboard not found or not configured.';
        } else if (response.status === 500) {
          errorMessage = 'Backend service error. Verify backend on port 8080.';
        } else if ([502,503,504].includes(response.status)) {
          errorMessage = 'Dashboard service temporarily unavailable.';
        }
        if (isMountedRef.current) {
          const error = new Error(errorMessage);
          if (!iframeUrl) {
            setError(error.message);
            setLoading(false);
          }
          setIsRefreshing(false);
          onError?.(error);
        }
        return;
      }
      const data: DashboardUrlResponse = await response.json();
      if (!isMountedRef.current || currentRequestId !== requestIdRef.current) return;
      setIframeUrl(data.signedUrl);
      setLoading(false);
      setIsRefreshing(false);
      setError(null);
      onLoad?.();
    } catch (err) {
      if (!isMountedRef.current || currentRequestId !== requestIdRef.current) return;

      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }

      if (err instanceof Error && err.name === 'AbortError') {
        // Type assertion para evitar TS2678 - bug conocido de TypeScript con useRef
        const reason = abortReasonRef.current as AbortReason;

        // Verificar el motivo del abort
        switch (reason) {
          case 'timeout':
            if (!iframeUrl) {
              const timeoutError = new Error('Request timeout: The dashboard is taking too long to load.');
              setError(timeoutError.message);
              setLoading(false);
              setIsRefreshing(false);
              onError?.(timeoutError);
            }
            break;
          case 'superseded':
          case 'unmount':
          case 'none':
            // No hacemos nada para estos casos
            break;
        }
        return;
      }

      // Manejo para otros errores que no son AbortError
      const errorToReport = err instanceof Error ? err : new Error('Unknown error loading dashboard');
      setError(errorToReport.message);
      setLoading(false);
      setIsRefreshing(false);
      onError?.(errorToReport);
    }
  }, [dashboardId, onError, onLoad, clearPendingRequest, iframeUrl]);

  useEffect(() => {
    isMountedRef.current = true;
    void fetchDashboardUrl(false);
    const refreshInterval = setInterval(() => {
      if (isMountedRef.current) {
        loggingService.info(`Refrescando token para Dashboard ${dashboardId}`);
        void fetchDashboardUrl(true);
      }
    }, TOKEN_REFRESH_INTERVAL_MS);
    return () => {
      isMountedRef.current = false;
      abortReasonRef.current = 'unmount';
      clearPendingRequest();
      clearInterval(refreshInterval);
    };
  }, [fetchDashboardUrl, clearPendingRequest, dashboardId]);

  if (loading) {
    return <DashboardSkeleton className={className} />;
  }
  if (error) {
    return (
      <div className={className}>
        <Alert
          variant="error"
          title="Error Loading Dashboard"
          message={error}
          action={{
            label: 'Retry',
            onClick: () => fetchDashboardUrl(false)
          }}
        />
      </div>
    );
  }
  return (
    <div className={`relative dashboard-embed-container ${className}`}>
      {isRefreshing && (
        <div className="absolute top-4 right-4 z-10 bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-1 rounded-full dark:bg-blue-900 dark:text-blue-300 animate-pulse">
          Refrescando conexión...
        </div>
      )}
      <iframe
        src={iframeUrl}
        width="100%"
        height="100%"
        sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
        title={`Dashboard ${dashboardId}`}
        className="rounded-lg shadow-sm border-none"
      />
    </div>
  );
};

export default DashboardEmbed;
