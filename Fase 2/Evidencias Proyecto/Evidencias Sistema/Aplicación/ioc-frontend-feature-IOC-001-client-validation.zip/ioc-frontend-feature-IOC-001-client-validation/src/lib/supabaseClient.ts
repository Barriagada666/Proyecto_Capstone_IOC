import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabasePublishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

if (!supabaseUrl || !supabasePublishableKey) {
  throw new Error('Supabase URL and the publishable key (VITE_SUPABASE_PUBLISHABLE_KEY) must be defined in the environment variables. Do NOT use anon keys in the frontend config.');
}

export const supabase = createClient(supabaseUrl, supabasePublishableKey);
