import type { AxiosError } from 'axios';
import type { StandardError, UnauthorizedError, ForbiddenError } from '../types/api';

export type ParsedApiError = {
  kind: 'api' | 'auth' | 'network' | 'abort' | 'unknown';
  status?: number;
  message: string;
  data?: StandardError | UnauthorizedError | ForbiddenError | Record<string, unknown> | null;
};

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null;
}

function isStandardError(v: unknown): v is StandardError {
  return isRecord(v) && typeof v.error === 'string' && typeof v.message === 'string' && typeof v.timestamp === 'string';
}

export function parseApiError(err: unknown): ParsedApiError {
  // Axios abort via AbortController yields AxiosError with code ERR_CANCELED
  const maybeAxios = err as Partial<AxiosError> | undefined;
  if (maybeAxios && 'code' in (maybeAxios as object) && maybeAxios?.code === 'ERR_CANCELED') {
    return { kind: 'abort', message: 'Request was canceled by the user.' };
  }

  const axiosError = err as AxiosError | undefined;
  if (axiosError?.isAxiosError) {
    const status = axiosError.response?.status;
    const dataUnknown: unknown = axiosError.response?.data as unknown;

    if (status === 401 || status === 403) {
      const data = isRecord(dataUnknown) ? dataUnknown : null;
      const msg = (isRecord(data) && typeof data.message === 'string') ? (data.message as string) : (status === 401 ? 'Unauthorized' : 'Forbidden');
      return {
        kind: 'auth',
        status,
        message: msg,
        data: data as UnauthorizedError | ForbiddenError | null,
      };
    }

    if (typeof status === 'number') {
      const data = isRecord(dataUnknown) ? dataUnknown : null;
      const std = isStandardError(data) ? (data as StandardError) : undefined;
      const msg = std?.message || axiosError.message || 'Unexpected API error';
      return { kind: 'api', status, message: msg, data: data ?? null };
    }

    // Network error: no response
    if (!axiosError.response) {
      return { kind: 'network', message: axiosError.message || 'Network error' };
    }
  }

  const fallbackMsg = typeof (err as { message?: unknown })?.message === 'string' ? (err as { message?: string }).message! : 'Unknown error';
  return { kind: 'unknown', message: fallbackMsg };
}
