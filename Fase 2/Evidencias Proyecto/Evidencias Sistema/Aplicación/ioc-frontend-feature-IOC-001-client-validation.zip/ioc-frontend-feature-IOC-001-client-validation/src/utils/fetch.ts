/**
 * Una lista de códigos de estado HTTP que indican un error temporal del servidor
 * y para los cuales un reintento automático podría tener éxito.
 */
const RETRYABLE_STATUS_CODES = [502, 503, 504];

/**
 * Opciones para la función fetchWithRetry.
 */
interface FetchWithRetryOptions extends RequestInit {
  retries?: number;
}

/**
 * Realiza una petición fetch con una lógica de reintentos automáticos y backoff exponencial.
 * Solo reintenta en caso de errores de red o códigos de estado HTTP específicos (502, 503, 504).
 *
 * @param url La URL a la que se hará la petición.
 * @param options Opciones de la petición, incluyendo el número de reintentos.
 * @returns Una promesa que se resuelve con el objeto Response.
 * @throws Un error si la petición falla después de todos los reintentos.
 */
export const fetchWithRetry = async (
  url: string,
  options: FetchWithRetryOptions = { retries: 3 }
): Promise<Response> => {
  const { retries = 3, ...fetchOptions } = options;

  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch(url, fetchOptions);

      // Si la respuesta es exitosa o es un error del cliente (4xx) o un error 500,
      // no reintentamos y devolvemos la respuesta directamente.
      if (response.ok || (response.status >= 400 && !RETRYABLE_STATUS_CODES.includes(response.status))) {
        return response;
      }

      // Si es un error reintentable, lanzamos una excepción para activar el reintento.
      throw new Error(`Server error: ${response.status}`);

    } catch (err) {
      // Si es el último intento, relanzamos el error para que sea manejado por el llamador.
      if (i === retries - 1) {
        throw err;
      }

      // Calculamos el tiempo de espera con backoff exponencial (1s, 2s, 4s, ...)
      const delay = Math.pow(2, i) * 1000;
      console.log(`Petición fallida. Reintentando en ${delay / 1000} segundos...`);
      
      // Esperamos antes del siguiente reintento.
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  // Esto teóricamente nunca se alcanzará, pero es necesario para la inferencia de tipos.
  throw new Error('La petición falló después de todos los reintentos.');
};
