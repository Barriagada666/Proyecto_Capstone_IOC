/**
 * Lee una variable de entorno de Vite, la convierte a un número entero y la valida.
 * Muestra advertencias o errores en la consola si la variable no está definida o es inválida.
 * 
 * @param envVar El nombre de la variable de entorno (ej. 'VITE_DASHBOARD_ID').
 * @param name El nombre legible de la variable para los mensajes de log (ej. 'Dashboard Gerencial ID').
 * @returns El número validado, o 0 si no es válido o no está definido.
 */
export function getValidatedEnvId(envVar: string, name: string): number {
  const value = import.meta.env[envVar];

  if (!value) {
    console.warn(`[Configuración] La variable de entorno '${envVar}' para '${name}' no está definida. El componente no se renderizará. Por favor, revisa tu archivo .env.`);
    return 0;
  }

  const id = parseInt(value, 10);

  if (isNaN(id) || id <= 0) {
    console.error(`[Configuración] El valor '${value}' para la variable '${envVar}' ('${name}') no es un ID válido. Debe ser un número entero positivo.`);
    return 0;
  }

  return id;
}
