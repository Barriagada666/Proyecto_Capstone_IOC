import { useAuth } from "../hooks/useAuth";
import { supabase } from "../lib/supabaseClient";
import PageBreadcrumb from "../components/common/PageBreadCrumb";
import Button from "../components/ui/button/Button";
import toast from "react-hot-toast";

const Account = () => {
  const { user } = useAuth();

  const handleSignOut = async () => {
    const toastId = toast.loading("Cerrando sesión...");
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast.error(`Error: ${error.message}`, { id: toastId });
    } else {
      toast.success("Has cerrado sesión.", { id: toastId });
      window.location.href = "/signin";
    }
  };

  return (
    <>
      <PageBreadcrumb pageTitle="Mi Cuenta" />
      <div className="p-4 md:p-6">
        <div className="max-w-2xl">
          <div className="p-5 border border-gray-200 rounded-2xl dark:border-gray-800 bg-white dark:bg-white/[0.03] sm:p-6">
            <h3 className="mb-5 text-lg font-semibold text-gray-800 dark:text-white/90">
              Información del Perfil
            </h3>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Correo Electrónico
                </p>
                <p className="text-sm text-gray-800 dark:text-white/90">
                  {user?.email ?? "No disponible"}
                </p>
              </div>
              <Button onClick={handleSignOut} variant="secondary" size="sm">Cerrar Sesión</Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Account;