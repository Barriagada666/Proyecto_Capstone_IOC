import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";
import MetricCard from "../../components/admin/MetricCard";
import QuickAccessButton from "../../components/admin/QuickAccessButton";
import { GroupIcon, BoxIconLine, AlertIcon, PieChartIcon } from "../../icons";
import LineChartOne from "../../components/charts/line/LineChartOne";
import BarChartOne from "../../components/charts/bar/BarChartOne";
import Alert from "../../components/ui/alert/Alert";
import MetricCardSkeleton from "../../components/ui/skeletons/MetricCardSkeleton";

const ChartSkeleton = () => <div className="w-full h-[350px] bg-gray-100 rounded-2xl animate-pulse dark:bg-gray-800"></div>;

interface ChartData {
  series: { name: string; data: number[] }[];
  categories: string[];
}

interface DashboardMetrics {
  activeUsers: number;
  lastUploadStatus: string;
  kpiAlerts: number;
  userActivity: ChartData;
  uploadHistory: ChartData;
}

const AdminDashboardPage = () => {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Para probar el estado de error, descomenta la siguiente línea:
        // throw new Error("No se pudo cargar la información del panel. Por favor, intente de nuevo.");

        setMetrics({
          activeUsers: 125,
          lastUploadStatus: "Éxito",
          kpiAlerts: 3,
          userActivity: {
            series: [{ name: "Usuarios", data: [180, 190, 170, 160, 175, 165, 170, 205, 230, 210, 240, 235] }],
            categories: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]
          },
          uploadHistory: {
            series: [{ name: "Cargas", data: [168, 385, 201, 298, 187, 195, 291, 110, 215, 390, 280, 112] }],
            categories: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]
          }
        });
      } catch (err) {
        const error = err as Error;
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    void fetchData();
  }, []);

  return (
    <>
      <PageBreadcrumb pageTitle="Panel Principal de Administración" />

      {error && (
        <div className="mb-4">
          <Alert variant="error" title="Error de Carga" message={error} />
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:gap-6 xl:grid-cols-3 2xl:grid-cols-3">
        {loading ? (
          <>
            <MetricCardSkeleton />
            <MetricCardSkeleton />
            <MetricCardSkeleton />
          </>
        ) : metrics && (
          <>
            <MetricCard
              title="Usuarios Activos"
              value={metrics.activeUsers}
              icon={<GroupIcon className="size-6" />}
            />
            <MetricCard
              title="Estado Última Carga"
              value={metrics.lastUploadStatus}
              icon={<BoxIconLine className="size-6" />}
            />
            <MetricCard
              title="Alertas de KPI"
              value={metrics.kpiAlerts}
              icon={<AlertIcon className="size-6" />}
            />
          </>
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2 xl:grid-cols-3">
        <QuickAccessButton
          title="Cargar Datos"
          icon={<BoxIconLine className="size-8" />}
          onClick={() => navigate("/admin/ingesta-datos")}
        />
        <QuickAccessButton
          title="Gestionar Contenido"
          icon={<PieChartIcon className="size-8" />}
          onClick={() => navigate("/admin/contenido")}
        />
        <QuickAccessButton
          title="Gestionar Usuarios"
          icon={<GroupIcon className="size-8" />}
          onClick={() => navigate("/admin/seguridad")}
        />
      </div>

      <div className="grid grid-cols-1 gap-6 mt-6 xl:grid-cols-2">
        {loading ? (
          <>
            <ChartSkeleton />
            <ChartSkeleton />
          </>
        ) : metrics && (
          <>
            <div className="p-5 border border-gray-200 rounded-2xl dark:border-gray-800 bg-white dark:bg-white/[0.03] sm:p-6">
              <h3 className="mb-5 text-lg font-semibold text-gray-800 dark:text-white/90">Actividad de Usuarios</h3>
              <LineChartOne
                series={metrics.userActivity.series}
                categories={metrics.userActivity.categories}
              />
            </div>
            <div className="p-5 border border-gray-200 rounded-2xl dark:border-gray-800 bg-white dark:bg-white/[0.03] sm:p-6">
              <h3 className="mb-5 text-lg font-semibold text-gray-800 dark:text-white/90">Historial de Cargas</h3>
              <BarChartOne
                series={metrics.uploadHistory.series}
                categories={metrics.uploadHistory.categories}
              />
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default AdminDashboardPage;
