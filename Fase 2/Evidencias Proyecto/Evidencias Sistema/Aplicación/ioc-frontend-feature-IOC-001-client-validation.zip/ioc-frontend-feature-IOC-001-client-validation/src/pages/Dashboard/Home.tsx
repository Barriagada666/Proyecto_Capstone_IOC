import React from 'react';
import PageBreadcrumb from '../../components/common/PageBreadCrumb';

const Home: React.FC = () => {
  return (
    <>
      <PageBreadcrumb pageTitle="feature/IOC-001-integracion-api-ingesta" />
      <div className="p-4 md:p-6">
        <h2 className="text-2xl font-semibold text-gray-800 dark:text-white/90">
          Bienvenido al Panel de Inteligencia Operacional
        </h2>
        <p className="mt-2 text-gray-500 dark:text-gray-400">
          Seleccione una opción del menú para comenzar.
        </p>
      </div>
    </>
  );
};

export default Home;