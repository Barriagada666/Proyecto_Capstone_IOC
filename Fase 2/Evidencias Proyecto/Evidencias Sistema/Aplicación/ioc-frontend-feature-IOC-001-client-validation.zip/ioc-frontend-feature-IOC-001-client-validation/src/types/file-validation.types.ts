// src/types/file-validation.types.ts

/**
 * Configuración para el proceso de validación de archivos.
 * Permite anular los valores por defecto.
 */
export interface FileValidationConfig {
  maxSizeMb: number;
  allowedExtensions: string[];
  expectedHeaders: string[];
  sampleLines: number;
  maxReadBytes: number;
  delimiter: string;
  sapLineIdentifier: string;
  featureFlagEnabled: boolean;
}

/**
 * Representa un error o advertencia de validación individual.
 */
export interface ValidationError {
  code: 'INVALID_EXTENSION' | 'FILE_TOO_LARGE' | 'FILE_EMPTY' | 'HEADER_MISMATCH' | 'MISSING_COLUMNS' | 'INVALID_NUMERIC' | 'INVALID_DATE' | 'REQUIRED_FIELD_EMPTY' | 'INTERNAL_ERROR';
  severity: 'ERROR' | 'WARNING';
  message: string;
  details?: string; // ej. "Expected: 9, Found: 8"
}

/**
 * Resumen de los metadatos y resultados de la validación.
 */
export interface ValidationSummary {
  fileName: string;
  fileSizeMb: number;
  encoding: 'UTF-8' | 'Windows-1252';
  lineCount: number;
  headers: string[];
  isSapFile: boolean;
}

/**
 * El objeto de resultado completo devuelto por el proceso de validación.
 */
export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  warnings: ValidationError[];
  summary: ValidationSummary;
  previewLines?: string[];
}
