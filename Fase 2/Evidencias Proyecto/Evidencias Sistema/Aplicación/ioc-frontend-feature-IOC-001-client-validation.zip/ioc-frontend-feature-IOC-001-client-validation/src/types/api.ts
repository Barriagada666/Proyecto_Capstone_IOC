// =================================================================
// INTERFACES PARA LA API DE INGESTA DE DATOS (IOC-001)
// Fuente de Verdad: .gemini/sprints/frontend_sync_brief.md
// =================================================================

/**
 * Respuesta del endpoint `POST /api/etl/start-process` cuando el job es aceptado.
 */
export interface StartProcessResponse {
  jobId: string;     // UUID del job creado
  fileName: string;  // Nombre del archivo original
  status: string;    // Estado inicial, ej: "INICIADO"
}

/**
 * DTO principal que representa el estado de un job ETL.
 * Usado en la respuesta de `GET /api/etl/jobs/{jobId}/status`.
 */
export interface EtlJobStatusDto {
  jobId: string;
  fileName: string;
  status: 'INICIADO' | 'PROCESANDO' | 'EXITO' | 'FALLO';
  details: string | null;
  minDate: string | null;    // Formato: YYYY-MM-DD
  maxDate: string | null;    // Formato: YYYY-MM-DD
  createdAt: string | null;  // Formato: ISO 8601 (e.g., 2025-09-21T12:34:56Z)
  finishedAt: string | null; // Formato: ISO 8601
}

// =================================================================
// INTERFACES PARA ERRORES ESTANDARIZADOS DE LA API
// =================================================================

/**

 * Payload de error estándar para respuestas 4xx y 5xx.

 */

export interface StandardError {

  error: string;

  message: string;

  timestamp: string;

}



/**

 * Payload de error para respuestas 401 Unauthorized.

 */

export interface UnauthorizedError {

  timestamp: string;

  status: 401;

  error: "Unauthorized";

  message: string;

  path: string;

}



/**

 * Payload de error para respuestas 403 Forbidden.

 */

export interface ForbiddenError {

  timestamp: string;

  status: 403;

  error: "Forbidden";

  message: string;

  path: string;

}
