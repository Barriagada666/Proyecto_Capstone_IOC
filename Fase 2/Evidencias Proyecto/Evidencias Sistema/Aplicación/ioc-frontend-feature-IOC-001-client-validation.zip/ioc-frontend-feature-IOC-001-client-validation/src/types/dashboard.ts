export interface DashboardEmbedProps {
  dashboardId: number;
  height?: string;
  onError?: (error: Error) => void;
  onLoad?: () => void;
  className?: string;
}

export interface DashboardUrlResponse {
  signedUrl: string;
  expiresInMinutes: number;
  dashboardId: number;
}

export interface DashboardError {
  status: number;
  title: string;
  message: string;
  timestamp: string;
}
