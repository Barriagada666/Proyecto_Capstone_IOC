import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { ProtectedRoute } from "./components/auth/ProtectedRoute";
import Account from "./pages/Account";
import SignIn from "./pages/AuthPages/SignIn";
import SignUp from "./pages/AuthPages/SignUp";
import ResetPassword from "./pages/AuthPages/ResetPassword";
import UpdatePassword from "./pages/AuthPages/UpdatePassword";
import NotFound from "./pages/OtherPage/NotFound";
import AppLayout from "./layout/AppLayout";
import Home from "./pages/Dashboard/Home";
import AdminDashboardPage from "./pages/admin/AdminDashboardPage";
import DataIngestionPage from "./pages/admin/DataIngestionPage";
import DashboardsPage from "./pages/DashboardsPage"; // Importar la nueva página
import Blank from "./pages/Blank";

export default function App() {
  return (
    <Router>
      <Toaster
        position="top-right"
        reverseOrder={false}
        toastOptions={{
          success: {
            duration: 3000,
          },
          error: {
            duration: 4000,
          },
        }}
      />
      <Routes>
        {/* Rutas Protegidas */}
        <Route element={<ProtectedRoute />}>
          <Route element={<AppLayout />}>
            <Route index path="/" element={<Home />} />
            <Route path="/account" element={<Account />} />
            <Route path="/dashboards" element={<DashboardsPage />} /> 
            {/* Rutas de Administración */}
            <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
            <Route path="/admin/ingesta-datos" element={<DataIngestionPage />} />
            <Route path="/admin/contenido-analitico" element={<Blank />} />
            <Route path="/admin/acceso-seguridad" element={<Blank />} />
          </Route>
        </Route>

        {/* Rutas Públicas */}
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/update-password" element={<UpdatePassword />} />
        
        {/* Ruta de Fallback */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}
