import { setupServer } from 'msw/node';
import { http, HttpResponse } from 'msw';

// Default handlers for common endpoints
const defaultHandlers = [
  // Default fallback for ETL endpoints
  http.post('http://localhost/api/etl/start-process', () => {
    return HttpResponse.json({
      jobId: 'default-job',
      fileName: 'default.csv',
      status: 'INICIADO'
    }, { status: 202 });
  }),

  http.get('http://localhost/api/etl/jobs/:jobId/status', () => {
    return HttpResponse.json({
      jobId: 'default-job',
      fileName: 'default.csv',
      status: 'EXITO',
      details: null,
      minDate: null,
      maxDate: null,
      createdAt: new Date().toISOString(),
      finishedAt: new Date().toISOString(),
    });
  }),
];

export const server = setupServer(...defaultHandlers);
