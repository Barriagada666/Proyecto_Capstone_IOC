import { beforeAll, afterEach, afterAll, vi } from 'vitest';
import '@testing-library/jest-dom';
import { server } from './server';

// Force axios to use Node http adapter by removing XHR from jsdom env
// eslint-disable-next-line @typescript-eslint/no-explicit-any
(delete (globalThis as any).XMLHttpRequest);

// Ensure axios baseURL uses an absolute URL in Node test env
// @ts-expect-error - process.env typing in Vitest jsdom environment
process.env.VITE_API_BASE_URL = process.env.VITE_API_BASE_URL || 'http://localhost';

beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

// Use fake timers for interval-based polling
vi.useFakeTimers();
