// src/hooks/useFileValidation.ts
import { useState, useCallback, useRef } from 'react';
import { validateFile, DEFAULT_FILE_VALIDATION_CONFIG } from '../services/FileValidator';
import type { FileValidationConfig, ValidationResult } from '../types/file-validation.types';
import loggingService from '../services/loggingService';

export enum ValidationState {
  IDLE = 'IDLE',
  PRECHECK = 'PRECHECK',
  READING = 'READING',
  PARSING_HEADERS = 'PARSING_HEADERS',
  SAMPLING = 'SAMPLING',
  SUMMARY = 'SUMMARY',
  READY = 'READY',
  BLOCKED = 'BLOCKED',
  ERROR = 'ERROR',
}

export interface UseFileValidationReturn {
  state: ValidationState;
  result: ValidationResult | null;
  isValidating: boolean;
  validate: (file: File) => Promise<void>;
  reset: () => void;
  validationDuration: number | null;
  // Funciones para manipulación externa
  setResult: React.Dispatch<React.SetStateAction<ValidationResult | null>>;
  setState: React.Dispatch<React.SetStateAction<ValidationState>>;
}

export function useFileValidation(
  configOverride?: Partial<FileValidationConfig>
): UseFileValidationReturn {
  const [state, setState] = useState<ValidationState>(ValidationState.IDLE);
  const [result, setResult] = useState<ValidationResult | null>(null);
  const [validationDuration, setValidationDuration] = useState<number | null>(null);
  const mountedRef = useRef(true);

  // Mantener mountedRef para evitar setState en componentes desmontados
  // (si acaso se extiende en el futuro); no usar effect para mantener simple.

  const isValidating = [
    ValidationState.PRECHECK,
    ValidationState.READING,
    ValidationState.PARSING_HEADERS,
    ValidationState.SAMPLING,
    ValidationState.SUMMARY,
  ].includes(state);

  const validate = useCallback(
    async (file: File) => {
      setState(ValidationState.PRECHECK);
      const start = Date.now();
      const cfg: FileValidationConfig = {
        ...DEFAULT_FILE_VALIDATION_CONFIG,
        ...(configOverride || {}),
      } as FileValidationConfig;

      try {
        setState(ValidationState.READING);
        const res = await validateFile(file, cfg);

        if (!mountedRef.current) return;

        setResult(res);
        setValidationDuration(Date.now() - start);

        // Estado final según validez
        setState(res.isValid ? ValidationState.READY : ValidationState.BLOCKED);
      } catch (err) {
        // loggingService.error expects (error, context?) so pass the Error first
        loggingService?.error?.(err as Error, { where: 'useFileValidation.validate' });
        if (!mountedRef.current) return;
        setResult(null);
        setState(ValidationState.ERROR);
        setValidationDuration(Date.now() - start);
      }
    },
    [configOverride]
  );

  const reset = useCallback(() => {
    setState(ValidationState.IDLE);
    setResult(null);
    setValidationDuration(null);
  }, []);

  return {
    state,
    result,
    isValidating,
    validate,
    reset,
    validationDuration,
    setResult, // Exponer
    setState, // Exponer
  };
}
