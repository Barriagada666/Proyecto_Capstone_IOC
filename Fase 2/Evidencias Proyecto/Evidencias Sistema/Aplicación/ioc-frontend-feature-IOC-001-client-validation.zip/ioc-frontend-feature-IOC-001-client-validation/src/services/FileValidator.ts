// src/services/FileValidator.ts
import type { FileValidationConfig, ValidationResult, ValidationError, ValidationSummary } from '../types/file-validation.types';

export const DEFAULT_FILE_VALIDATION_CONFIG: FileValidationConfig = {
  maxSizeMb: 50,
  allowedExtensions: ['txt'],
  expectedHeaders: [
    'status', 'fecha cont.', 'hora', 'fecha notif', 'numero log.', 'documento', 'material',
    'descripcion', 'no pallet', 'cantidad', 'peso neto', 'lista', 'version', 'maquina',
    'maquinista', 'ctro.ctos.', 'turno', 'jornada', 'usuario', 'bodeguero'
  ],
  sampleLines: 10,
  maxReadBytes: 100 * 1024, // 100KB para preview
  delimiter: '|',
  sapLineIdentifier: 'Total:',
  featureFlagEnabled: true,
};

/**
 * Normaliza un string de cabecera exactamente como lo hace el backend.
 * Replica la lógica de parseHeader() del ParserService.
 */
const normalizeHeader = (header: string): string => {
  return header.trim().toLowerCase()
    .replace(/á/g, 'a').replace(/é/g, 'e').replace(/í/g, 'i')
    .replace(/ó/g, 'o').replace(/ú/g, 'u').replace(/°/g, 'o');
};

// Helper: safe conversion Blob -> ArrayBuffer across environments (File API, jsdom, Node)
async function blobToArrayBuffer(blob: Blob): Promise<ArrayBuffer> {
  // Prefer native arrayBuffer if available
  if ('arrayBuffer' in blob && typeof (blob as any).arrayBuffer === 'function') {
    return await (blob as any).arrayBuffer();
  }
  // If Response is available (modern env), use it
  if (typeof Response !== 'undefined') {
    return await new Response(blob).arrayBuffer();
  }
  // Fallback to FileReader (older browsers / polyfills)
  return await new Promise<ArrayBuffer>((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result as ArrayBuffer);
    fr.onerror = () => reject(fr.error);
    fr.readAsArrayBuffer(blob);
  });
}

/**
 * Validación inicial del archivo (extensión, tamaño, etc.)
 */
function precheck(file: File, config: FileValidationConfig, errors: ValidationError[]) {
  // Validar extensión
  const ext = file.name.split('.').pop()?.toLowerCase();
  if (!ext || !config.allowedExtensions.includes(ext)) {
    errors.push({
      code: 'INVALID_EXTENSION',
      severity: 'ERROR',
      message: `Extensión no válida. Se esperaba: ${config.allowedExtensions.join(', ')}`,
      details: `Archivo: ${file.name}`
    });
  }

  // Validar tamaño
  const sizeMb = file.size / 1024 / 1024;
  if (sizeMb > config.maxSizeMb) {
    errors.push({
      code: 'FILE_TOO_LARGE',
      severity: 'ERROR',
      message: `El archivo es demasiado grande (${sizeMb.toFixed(2)} MB). Máximo permitido: ${config.maxSizeMb} MB`,
    });
  }

  // Validar que no esté vacío
  if (file.size === 0) {
    errors.push({
      code: 'FILE_EMPTY',
      severity: 'ERROR',
      message: 'El archivo está vacío.'
    });
  }
}

/**
 * Valida que el archivo tenga las columnas requeridas.
 * Replica la lógica de isRecordValid() del backend.
 */
function validateHeaders(headers: string[], errors: ValidationError[]) {
  const requiredFields = [
    'fecha cont.', 'maquina', 'numero log.', 'hora', 'fecha notif', 'material',
    'cantidad', 'peso neto', 'turno'
  ];
  
  const missingHeaders = requiredFields.filter(h => !headers.includes(h));
  if (missingHeaders.length > 0) {
    errors.push({
      code: 'MISSING_COLUMNS',
      severity: 'ERROR',
      message: 'Faltan columnas requeridas en la cabecera.',
      details: `Columnas faltantes: ${missingHeaders.join(', ')}`
    });
  }
}

/**
 * Valida las filas de datos de ejemplo.
 * Replica las validaciones del parseDataLine() y setterMap del backend.
 */
function validateDataRows(
  rows: string[], 
  headerMap: Map<string, number>, 
  config: FileValidationConfig, 
  errors: ValidationError[],
  startLineNumber: number
) {
  const DATE_PATTERN = /^\d{2}\.\d{2}\.\d{4}$/;
  const TIME_PATTERN = /^\d{2}:\d{2}:\d{2}$/;
  
  rows.forEach((row, index) => {
    const values = row.split(config.delimiter).map(v => v.trim());
    const lineNumber = startLineNumber + index;
    
    // Validar Fecha Cont. (obligatorio)
    const fechaIdx = headerMap.get('fecha cont.');
    if (fechaIdx !== undefined) {
      const value = values[fechaIdx] || '';
      if (!value) {
        errors.push({ 
          code: 'REQUIRED_FIELD_EMPTY', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: El campo 'Fecha Cont.' es obligatorio y está vacío.`,
          details: String(lineNumber)
        });
      } else if (!DATE_PATTERN.test(value)) {
        errors.push({ 
          code: 'INVALID_DATE', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: Formato de fecha inválido en 'Fecha Cont.'. Se esperaba dd.MM.yyyy (ej: 30.08.2025)`,
          details: String(lineNumber)
        });
      }
    }
    
    // Validar Hora (obligatorio)
    const horaIdx = headerMap.get('hora');
    if (horaIdx !== undefined) {
      const value = values[horaIdx] || '';
      if (!value) {
        errors.push({ 
          code: 'REQUIRED_FIELD_EMPTY', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: El campo 'Hora' es obligatorio y está vacío.`,
          details: String(lineNumber)
        });
      } else if (!TIME_PATTERN.test(value)) {
        errors.push({ 
          code: 'INVALID_DATE', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: Formato de hora inválido. Se esperaba HH:mm:ss (ej: 08:29:15)`,
          details: String(lineNumber)
        });
      }
    }
    
    // Validar Fecha Notif (obligatorio)
    const fechaNotifIdx = headerMap.get('fecha notif');
    if (fechaNotifIdx !== undefined) {
      const value = values[fechaNotifIdx] || '';
      if (!value) {
        errors.push({ 
          code: 'REQUIRED_FIELD_EMPTY', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: El campo 'Fecha Notif' es obligatorio y está vacío.`,
          details: String(lineNumber)
        });
      } else if (!DATE_PATTERN.test(value)) {
        errors.push({ 
          code: 'INVALID_DATE', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: Formato de fecha inválido en 'Fecha Notif'. Se esperaba dd.MM.yyyy`,
          details: String(lineNumber)
        });
      }
    }
    
    // Validar Numero Log. (obligatorio)
    const numLogIdx = headerMap.get('numero log.');
    if (numLogIdx !== undefined) {
      const value = values[numLogIdx] || '';
      if (!value) {
        errors.push({ 
          code: 'REQUIRED_FIELD_EMPTY', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: El campo 'Numero Log.' es obligatorio y está vacío.`,
          details: String(lineNumber)
        });
      } else {
        const normalized = value.replace(/\s/g, '').replace(/,/g, '');
        if (!/^\d+$/.test(normalized)) {
          errors.push({ 
            code: 'INVALID_NUMERIC', 
            severity: 'ERROR', 
            message: `Línea ${lineNumber}: El valor de 'Numero Log.' no es un número válido.`,
            details: String(lineNumber)
          });
        }
      }
    }
    
    // Validar Material (obligatorio)
    const materialIdx = headerMap.get('material');
    if (materialIdx !== undefined) {
      const value = values[materialIdx] || '';
      if (!value) {
        errors.push({ 
          code: 'REQUIRED_FIELD_EMPTY', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: El campo 'Material' es obligatorio y está vacío.`,
          details: String(lineNumber)
        });
      }
    }
    
    // Validar Maquina (obligatorio)
    const maquinaIdx = headerMap.get('maquina');
    if (maquinaIdx !== undefined) {
      const value = values[maquinaIdx] || '';
      if (!value) {
        errors.push({ 
          code: 'REQUIRED_FIELD_EMPTY', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: El campo 'Maquina' es obligatorio y está vacío.`,
          details: String(lineNumber)
        });
      }
    }
    
    // Validar Cantidad (obligatorio, decimal con coma)
    const cantidadIdx = headerMap.get('cantidad');
    if (cantidadIdx !== undefined) {
      const value = values[cantidadIdx] || '';
      if (!value) {
        errors.push({ 
          code: 'REQUIRED_FIELD_EMPTY', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: El campo 'Cantidad' es obligatorio y está vacío.`,
          details: String(lineNumber)
        });
      } else {
        const normalized = value.replace(/\./g, '').replace(/,/g, '.');
        if (isNaN(Number(normalized))) {
          errors.push({ 
            code: 'INVALID_NUMERIC', 
            severity: 'ERROR', 
            message: `Línea ${lineNumber}: El valor de 'Cantidad' no es un número válido. Use coma como separador decimal (ej: 48,000)`,
            details: String(lineNumber)
          });
        }
      }
    }
    
    // Validar Peso Neto (obligatorio, decimal con coma)
    const pesoIdx = headerMap.get('peso neto');
    if (pesoIdx !== undefined) {
      const value = values[pesoIdx] || '';
      if (!value) {
        errors.push({ 
          code: 'REQUIRED_FIELD_EMPTY', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: El campo 'Peso Neto' es obligatorio y está vacío.`,
          details: String(lineNumber)
        });
      } else {
        const normalized = value.replace(/\./g, '').replace(/,/g, '.');
        if (isNaN(Number(normalized))) {
          errors.push({ 
            code: 'INVALID_NUMERIC', 
            severity: 'ERROR', 
            message: `Línea ${lineNumber}: El valor de 'Peso Neto' no es un número válido. Use coma como separador decimal`,
            details: String(lineNumber)
          });
        }
      }
    }
    
    // Validar Turno (obligatorio)
    const turnoIdx = headerMap.get('turno');
    if (turnoIdx !== undefined) {
      const value = values[turnoIdx] || '';
      if (!value) {
        errors.push({ 
          code: 'REQUIRED_FIELD_EMPTY', 
          severity: 'ERROR', 
          message: `Línea ${lineNumber}: El campo 'Turno' es obligatorio y está vacío.`,
          details: String(lineNumber)
        });
      }
    }
  });
}

/**
 * Construye el resultado de validación.
 */
function buildResult(
  isValid: boolean,
  errors: ValidationError[],
  warnings: ValidationError[],
  file: File,
  summary?: Partial<ValidationSummary>,
  previewLines?: string[]
): ValidationResult {
  return {
    isValid,
    errors,
    warnings,
    summary: {
      fileName: summary?.fileName || file.name,
      fileSizeMb: summary?.fileSizeMb || parseFloat((file.size / 1024 / 1024).toFixed(2)),
      encoding: summary?.encoding || 'UTF-8',
      lineCount: summary?.lineCount || 0,
      headers: summary?.headers || [],
      isSapFile: summary?.isSapFile || false,
    },
    previewLines,
  };
}

/** Decode buffer as UTF-8 or Windows-1252 and return both candidates */
async function getDecodedCandidates(file: File, maxBytes: number): Promise<{ utf8: string; win1252: string; hasHighBytes: boolean }> {
  const slice = file.slice(0, maxBytes);

  // Try fast path: blob.text() which exists in jsdom/browser
  let utf8 = '';
  try {
    if (typeof (slice as any).text === 'function') {
      utf8 = await (slice as any).text();
    }
  } catch { // ignore
    utf8 = '';
  }

  let buffer: ArrayBuffer | null;
  try {
    buffer = await blobToArrayBuffer(slice);
  } catch { // ignore
    buffer = null;
  }

  let win1252 = utf8;
  let hasHighBytes: boolean;

  if (buffer) {
    const bytes = new Uint8Array(buffer);
    hasHighBytes = bytes.some(b => b >= 0x80);
    const utf8FromBuffer = new TextDecoder('utf-8', { fatal: false }).decode(buffer);
    if (!utf8) utf8 = utf8FromBuffer;
    try {
      // use a typed assertion instead of ts-ignore/expect to avoid lint error
      win1252 = new (TextDecoder as any)('windows-1252').decode(buffer);
    } catch {
      // fallback: construct from bytes
      let txt = '';
      for (let i = 0; i < bytes.length; i++) txt += String.fromCharCode(bytes[i]);
      win1252 = txt;
    }
  } else {
    // No buffer available; derive hasHighBytes from utf8 string
    hasHighBytes = Array.from(utf8).some(ch => ch.charCodeAt(0) > 127);
    // win1252 remains equal to utf8 (best effort)
  }

  return { utf8, win1252, hasHighBytes };
}

/**
 * Función principal de validación que replica la lógica del ParserService del backend.
 */
export async function validateFile(
  file: File,
  config: FileValidationConfig = DEFAULT_FILE_VALIDATION_CONFIG
): Promise<ValidationResult> {
  const errors: ValidationError[] = [];
  const warnings: ValidationError[] = [];

  // --- FASE 1: Pre-chequeos básicos ---
  precheck(file, config, errors);
  if (errors.length > 0) {
    return buildResult(false, errors, warnings, file);
  }

  try {
    // --- FASE 2: Obtener decodificaciones candidatas ---
    const { utf8, win1252 } = await getDecodedCandidates(file, config.maxReadBytes);

    // Selector de mejor decodificación: aquella cuyo header normalizado cubra más campos requeridos
    const required = ['fecha cont.', 'maquina', 'numero log.', 'hora', 'fecha notif', 'material', 'cantidad', 'peso neto', 'turno'];
    function evalCandidate(content: string) {
      const lines = content.split(/\r?\n/);
      const headerIdx = lines.findIndex(l => {
        try {
          if (!l || !l.includes(config.delimiter)) return false;
          const parts = l.split(config.delimiter).map(p => normalizeHeader(p || ''));
          return parts.some(p => p === 'fecha cont.');
        } catch { return false; }
      });
      const headerLine = headerIdx >= 0 ? lines[headerIdx] : '';
      const headers = headerLine ? headerLine.split(config.delimiter).map(normalizeHeader) : [];
      // debug temporary
      try {
        console.debug('[FileValidator] evalCandidate headerLine:', headerLine ? headerLine.slice(0, 200) : '<empty>');
        console.debug('[FileValidator] evalCandidate headers parts:', headers.slice(0, 30));
      } catch { /* ignore console debugging errors */ }
      const missing = required.filter(h => !headers.includes(h)).length;
      return { content, headerIdx, headers, missing, lines };
    }
    const candUtf8 = evalCandidate(utf8);
    const candW1252 = evalCandidate(win1252);

    // Elegir mejor
    let best = (candW1252.missing < candUtf8.missing) ? candW1252 : candUtf8;
    let encoding: 'UTF-8' | 'Windows-1252' = (best === candW1252) ? 'Windows-1252' : 'UTF-8';
    if (candW1252.missing === candUtf8.missing) {
      // Empate: preferir Windows-1252 si hay bytes altos y decodificación difiere
      const { hasHighBytes } = await getDecodedCandidates(file, 1024);
      if (hasHighBytes && candW1252.headers.length >= candUtf8.headers.length && win1252 !== utf8) {
        best = candW1252;
        encoding = 'Windows-1252';
      }
    }
    const allLines = best.lines;

    // --- FASE 3: Buscar la línea de cabecera (igual que el backend) ---
    const headerLineIndex = best.headerIdx;
    if (headerLineIndex === -1) {
      errors.push({
        code: 'HEADER_MISMATCH',
        severity: 'ERROR',
        message: 'No se encontró la línea de cabecera. Se esperaba una línea que contenga "Fecha Cont.".'
      });
      return buildResult(false, errors, warnings, file, { encoding }, allLines.slice(0, 14));
    }

    // --- FASE 4: Parsear la cabecera ---
    const headerLine = allLines[headerLineIndex];
    const rawHeaders = headerLine.split(config.delimiter);
    const headers = rawHeaders.map(normalizeHeader);
    const headerMap = new Map(headers.map((h, i) => [h, i]));

    // --- FASE 5: Filtrar líneas de datos (como el backend) ---
    const dataLines = allLines
      .slice(headerLineIndex + 1)
      .filter(line => {
        const trimmed = line.trim();
        return trimmed &&
               !trimmed.startsWith('-') &&
               !line.includes('Cantidad') &&
               trimmed !== '' &&
               line.includes(config.delimiter);
      });

    // Extra: eliminar la fila de totales de SAP si está inmediatamente después del header
    const filteredDataLines = dataLines.filter((line, idx) => !(idx === 0 && isTotalsRow(line, headerMap, config.delimiter)));

    const summary: Partial<ValidationSummary> = {
      fileName: file.name,
      fileSizeMb: parseFloat((file.size / 1024 / 1024).toFixed(2)),
      encoding,
      lineCount: filteredDataLines.length,
      headers,
      isSapFile: encoding === 'Windows-1252',
    };

    // --- FASE 6: Validar columnas requeridas ---
    validateHeaders(headers, errors);
    if (errors.length > 0) {
      return buildResult(false, errors, warnings, file, summary, allLines.slice(0, 14));
    }

    // --- FASE 7: Validar muestra de datos ---
    const sampleDataLines = filteredDataLines.slice(0, config.sampleLines);
    const startLineNumber = headerLineIndex + 2;
    validateDataRows(sampleDataLines, headerMap, config, errors, startLineNumber);

    // Resultado final
    return buildResult(errors.length === 0, errors, warnings, file, summary, allLines.slice(0, 14));

  } catch (error) {
    errors.push({
      code: 'INTERNAL_ERROR',
      severity: 'ERROR',
      message: 'Ocurrió un error inesperado durante la validación del archivo.',
      details: error instanceof Error ? error.message : 'Error desconocido'
    });
    return buildResult(false, errors, warnings, file);
  }
}

/**
 * Detecta si una fila es una fila de totales de SAP.
 * Se basa en la observación de que la fila de totales tiene campos vacíos en columnas requeridas
 * y un valor numérico en la columna de cantidad o peso neto.
 */
function isTotalsRow(row: string, headerMap: Map<string, number>, delimiter: string): boolean {
  const values = row.split(delimiter).map(v => v.trim());
  const statusIdx = headerMap.get('status');
  const fechaIdx = headerMap.get('fecha cont.');
  const horaIdx = headerMap.get('hora');
  const notifIdx = headerMap.get('fecha notif');
  const logIdx = headerMap.get('numero log.');
  const materialIdx = headerMap.get('material');
  const maquinaIdx = headerMap.get('maquina');
  const turnoIdx = headerMap.get('turno');
  const cantidadIdx = headerMap.get('cantidad');
  const pesoIdx = headerMap.get('peso neto');

  const statusVal = statusIdx !== undefined ? (values[statusIdx] || '') : '';
  const looksTotalsStatus = statusVal.replace(/\s+/g, '') === '*' || statusVal === '';

  const emptyRequired = [fechaIdx, horaIdx, notifIdx, logIdx, materialIdx, maquinaIdx, turnoIdx]
    .every(idx => idx === undefined || !values[idx] || values[idx].trim() === '');

  const numCantidad = Boolean(cantidadIdx !== undefined && values[cantidadIdx] && /[\d]/.test(values[cantidadIdx] || ''));
  const numPeso = Boolean(pesoIdx !== undefined && values[pesoIdx] && /[\d]/.test(values[pesoIdx] || ''));

  return looksTotalsStatus && emptyRequired && (numCantidad || numPeso);
}
