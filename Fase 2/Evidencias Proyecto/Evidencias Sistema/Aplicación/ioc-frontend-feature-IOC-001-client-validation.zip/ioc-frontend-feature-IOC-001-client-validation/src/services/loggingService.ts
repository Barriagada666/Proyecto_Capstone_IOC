// src/services/loggingService.ts

// import * as Sentry from "@sentry/react";

/**
 * Un servicio de logging simple para centralizar los logs de la aplicación.
 * En el futuro, se integrará con un servicio de monitoreo como Sentry.
 */

const isDevelopment = import.meta.env.DEV;

/**
 * Registra un error. En desarrollo, lo muestra en la consola.
 * En producción, lo enviaría a un servicio de monitoreo.
 * @param error El error a registrar. Puede ser un objeto Error o cualquier otro valor.
 * @param context Información adicional sobre el contexto del error.
 */
export function logError(error: unknown, context?: Record<string, unknown>): void {
  if (isDevelopment) {
    console.error('[ERROR]', error, context ? `| Context: ${JSON.stringify(context)}` : '');
  } else {
    // En producción, enviaríamos el error a Sentry u otro servicio.
    // Sentry.withScope(scope => {
    //   if (context) {
    //     scope.setExtras(context);
    //   }
    //   Sentry.captureException(error);
    // });
  }
}

/**
 * Registra un mensaje informativo. Solo se muestra en desarrollo para no generar ruido en producción.
 * @param message El mensaje a registrar.
 * @param context Información adicional.
 */
export function logInfo(message: string, context?: Record<string, unknown>): void {
  if (isDevelopment) {
    console.log('[INFO]', message, context ? `| Context: ${JSON.stringify(context)}` : '');
  }
}

/**
 * Registra una advertencia.
 * @param message El mensaje de advertencia.
 * @param context Información adicional.
 */
export function logWarn(message: string, context?: Record<string, unknown>): void {
  if (isDevelopment) {
    console.warn('[WARN]', message, context ? `| Context: ${JSON.stringify(context)}` : '');
  } else {
    // En producción, podríamos enviar esto a Sentry como un evento de "warning".
    // Sentry.withScope(scope => {
    //   if (context) {
    //     scope.setExtras(context);
    //   }
    //   Sentry.captureMessage(message, 'warning');
    // });
  }
}

const loggingService = {
  error: logError,
  info: logInfo,
  warn: logWarn,
};

export default loggingService;
