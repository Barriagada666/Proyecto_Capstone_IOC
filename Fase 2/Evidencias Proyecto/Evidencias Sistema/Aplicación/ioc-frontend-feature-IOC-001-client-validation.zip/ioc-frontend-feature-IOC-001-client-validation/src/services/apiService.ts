import axios, { AxiosInstance } from "axios";
import type { StartProcessResponse, EtlJobStatusDto } from "../types/api";

let tokenProvider: (() => Promise<string | null> | string | null) | null = null;
let signOutHandler: (() => Promise<void> | void) | null = null;

export function setTokenProvider(provider: typeof tokenProvider) {
  tokenProvider = provider;
}

export function setSignOut(handler: typeof signOutHandler) {
  signOutHandler = handler;
}

const viteBase = import.meta.env?.VITE_API_BASE_URL;
const nodeBase = typeof process !== 'undefined' ? process.env?.VITE_API_BASE_URL : undefined;
const apiBaseURL = nodeBase || viteBase || "";

const client: AxiosInstance = axios.create({ baseURL: apiBaseURL });

client.interceptors.request.use(async (config) => {
  if (tokenProvider) {
    try {
      const maybe = tokenProvider();
      const token = maybe instanceof Promise ? await maybe : maybe;
      if (token) {
        config.headers = config.headers ?? {};
        (config.headers as Record<string, string>).Authorization = `Bearer ${token}`;
      }
    } catch {
      // ignore token errors
    }
  }
  return config;
});

client.interceptors.response.use(
  (res) => res,
  async (error) => {
    const status = error?.response?.status as number | undefined;
    if ((status === 401 || status === 403) && signOutHandler) {
      try { await signOutHandler(); } catch {
        // ignore signOut errors
      }
    }
    return Promise.reject(error);
  },
);

export async function startEtlProcess(file: File, opts?: { signal?: AbortSignal }): Promise<StartProcessResponse> {
  const form = new FormData();
  form.append("file", file);
  const res = await client.post<StartProcessResponse>("/api/etl/start-process", form, {
    signal: opts?.signal,
    headers: { Accept: "application/json" },
  });
  return res.data;
}

export async function getEtlJobStatus(jobId: string, opts?: { signal?: AbortSignal }): Promise<EtlJobStatusDto> {
  const res = await client.get<EtlJobStatusDto>(`/api/etl/jobs/${encodeURIComponent(jobId)}/status`, {
    signal: opts?.signal,
    headers: { Accept: "application/json" },
  });
  return res.data;
}

export default { setTokenProvider, setSignOut, startEtlProcess, getEtlJobStatus };
