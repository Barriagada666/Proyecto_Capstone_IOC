## IOC-001: Cargar y validar un archivo CSV con datos de producción
*   **Estado:** 🟡 **En Progreso**
*   **Objetivo de Negocio (El "Para Qué"):** Permitir a los administradores cargar archivos de producción de forma segura, obteniendo feedback inmediato sobre la validez y el estado del procesamiento.
*   **Criterios de Aceptación Clave:**
    *   La interfaz permite seleccionar y subir un archivo CSV.
    *   El sistema rechaza archivos con formato incorrecto.
    *   Se muestra una notificación de éxito o error al finalizar la carga.

### Desglose Técnico y Verificación

*   **Resumen de la Implementación:**
    *   **Backend:** ✅ **Terminado.** Se ha construido un pipeline de ETL asincrónico con endpoints para iniciar el procesamiento (`POST /api/etl/start-process`) y consultar el estado (`GET /api/etl/jobs/{jobId}/status`).
    *   **Frontend:** ✅ **UI Completada.** La vista de Ingesta de Datos está construida con componentes reutilizables y manejo de estados (carga, error, vacío), pero actualmente utiliza datos simulados.

*   **Archivos Clave:**
    *   **Backend:** `com.cambiaso.ioc.controller.EtlController`, `com.cambiaso.ioc.service.EtlProcessingService`.
    *   **Frontend:** `src/pages/admin/DataIngestionPage.tsx`, `src/components/admin/DataUploadDropzone.tsx`.

*   **Trabajo Pendiente (Integración Frontend):**
    1.  **Crear Capa de Servicio API:** Implementar un servicio (`src/services/apiService.ts`) que encapsule las llamadas a los endpoints del backend, incluyendo la inyección automática del token de autenticación de Supabase.
    2.  **Definir Tipos de Datos:** Crear un archivo (`src/types/api.ts`) con las interfaces TypeScript que correspondan a los DTOs del backend (`StartProcessResponse`, `EtlJobStatusDto`, etc.).
    3.  **Conectar Subida de Archivos:** Refactorizar `DataIngestionPage.tsx` para que llame al nuevo servicio API al subir un archivo, manejando la respuesta asíncrona.
    4.  **Implementar Sondeo de Estado (Polling):** Al recibir el `jobId` de la respuesta, iniciar un `setInterval` para consultar periódicamente el endpoint de estado del job hasta que este finalice.
    5.  **Actualizar UI con Datos Reales:** Usar la respuesta del sondeo para actualizar la tabla de historial en tiempo real y mostrar notificaciones de éxito o fallo basadas en la respuesta del backend.

*   **Commit(s) de Referencia:**
    *   **Backend:** `[hash-del-commit-backend]` - `feat(etl): implementa pipeline de ingesta asincrónico`
    *   **Frontend (UI):** `fa8aa8b` - `feat(admin): Implementar y refactorizar vista de ingesta de datos`
