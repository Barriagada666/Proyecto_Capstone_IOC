# 📄 PROMPT 3: Merger - Project Summary Synchronizer

## 1. CONFIGURACIÓN

**Contexto**: Ambos módulos (Backend y Frontend) generaron documentos en paralelo.

**Objetivo**: Fusionar `project-summary-backend.md` y `project-summary-frontend.md` en un único `project-summary.md` completo.

**Ubicación**: Carpeta `@.gemini/` (compartida o en repo raíz).

---

## 2. MANDATO OPERATIVO

**Tu Rol**: Document Merger con prioridad en mantener coherencia.

**Tu Responsabilidad**:
1. Leer ambos archivos generados
2. Fusionar secciones sin duplicar contenido
3. Resolver conflictos (Backend tiene prioridad en arquitectura, Frontend en UI)
4. Generar documento final sincronizado

---

## 3. PROTOCOLO DE FUSIÓN

### FASE 1: Validación de Archivos

```bash
# Buscar archivos en:
BACKEND_FILE = "@.gemini/project-summary-backend-complete.md"
FRONTEND_FILE = "@.gemini/project-summary-frontend-complete.md"

# Validar:
- ¿Existen ambos archivos? → ✅ Continuar
- ¿Falta alguno? → ❌ ERROR (mostrar cuál falta)
- ¿Ambos tienen metadata válida? → ✅ Continuar
```

**Si falta algún archivo**:

```markdown
❌ ERROR: Archivos Incompletos

Archivos encontrados:
- Backend: [✅ / ❌]
- Frontend: [✅ / ❌]

🔧 Acción:
- Si falta Backend → Ejecutar "Backend - Project Summary Generator"
- Si falta Frontend → Ejecutar "Frontend - Project Summary Completer"

DETENER EJECUCIÓN
```

---

### FASE 2: Estrategia de Merge

#### Reglas de Fusión por Sección:

| Sección | Fuente Prioritaria | Acción |
|---------|-------------------|--------|
| **1. Contexto del Proyecto** | Backend (arquitectura) + Frontend (UX) | Combinar ambas |
| **2. Arquitectura** | Backend | Usar Backend, agregar diagrama frontend si existe |
| **3.1 Frontend Stack** | Frontend | Usar Frontend completo |
| **3.2 Backend Stack** | Backend | Usar Backend completo |
| **4. API Endpoints** | Backend | Usar Backend, validar con llamadas de Frontend |
| **5. Seguridad** | Backend | Usar Backend |
| **6. Variables de Entorno** | Ambos | Separar en 6.1 (Frontend) y 6.2 (Backend) |
| **7. Deployment** | Ambos | Separar en 7.1 (Frontend) y 7.2 (Backend) |
| **8. Testing** | Ambos | Separar en 8.1 (Frontend) y 8.2 (Backend) |
| **9. Monitoreo** | Backend | Usar Backend |
| **10. Documentación** | Ambos | Combinar |

#### Resolución de Conflictos:

```typescript
// Si ambos completaron la misma sección:

if (seccion.completadaPorBackend && seccion.completadaPorFrontend) {
  if (seccion.tipo === "ARQUITECTURA") {
    usar(backend.contenido);
  } else if (seccion.tipo === "UI") {
    usar(frontend.contenido);
  } else {
    combinar(backend.contenido, frontend.contenido);
  }
}
```

---

### FASE 3: Generación del Documento Final

**Estructura**:

```markdown
# Resumen Técnico del Proyecto: [NOMBRE]

> **Generado por**: Backend + Frontend Modules (Merged)  
> **Versión**: 1.0-FULL  
> **Estado**: ✅ COMPLETE

<!-- SECCIONES 1-12: Contenido fusionado -->

---

## METADATA PARA SINCRONIZACIÓN

```yaml
generated_by: "Backend + Frontend Modules (Merged)"
source_files:
  - "project-summary-backend.md"
  - "project-summary-frontend.md"
version: "1.0-FULL"
status: "COMPLETE"
merged_at: "[ISO 8601]"
backend_analyzed: "[Fecha del archivo backend]"
frontend_analyzed: "[Fecha del archivo frontend]"
```

---

## 13. Changelog del Documento

| Versión | Fecha | Autor | Cambios |
|---------|-------|-------|---------|
| 1.0-BACKEND | [De metadata backend] | Backend Module | Generación backend |
| 1.0-FRONTEND | [De metadata frontend] | Frontend Module | Generación frontend |
| **1.0-FULL** | **[Ahora]** | **Merger Module** | **Fusión final** |
```

---

## 4. VALIDACIÓN FINAL

**Checklist**:

```markdown
✅ Checklist de Fusión

### Completitud
- [ ] Todas las secciones de backend están presentes
- [ ] Todas las secciones de frontend están presentes
- [ ] No hay placeholders "<!-- FRONTEND: completar -->" sin resolver
- [ ] No hay placeholders "<!-- BACKEND: completar -->" sin resolver

### Consistencia
- [ ] No hay duplicación de contenido
- [ ] Secciones numeradas correctamente (1-13)
- [ ] Referencias cruzadas son correctas
- [ ] Metadata actualizada con fechas de ambos archivos

### Calidad
- [ ] Formato markdown válido
- [ ] Tablas bien formadas
- [ ] Diagramas ASCII correctos
- [ ] No hay conflictos sin resolver
```

---

## 5. REPORTE DE FUSIÓN

```markdown
## 📊 REPORTE DE FUSIÓN

**Documento Final**: `@.gemini/project-summary.md`  
**Fecha de Merge**: [ISO 8601]

---

### Estadísticas

**Fuente Backend**:
- Fecha de generación: [Extraer de metadata]
- Secciones aportadas: [X]
- Tamaño: [Y] líneas

**Fuente Frontend**:
- Fecha de generación: [Extraer de metadata]
- Secciones aportadas: [Z]
- Tamaño: [W] líneas

**Documento Final**:
- Total de secciones: 13
- Total de líneas: [X+Y+Z] aprox.
- Conflictos resueltos: [N]

---

### Conflictos Resueltos

[SI HUBO CONFLICTOS]:
1. **Sección [X]**: Ambos módulos completaron esta sección
   - ✅ Resolución: [Usé backend / Usé frontend / Combiné ambas]

[SI NO HUBO CONFLICTOS]:
✅ No se detectaron conflictos. Fusión limpia.

---

### Próximos Pasos

1. ✅ Revisar el documento final: `@.gemini/project-summary.md`
2. ✅ Validar secciones críticas (Arquitectura, API, Seguridad)
3. ✅ Eliminar archivos fuente (opcional):
   ```bash
   rm @.gemini/project-summary-backend.md
   rm @.gemini/project-summary-frontend.md
   ```
4. ✅ Compartir con el equipo

---

**Merge completado exitosamente** ✅
```

---

## 6. COMANDOS ÚTILES

**Ejecutar el Merge**:

```bash
# Opción 1: Manualmente (si ambos archivos existen)
gemini-cli < @.gemini/prompts/merge-project-summary.md

# Opción 2: Automatizar (script bash)
./scripts/generate-full-summary.sh
```

**Script de Automatización** (crear como `scripts/generate-full-summary.sh`):

```bash
#!/bin/bash

echo "🚀 Generando documentación completa..."

# Ejecutar Backend
echo "📦 Analizando Backend..."
cd ioc-backend
gemini-cli < @.gemini/prompts/generate-project-summary-backend.md > @.gemini/project-summary-backend.md

# Ejecutar Frontend
echo "🎨 Analizando Frontend..."
cd ../ioc-frontend
gemini-cli < @.gemini/prompts/complete-project-summary-frontend.md > @.gemini/project-summary-frontend.md

# Fusionar
echo "🔀 Fusionando documentos..."
cd ..
gemini-cli < @.gemini/prompts/merge-project-summary.md > @.gemini/project-summary.md

echo "✅ Documentación completa generada en: @.gemini/project-summary.md"
```

---

## 7. MANEJO DE ERRORES

**Error: Archivos con versiones incompatibles**:

```markdown
⚠️ ADVERTENCIA: Versiones Incompatibles

Backend version: [X]
Frontend version: [Y]

Estos archivos pueden estar desincronizados.

🔧 Recomendación:
- Regenerar ambos archivos en la misma sesión
- O continuar con precaución

¿Continuar? (S/N)
```

---

