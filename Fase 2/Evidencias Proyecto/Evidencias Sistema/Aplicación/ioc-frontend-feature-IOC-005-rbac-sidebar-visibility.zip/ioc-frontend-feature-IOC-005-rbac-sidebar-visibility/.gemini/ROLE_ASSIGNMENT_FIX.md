# ✅ Corrección: Asignación de Roles de Usuario

## Problema Identificado

El código en `src/pages/admin/users/list.tsx` intentaba actualizar los roles de un usuario enviando el campo `roles` en el body de las peticiones PUT/POST a `/api/v1/admin/users/{id}`, pero **el backend NO procesa este campo** porque:

1. El DTO `UsuarioUpdateRequest` no tiene la propiedad `roles`
2. El servicio `UserAdminService.update` no modifica las asignaciones de roles
3. El backend **ignora silenciosamente** el campo `roles` en estas peticiones

**Resultado:** Los roles no se actualizaban, aunque la API respondía con éxito 200.

## Solución Implementada

Se implementó el flujo correcto documentado en `.gemini/frontend-role-agent.md`:

### 1. Nuevo Servicio: `roleAssignmentService.ts`

Se creó un servicio dedicado (`src/services/roleAssignmentService.ts`) que:

- **Obtiene los roles actuales** del usuario con `GET /api/v1/admin/users/{id}`
- **Calcula las diferencias** entre roles actuales y deseados (toAdd, toRemove)
- **Resuelve roleId** para cada nombre de rol desde la lista de roles disponibles
- **Asigna roles nuevos** con `POST /api/v1/admin/assignments/users/{userId}/roles/{roleId}`
- **Remueve roles antiguos** con `DELETE /api/v1/admin/assignments/users/{userId}/roles/{roleId}`
- **Verifica el estado final** y reporta resultados detallados

#### Funciones principales:

```typescript
syncUserRoles(options: SyncRolesOptions): Promise<RoleChangeResult>
formatRoleChangeResult(result: RoleChangeResult): string
```

### 2. Actualización de `list.tsx`

Se modificaron tres handlers críticos:

#### `handleSaveRoles` (Modal de asignación de roles)
- ✅ Ahora usa `syncUserRoles` con los endpoints correctos
- ✅ Obtiene el token JWT de Supabase
- ✅ Muestra notificaciones detalladas del progreso
- ✅ Reporta éxitos parciales si algunos roles fallan

#### `handleCreateSubmit` (Crear nuevo usuario)
- ✅ **Paso 1:** Crea el usuario SIN el campo `roles` en el payload
- ✅ **Paso 2:** Asigna roles usando `syncUserRoles` después de la creación
- ✅ Maneja errores en cada paso independientemente

#### `handleUpdateSubmit` (Actualizar usuario existente)
- ✅ **Paso 1:** Actualiza datos del usuario SIN el campo `roles` en el payload
- ✅ **Paso 2:** Sincroniza roles usando `syncUserRoles`
- ✅ Notifica al usuario sobre cada operación

## Cambios Técnicos

### Archivos Creados
- `src/services/roleAssignmentService.ts` - Servicio de sincronización de roles

### Archivos Modificados
- `src/pages/admin/users/list.tsx` - Actualización de handlers

### Endpoints Correctos Utilizados

| Operación | Endpoint | Método |
|-----------|----------|--------|
| Obtener usuario | `/api/v1/admin/users/{id}` | GET |
| Crear usuario | `/api/v1/admin/users` | POST |
| Actualizar usuario | `/api/v1/admin/users/{id}` | PUT |
| **Asignar rol** | `/api/v1/admin/assignments/users/{userId}/roles/{roleId}` | **POST** |
| **Remover rol** | `/api/v1/admin/assignments/users/{userId}/roles/{roleId}` | **DELETE** |
| Listar roles | `/api/v1/admin/roles` | GET |

## Comportamiento Mejorado

### Antes ❌
- Enviaba `{ roles: ["ADMIN", "GERENTE"] }` en PUT
- Backend ignoraba el campo silenciosamente
- Frontend mostraba "éxito" pero roles no cambiaban
- Usuario confundido sin feedback real

### Ahora ✅
- Separa actualización de datos de usuario y sincronización de roles
- Usa endpoints dedicados para asignación/remoción
- Notificaciones en tiempo real: "Creando usuario...", "Asignando roles..."
- Reporta éxitos parciales: "Usuario creado pero algunos roles fallaron: 2"
- Logs detallados en consola para debugging

## Flujo de Roles (Ejemplo)

```typescript
// Usuario actual tiene: ["USER", "SUPERVISOR"]
// Usuario desea: ["ADMIN", "GERENTE"]

// 1. Calculate diff:
toAdd = ["ADMIN", "GERENTE"]
toRemove = ["USER", "SUPERVISOR"]

// 2. Resolve IDs:
ADMIN -> roleId: 2
GERENTE -> roleId: 5
USER -> roleId: 1
SUPERVISOR -> roleId: 3

// 3. Execute:
POST /api/v1/admin/assignments/users/7/roles/2  ✅
POST /api/v1/admin/assignments/users/7/roles/5  ✅
DELETE /api/v1/admin/assignments/users/7/roles/1 ✅
DELETE /api/v1/admin/assignments/users/7/roles/3 ✅

// 4. Result:
// Usuario ahora tiene: ["ADMIN", "GERENTE"]
```

## Manejo de Errores

El servicio maneja varios escenarios:

- **Token inválido/expirado:** Muestra error y redirige a login
- **Rol inexistente:** Reporta qué rol no se encontró
- **Fallo parcial:** Muestra qué roles se asignaron/removieron correctamente
- **Error de red:** Logs detallados y mensaje amigable al usuario

## Testing

### Casos de Prueba Recomendados

1. ✅ Crear usuario sin roles
2. ✅ Crear usuario con múltiples roles
3. ✅ Actualizar usuario agregando roles
4. ✅ Actualizar usuario removiendo roles
5. ✅ Actualizar usuario reemplazando todos los roles
6. ✅ Asignar rol desde modal de roles
7. ✅ Verificar comportamiento con rol inexistente
8. ✅ Verificar comportamiento sin token de autenticación

## Notas de Implementación

- **Idempotencia:** El backend verifica existencia antes de insertar
- **Paralelismo:** Operaciones POST/DELETE se ejecutan en paralelo para velocidad
- **Atomicidad:** No existe transacción atómica (limitación del backend actual)
- **Consistencia:** Se verifica estado final y se muestra al usuario

## Próximos Pasos (Opcional)

Si se requiere atomicidad o una única operación:

1. Modificar `UsuarioUpdateRequest` en backend para incluir `List<String> roles`
2. Actualizar `UserAdminService.update` para reconciliar roles
3. Implementar tests unitarios en backend
4. Simplificar frontend a una única llamada PUT

Por ahora, la solución actual es **robusta, funcional y no requiere cambios en el backend**.

---

**Fecha:** 2025-11-03  
**Autor:** GitHub Copilot  
**Referencia:** `.gemini/frontend-role-agent.md`

