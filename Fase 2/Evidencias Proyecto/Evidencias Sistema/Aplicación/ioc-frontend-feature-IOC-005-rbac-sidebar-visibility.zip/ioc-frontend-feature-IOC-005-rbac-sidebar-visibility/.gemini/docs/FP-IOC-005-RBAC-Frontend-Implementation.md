# Feature Plan: FP-IOC-005 - RBAC en Frontend (Visibilidad y Redirección)

**Problema:**
Actualmente, la interfaz de usuario del frontend no aplica ningún control de acceso basado en roles (RBAC) para la navegación. Todos los usuarios autenticados ven los mismos elementos en el menú lateral, independientemente de sus roles. Además, la página de inicio (`/`) es una página genérica que no redirige al usuario a un dashboard relevante según su perfil, lo que resulta en una experiencia de usuario subóptima.

**Necesidad:**
Implementar un sistema de RBAC en el frontend para:
1.  **Redirigir automáticamente** a los usuarios desde la ruta raíz (`/`) a un dashboard específico basado en sus roles (ej. `ADMIN`/`GERENTE` a `/dashboards/gerencial`, `ANALISTA` a `/dashboards`).
2.  **Controlar la visibilidad de los elementos del menú lateral** (`AppSidebar.tsx`), mostrando solo aquellos enlaces a los que el usuario tiene acceso según sus roles.

**Prerrequisito Crítico:**
El hook `useAuth` (ubicado en `src/hooks/useAuth.ts`) **debe exponer un array de strings con los roles del usuario actual** (ej. `user.roles: ['ADMIN', 'GERENTE']`). Si este no es el caso, el agente de IA deberá investigar y modificar `useAuth` primero para obtener esta información del backend.

---

### **Solución Detallada (Plan de Ejecución para Agente de IA)**

**Objetivo General:** Implementar RBAC basado en roles para la navegación y visibilidad del menú.

**Fase 1: Redireccionamiento Inteligente desde la Página de Inicio (`Home.tsx`)**

*   **Archivo Objetivo:** `src/pages/Dashboard/Home.tsx`
*   **Descripción:** Transformar el componente `Home` en un componente de redirección que, al cargar, evalúa los roles del usuario y lo envía a la ruta más apropiada.
*   **Pasos:**
    1.  **Leer `src/pages/Dashboard/Home.tsx`** para entender su estructura actual.
    2.  **Modificar `src/pages/Dashboard/Home.tsx`:**
        *   **Importar:** `useEffect`, `useNavigate` de `react-router-dom`, `useAuth` de `../../hooks/useAuth`, y `Spinner` de `../../components/ui/Spinner`.
        *   **Lógica:**
            *   Dentro del componente `Home`, usar `const { user, isLoading } = useAuth();` y `const navigate = useNavigate();`.
            *   Implementar un `useEffect` que se ejecute cuando `user` o `isLoading` cambien.
            *   Dentro del `useEffect`:
                *   Si `isLoading` es `true` o `user` es `null`, retornar (esperar a que cargue la autenticación).
                *   Obtener los roles del usuario: `const roles = user.roles || [];`.
                *   **Condiciones de Redirección (por prioridad):**
                    *   Si `roles.includes('ADMIN') || roles.includes('GERENTE')`, redirigir a `/dashboards/gerencial` (`navigate('/dashboards/gerencial', { replace: true })`).
                    *   Si `roles.includes('ANALISTA')`, redirigir a `/dashboards` (`navigate('/dashboards', { replace: true })`).
                    *   **Fallback:** Si no coincide con ningún rol específico, redirigir a `/account` (`navigate('/account', { replace: true })`).
        *   **Renderizado:** El componente `Home` solo debe renderizar un `Spinner` a pantalla completa mientras `isLoading` es `true` o `user` es `null`.

**Fase 2: Control de Visibilidad del Menú Lateral (`AppSidebar.tsx`)**

*   **Archivo Objetivo:** `src/layout/AppSidebar.tsx`
*   **Descripción:** Modificar la definición de los elementos del menú para incluir los roles requeridos y filtrar la lista de elementos a renderizar basándose en los roles del usuario actual.
*   **Pasos:**
    1.  **Leer `src/layout/AppSidebar.tsx`** para entender su estructura actual.
    2.  **Modificar la Interfaz `NavItem`:**
        *   Añadir la propiedad `requiredRoles?: string[];` a la interfaz `NavItem`.
        *   Añadir la misma propiedad `requiredRoles?: string[];` a la interfaz de los `subItems` dentro de `NavItem`.
    3.  **Importar `useAuth`:** Añadir `import { useAuth } from "../hooks/useAuth";` al principio del archivo.
    4.  **Obtener Roles del Usuario:** Dentro del componente `AppSidebar`, usar `const { user } = useAuth();` y definir `const userRoles = user?.roles || [];`.
    5.  **Actualizar `navItems` y `adminItems`:**
        *   Para cada objeto `NavItem` (y sus `subItems`), añadir la propiedad `requiredRoles` con un array de strings que representen los roles que tienen permiso para ver ese elemento.
        *   **Ejemplos:**
            *   `{ name: "Dashboards Analíticos", path: "/dashboards", requiredRoles: ["ADMIN", "GERENTE", "ANALISTA"] }`
            *   `{ name: "Dashboard Gerencial", path: "/dashboards/gerencial", requiredRoles: ["ADMIN", "GERENTE"] }`
            *   `{ name: "Mi Cuenta", path: "/account", requiredRoles: ["ADMIN", "GERENTE", "ANALISTA"] }`
            *   `{ name: "Admin", requiredRoles: ["ADMIN"], subItems: [...] }` (y cada sub-item de admin también con `requiredRoles: ["ADMIN"]`).
            *   Si un elemento no tiene `requiredRoles`, se asume que es visible para todos los usuarios autenticados.
    6.  **Implementar Lógica de Filtrado:**
        *   Crear una función helper (ej. `hasAccess(itemRoles: string[] | undefined, userRoles: string[]): boolean`) que devuelva `true` si el usuario tiene al menos uno de los roles requeridos por el elemento del menú.
        *   Antes de llamar a `renderMenuItems`, filtrar los arrays `navItems` y `adminItems` usando esta función:
            ```typescript
            const filteredNavItems = navItems.filter(item => hasAccess(item.requiredRoles, userRoles));
            const filteredAdminItems = adminItems.filter(item => hasAccess(item.requiredRoles, userRoles));
            ```
        *   Asegurarse de que los `subItems` también se filtren si el elemento principal tiene submenús.
    7.  **Renderizar Menús Filtrados:** En la sección `return` del componente `AppSidebar`, usar `renderMenuItems(filteredNavItems, "main")` y `renderMenuItems(filteredAdminItems, "admin")`.

---

**Verificación Final:**
Después de la implementación, el agente de IA debe verificar que:
*   Un usuario con rol `ANALISTA` es redirigido a `/dashboards` y solo ve "Dashboards Analíticos" y "Mi Cuenta" en el menú.
*   Un usuario con rol `GERENTE` (o `ADMIN`) es redirigido a `/dashboards/gerencial` y ve "Dashboard Gerencial", "Dashboards Analíticos", "Mi Cuenta" y posiblemente la sección "Administración" (si tiene el rol `ADMIN`).
*   Los usuarios sin roles específicos son redirigidos a `/account`.
