# Informe de Implementación: FP-IOC-006 - RBAC Granular en Frontend

**Problema:**
El plan de RBAC actual del frontend se basa en roles (`ADMIN`, `GERENTE`, `ANALISTA`), lo cual es una abstracción de alto nivel. El backend, sin embargo, ha implementado un sistema de control de acceso mucho más granular basado en permisos específicos (`DASHBOARD_VIEW`, `USER_WRITE`, etc.). Continuar usando solo roles en el frontend crea una desalineación con el backend, reduce la flexibilidad y no aprovecha el robusto sistema de seguridad ya implementado.

**Necesidad:**
Refactorizar el frontend para que el control de acceso (redireccionamiento, visibilidad de componentes y protección de rutas) se base directamente en la **lista de permisos efectivos** del usuario. Esto alineará perfectamente el frontend con el backend, centralizará la lógica de autorización en el servidor y permitirá un control de la UI mucho más fino y seguro.

**Prerrequisito Crítico:**
El hook `useAuth` (`src/hooks/useAuth.ts`) debe ser modificado para que obtenga y exponga la lista de permisos del usuario. El objeto `user` que devuelve el hook debe contener un array de strings con los permisos.

```typescript
// Resultado esperado del hook useAuth
interface UserProfile {
  // ... otros campos
  roles: string[];
  permissions: string[]; // <--- CRÍTICO: ['DASHBOARD_VIEW', 'USER_READ', ...]
}

const { user, permissions, isLoading } = useAuth();
```

---

### **Solución Detallada (Plan de Ejecución para Agente de IA)**

**Objetivo General:** Implementar un control de acceso granular y de punta a punta basado en permisos.

**Fase 1: Redireccionamiento Inteligente Basado en Permisos (`Home.tsx`)**

*   **Archivo Objetivo:** `src/pages/Dashboard/Home.tsx`
*   **Descripción:** Transformar el componente `Home` para que redirija al usuario basándose en los permisos que posee, en un orden de prioridad.
*   **Pasos:**
    1.  **Modificar `Home.tsx`** para usar `const { user, permissions, isLoading } = useAuth();`.
    2.  Dentro del `useEffect`, la lógica de redirección cambiará a:
        ```typescript
        // Lógica de redirección por prioridad de permiso
        if (permissions.includes('DASHBOARD_EDIT')) { // O un permiso específico para gerencial
          navigate('/dashboards/gerencial', { replace: true });
        } else if (permissions.includes('DASHBOARD_VIEW')) {
          navigate('/dashboards', { replace: true });
        } else if (permissions.includes('USER_READ')) { // Un permiso básico
          navigate('/account', { replace: true });
        } else {
          // Fallback si no tiene permisos de navegación
          navigate('/unauthorized', { replace: true }); // Redirigir a una página de "No Autorizado"
        }
        ```

**Fase 2: Control de Visibilidad del Menú Basado en Permisos (`AppSidebar.tsx`)**

*   **Archivo Objetivo:** `src/layout/AppSidebar.tsx`
*   **Descripción:** Modificar los elementos del menú para que su visibilidad dependa de permisos específicos.
*   **Pasos:**
    1.  **Modificar la Interfaz `NavItem`:** Cambiar `requiredRoles` por `requiredPermission: string;` (un solo permiso por simplicidad) o `requiredPermissions: string[];` (más flexible).
    2.  **Actualizar `navItems` y `adminItems`:** Asignar el permiso requerido a cada enlace.
        ```typescript
        const navItems: NavItem[] = [
          {
            name: "Dashboards Analíticos",
            path: "/dashboards",
            requiredPermission: "DASHBOARD_VIEW",
          },
          {
            name: "Dashboard Gerencial",
            path: "/dashboards/gerencial",
            requiredPermission: "DASHBOARD_EDIT", // O un permiso más específico
          },
          // ...
        ];

        const adminItems: NavItem[] = [
          {
            name: "Admin",
            subItems: [
              { name: "Gestión de Usuarios", path: "/admin/usuarios", requiredPermission: "USER_READ" },
              { name: "Gestión de Roles", path: "/admin/roles", requiredPermission: "ROLE_READ" },
              // ...
            ],
          },
        ];
        ```
    3.  **Implementar Lógica de Filtrado:**
        *   Dentro de `AppSidebar`, obtener `const { permissions } = useAuth();`.
        *   Crear una función helper `hasPermission(permission: string): boolean` que verifique si `permissions.includes(permission)`.
        *   Filtrar `navItems` y `adminItems` (y sus `subItems`) antes de renderizarlos, mostrando solo aquellos para los que `hasPermission` devuelva `true`.

**Fase 3: Protección de Rutas a Nivel de Router (`App.tsx` y `ProtectedRoute.tsx`)**

*   **Descripción:** Esta es la capa de seguridad más importante. Evita que un usuario acceda a una URL directamente aunque el enlace del menú esté oculto.
*   **Pasos:**
    1.  **Crear un Nuevo Componente `ProtectedRoute.tsx`:**
        *   **Ruta:** `src/components/auth/ProtectedRoute.tsx`
        *   **Lógica:**
            ```typescript
            import { useAuth } from '../../hooks/useAuth';
            import { Navigate, Outlet } from 'react-router-dom';
            import Spinner from '../../components/ui/Spinner';

            interface ProtectedRouteProps {
              requiredPermission: string;
            }

            const ProtectedRoute = ({ requiredPermission }: ProtectedRouteProps) => {
              const { permissions, isLoading } = useAuth();

              if (isLoading) {
                return <div className="flex h-screen w-full items-center justify-center"><Spinner size="lg" /></div>;
              }

              if (!permissions || !permissions.includes(requiredPermission)) {
                // Usuario no tiene el permiso, redirigir
                return <Navigate to="/unauthorized" replace />;
              }

              // Usuario tiene el permiso, renderizar la ruta hija
              return <Outlet />;
            };

            export default ProtectedRoute;
            ```
    2.  **Modificar el Router en `App.tsx`:**
        *   Envolver las rutas que requieren protección con el nuevo componente `ProtectedRoute`.
        *   **Ejemplo:**
            ```typescript
            // src/App.tsx
            <Routes>
              {/* Rutas Públicas */}
              <Route path="/login" element={<LoginPage />} />
              <Route path="/unauthorized" element={<UnauthorizedPage />} />

              {/* Rutas Protegidas */}
              <Route element={<DefaultLayout />}>
                <Route path="/" element={<Home />} />
                <Route path="/account" element={<AccountPage />} />

                {/* Ruta protegida por permiso DASHBOARD_VIEW */}
                <Route element={<ProtectedRoute requiredPermission="DASHBOARD_VIEW" />}>
                  <Route path="/dashboards" element={<AnalyticalDashboardPage />} />
                </Route>

                {/* Ruta protegida por permiso DASHBOARD_EDIT */}
                <Route element={<ProtectedRoute requiredPermission="DASHBOARD_EDIT" />}>
                  <Route path="/dashboards/gerencial" element={<ManagerialDashboardPage />} />
                </Route>

                {/* Rutas de Admin */}
                <Route element={<ProtectedRoute requiredPermission="USER_READ" />}>
                  <Route path="/admin/usuarios" element={<UserManagementPage />} />
                </Route>
                <Route element={<ProtectedRoute requiredPermission="ROLE_READ" />}>
                  <Route path="/admin/roles" element={<RoleManagementPage />} />
                </Route>
              </Route>
            </Routes>
            ```

---

**Verificación Final:**
*   Un usuario con solo el permiso `DASHBOARD_VIEW` es redirigido a `/dashboards`, solo ve ese enlace en el menú y si intenta acceder a `/admin/usuarios` directamente, es redirigido a `/unauthorized`.
*   Un usuario con `USER_WRITE` pero sin `USER_READ` no debería poder ver la página de gestión de usuarios (demostrando la granularidad).
*   La aplicación es segura tanto a nivel de UI (ocultando enlaces) como a nivel de enrutamiento (bloqueando acceso directo a URLs).