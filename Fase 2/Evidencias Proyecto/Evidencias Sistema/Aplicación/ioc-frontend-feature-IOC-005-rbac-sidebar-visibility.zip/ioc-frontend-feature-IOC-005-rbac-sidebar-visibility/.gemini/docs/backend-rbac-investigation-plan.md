# Investigación y Plan de Acción: RBAC — Backend

**Estado:** ✅ **IMPLEMENTACIÓN COMPLETADA** (ver `RBAC_BACKEND_IMPLEMENTATION_REPORT.md`)  
**Fecha de Implementación:** 16 de Noviembre, 2025  
**Pendiente:** Validación end-to-end con frontend

Resumen breve

Este documento describe el problema detectado en la integración frontend-backend del RBAC (Roles) y propone un plan de investigación y corrección para el equipo backend. El objetivo es permitir que el frontend obtenga de forma segura los roles de un usuario autenticado sin violar las reglas de seguridad del backend.

**ACTUALIZACIÓN:** El backend implementó exitosamente `GET /api/v1/users/me` según lo propuesto. Ver reporte completo en `RBAC_BACKEND_IMPLEMENTATION_REPORT.md`.

Checklist (acciones realizadas)

- [x] Reproducir el fallo en local con cuentas ADMIN y ANALISTA.
- [x] Analizar recursivamente el código backend (controllers/services/repos/security) para entender la protección de rutas y la disponibilidad de roles.
## ✅ Estado de Implementación (Actualización)

**Fecha:** 16 de Noviembre, 2025

El backend **completó exitosamente** la implementación del endpoint `GET /api/v1/users/me` según lo propuesto en este documento.

### Resultados de la Implementación:

- ✅ **Endpoint Implementado:** `GET /api/v1/users/me`
- ✅ **Controller Creado:** `UserController.java`
- ✅ **Tests Completados:** 13 tests (8 unitarios + 5 integración)
- ✅ **Documentación:** OpenAPI/Swagger actualizado
- ✅ **Frontend Actualizado:** `AuthProvider.tsx` consume el nuevo endpoint

### Contrato Confirmado:

```json
{
  "id": 123,
  "email": "user@domain.cl",
  "fullName": "Nombre Completo",
  "supabaseUserId": "uuid-...",
  "roles": ["ADMIN", "ANALISTA", "GERENTE"]
}
```

**Próximo Paso:** Validación end-to-end con usuarios reales en staging/producción.

**Referencia Completa:** Ver `RBAC_BACKEND_IMPLEMENTATION_REPORT.md` para detalles técnicos completos.

---

- [x] Implementar (o exponer) un endpoint seguro `GET /api/v1/users/me` que devuelva el perfil del usuario autenticado con sus roles.
- [x] Añadir pruebas unitarias e integración que validen la nueva ruta y la correcta extracción de roles (13 tests totales).
- [x] Documentar la API y comunicar al frontend el contrato (ej. shape de respuesta JSON).
- [x] Frontend actualizado para consumir `/api/v1/users/me` en `AuthProvider.tsx`.
- [ ] **PENDIENTE:** Validación end-to-end con frontend (pruebas con usuarios ADMIN y ANALISTA).

Contexto y síntesis del problema

- El frontend actualmente intenta obtener los roles de un usuario consultando `/api/v1/admin/users?search={email}`.
- El endpoint `/api/v1/admin/**` está correctamente protegido y requiere rol `ADMIN`.
- Por diseño, usuarios sin rol ADMIN (por ejemplo ANALISTA) no pueden llamar a ese endpoint: la llamada devuelve `403/500 (Access Denied)`.
- Resultado: usuarios no-admin no pueden obtener sus roles mediante esa llamada, y el frontend falla o recurre a fuentes secundarias (JWT) que no siempre contienen los roles.

Necesidad

- El frontend necesita conocer los roles del usuario actual para:
  - Mostrar/ocultar elementos del UI (sidebar, menús, botones).
  - Redirigir automáticamente a páginas adecuadas (por ejemplo, ADMIN → `/admin/ingesta-datos`).

- Esta información debe obtenerse sin exponer endpoints administrativos ni romper RBAC.

Propuesta de solución (visión general)

1. Añadir un endpoint público (autenticado) que devuelva el perfil del usuario conectado (p. ej. `GET /api/v1/users/me`).
   - Este endpoint debe estar protegido por autenticación (token JWT válido), pero no exigir rol ADMIN.
   - Devolverá los roles asociados al usuario (roles: string[]).
   - Implementación segura: encontrar al usuario en la BD por `supabase_user_id` (o `sub` del JWT) y devolver solo su perfil.

2. Alternativa o complemento: asegurar que los roles estén incluidos en el JWT (app_metadata o custom claims).
   - Si el sistema de autenticación (Supabase) puede añadir los roles al token al autenticar al usuario, el frontend puede leer roles directamente desde `session.user` y no necesitar llamadas al backend.
   - Esta opción requiere soporte en la plataforma de autenticación o en un proceso que sincronice cambios de roles hacia los claims.

Recomendación: implementar `GET /api/v1/users/me` como primera medida (menor riesgo y estándar). Añadir roles al JWT es complementario y útil, pero suele implicar coordinación con el auth provider.

Contrato API propuesto

- Endpoint: `GET /api/v1/users/me`
- Auth: JWT Bearer (cualquiera con sesión válida)
- Response 200 (JSON):

```json
{
  "id": 123,
  "email": "admin@domain.cl",
  "fullName": "Primer Segundo Apellido",
  "supabaseUserId": "uuid-...",
  "roles": ["ADMIN","GERENTE"]
}
```

- Errores:
  - 401: token inválido/expirado
  - 404: usuario no encontrado (rare)

Implementación sugerida — Spring Boot (esqueleto)

- Controller (ejemplo simplificado):

```java
@RestController
@RequestMapping("/api/v1")
public class UserController {
  private final UserService userService;

  public UserController(UserService userService) {
    this.userService = userService;
  }

  @GetMapping("/users/me")
  public ResponseEntity<UsuarioResponse> me(@AuthenticationPrincipal Jwt jwt) {
    String supabaseUserId = jwt.getSubject(); // sub claim
    if (supabaseUserId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

    Usuario usuario = userService.findBySupabaseUserId(supabaseUserId);
    if (usuario == null) return ResponseEntity.notFound().build();

    return ResponseEntity.ok(UsuarioResponse.fromEntity(usuario));
  }
}
```

- Service: `findBySupabaseUserId(String supabaseUserId)` debe devolver la entidad `Usuario` incluyendo roles.

- Seguridad (configuración Spring Security):

```java
http
  .authorizeHttpRequests(auth -> auth
    .requestMatchers("/api/v1/admin/**").hasRole("ADMIN")
    .requestMatchers("/api/v1/users/me").authenticated()
    // ... otras reglas
  )
  .oauth2ResourceServer(oauth2 -> oauth2.jwt());
```

Puntos de inspección del código backend (análisis recursivo)

El agente backend debe analizar recursivamente los siguientes elementos y rutas del repo backend (sugerencias):

- Controllers:
  - `src/main/java/**/controller/admin/AdminUserController.java`
  - `src/main/java/**/controller/*` (buscar `UserController`, `Auth`, `Me`, etc.)
- Services:
  - `src/main/java/**/service/**` (buscar `UserService`, `UsuarioService`, `findBySupabaseUserId`)
- Repositories:
  - `src/main/java/**/repository/**` (UserRepository, métodos `findBySupabaseUserId` o `findBySupabaseUserIdIs`)
- Security config:
  - `src/main/java/**/config/**` (WebSecurityConfig, ResourceServer config)
  - Revisar reglas `requestMatchers` que afectan `api/v1/**`
- DTOs/Responses:
  - `src/main/java/**/dto/**` o `response` (UsuarioResponse) — confirmar que `roles` está incluido
- Migrations/DB:
  - Revisar tablas `users`, `user_roles`, `roles` y columnas `supabase_user_id`
- Test code:
  - `src/test/java/**` (buscar tests para AdminUserController)

Tareas concretas para el agente backend (pasos)

1. Ejecutar búsquedas recursivas por strings: `AdminUserController`, `findBySupabaseUserId`, `supabaseUserId`, `requestMatchers("/api/v1/admin`), `UsuarioResponse`, `user_roles`.
2. Validar si existe ya un endpoint similar a `/users/me` o `/auth/me`. Si existe, documentar su contrato y permisos.
3. Si no existe, implementar `GET /api/v1/users/me` en un controller público (auth-only), que resuelva el usuario por `sub` del JWT.
4. Añadir a `UsuarioResponse` la propiedad `roles: String[]` (si no existe).
5. Asegurarse que la lógica del servicio hace el `JOIN` con `user_roles` y `roles` para devolver `roles`.
6. Añadir pruebas automatizadas: unit + integración (mock JWT, response 200/401/404).
7. Añadir documentación OpenAPI/Swagger y ejemplo en la documentación del proyecto para que frontend lo consuma.
8. Desplegar en staging y validar con frontend (login admin y analista).

Cambios frontend esperados (cuando backend esté listo)

- En `src/context/AuthProvider.tsx` cambiar la llamada `fetchUserRoles(user.email, token)` por `GET /api/v1/users/me` usando `session.access_token`.
- Si respuesta 200 → usar `response.roles`.
- Si fallback → intentar leer roles desde JWT claims si existen.

Ejemplo de cliente (fetch):

```ts
const res = await fetch('/api/v1/users/me', { headers: { Authorization: `Bearer ${accessToken}` } });
if (res.ok) {
  const json = await res.json();
  return json.roles || [];
}
return [];
```

Pruebas y validación

- Test manual:
  1. Iniciar sesión con `admin@admin.cl` — validar que `/api/v1/users/me` devuelve roles `ADMIN, ANALISTA, GERENTE` y que frontend redirige a `/admin/ingesta-datos`.
  2. Iniciar sesión con `analista@...` — validar que `/api/v1/users/me` devuelve `ANALISTA` y que frontend muestra/oculta elementos correctamente.
- Test automático:
  - Integration test que mockee JWT para distintos `sub` y verifique respuestas.

Riesgos y notas de seguridad

- No hacer público `/api/v1/admin/**` a usuarios autenticados sin rol ADMIN.
- `GET /api/v1/users/me` solo debe devolver datos del usuario solicitado (no listar otros usuarios).
- Revisar logs y monitoreo para detectar llamadas inusuales.

Entrega y prioridades

Prioridad alta: implementar `GET /api/v1/users/me` y la consulta `findBySupabaseUserId`. Esto soluciona el bloqueo actual del frontend sin cambiar la política de protección de endpoints administrativos.

Si quieres, puedo:

- Generar el patch/PR con el controller + service skeleton pre-llenado (Java files) listo para que el equipo backend los revise.
- Actualizar el frontend `AuthProvider.tsx` para consumir `/api/v1/users/me` en lugar del admin endpoint (ya discutido), y probar la integración localmente.

---

> Nota: no se recomienda exponer los endpoints bajo `/api/v1/admin/**` para lectura general — el diseño propuesto (`/users/me`) es la práctica estándar en aplicaciones con RBAC.

---

Documento creado por: agente de integración (propuesta técnica)

Fecha: 2025-11-16

