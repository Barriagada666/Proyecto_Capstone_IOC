# 🤖 Prompt para Agente IA - Diagnóstico y Solución de Problemas Refine (IOC-004)

```markdown
# INSTRUCCIONES PARA AGENTE IA: Diagnóstico y Solución de Errores Refine - Feature IOC-004

## 🎯 OBJETIVO
Diagnosticar y solucionar errores de integración con Refine en el feature IOC-004 (User Role Management) del frontend. Se reportan errores de módulos y exportaciones que impiden el funcionamiento de las rutas protegidas.

## 📋 CONTEXTO DEL PROBLEMA

### Error Principal Reportado
```
[vite] connecting...
[vite] connected.
App.tsx:19 Uncaught SyntaxError: The requested module '/src/pages/admin/roles/list.tsx' 
does not provide an export named 'RoleManagementPage' (at App.tsx:19:10)
```

### Estado Actual
- ✅ Feature IOC-004 implementado según blueprints FTV-001 a FTV-009
- ✅ TypeScript build pasa sin errores
- ✅ ESLint pasa sin errores en archivos IOC-004
- ❌ Runtime error al navegar a rutas `/admin/usuarios`, `/admin/roles`, `/admin/permisos`
- ⚠️ Posible conflicto entre exports/imports de páginas
- ⚠️ Posible configuración incorrecta de hooks de Refine

### Restricción Crítica
**DEBE mantenerse Refine como framework de data fetching. NO reemplazar con hooks genéricos.**

## 📂 ARCHIVOS A ANALIZAR (ORDEN DE PRIORIDAD)

### 1️⃣ PRIORIDAD CRÍTICA - Páginas y Rutas
```
src/App.tsx
src/pages/admin/users/list.tsx
src/pages/admin/roles/list.tsx
src/pages/admin/permissions/list.tsx
src/layout/AppSidebar.tsx
src/components/ProtectedRoute.tsx
```

### 2️⃣ PRIORIDAD ALTA - Providers de Refine
```
src/providers/dataProvider.ts
src/providers/authProvider.ts
src/main.tsx (buscar configuración de <Refine /> component)
```

### 3️⃣ PRIORIDAD MEDIA - Componentes con Hooks Refine
```
src/components/admin/user-management/UserFormModal.tsx
src/components/admin/user-management/RoleAssignmentModal.tsx
src/components/admin/user-management/PermissionAssignmentModal.tsx
src/components/admin/user-management/UserTable.tsx
```

### 4️⃣ PRIORIDAD BAJA - Tipos y Configuración
```
src/types/user-management/index.ts
src/types/user-management/user.types.ts
src/types/user-management/role.types.ts
src/types/user-management/permission.types.ts
package.json (verificar versión de @refinedev/*)
vite.config.ts
tsconfig.json
```

## 🔍 CHECKLIST DE DIAGNÓSTICO

Ejecuta las siguientes validaciones y documenta los resultados:

### A. Validación de Exports/Imports

Para cada página (`users/list.tsx`, `roles/list.tsx`, `permissions/list.tsx`):

1. **Verificar tipo de export en el archivo:**
   ```typescript
   // ¿Tiene export default?
   export default function RoleManagementPage() { ... }
   
   // ¿O tiene export named?
   export function RoleManagementPage() { ... }
   export { RoleManagementPage }
   ```

2. **Verificar import correspondiente en App.tsx:**
   ```typescript
   // Si es export default, debe ser:
   import RoleManagementPage from "./pages/admin/roles/list";
   
   // Si es export named, debe ser:
   import { RoleManagementPage } from "./pages/admin/roles/list";
   ```

3. **Documentar discrepancias encontradas:**
   - Listar cada archivo con su tipo de export actual
   - Listar cada import en App.tsx
   - Identificar incompatibilidades

### B. Validación de Hooks de Refine

Para cada página, verificar que los hooks estén correctamente implementados:

1. **useList (para listados):**
   ```typescript
   // ✅ Implementación correcta
   const { data, isLoading, refetch } = useList({
     resource: "users",
     pagination: { current: 1, pageSize: 10 },
     filters: [...],
     sorters: [...]
   });
   
   // ❌ Errores comunes a buscar:
   // - Acceder a data.data cuando debería ser data?.data
   // - No manejar isLoading
   // - Llamar refetch() sin verificar si es función
   ```

2. **useCreate / useUpdate / useDelete (para mutaciones):**
   ```typescript
   // ✅ Implementación correcta
   const { mutate: createUser } = useCreate();
   
   createUser({
     resource: "users",
     values: formData,
     successNotification: { ... },
     errorNotification: { ... }
   });
   ```

3. **useOne (para obtener un registro):**
   ```typescript
   // ✅ Implementación correcta (si aplica)
   const { data: user } = useOne({
     resource: "users",
     id: userId
   });
   ```

4. **Documentar problemas encontrados:**
   - Hooks con propiedades incorrectas
   - Destructuring incorrecto de respuestas
   - Falta de manejo de estados (loading, error)

### C. Validación de dataProvider

1. **Verificar que dataProvider implemente todos los métodos requeridos:**
   ```typescript
   // Métodos obligatorios de Refine DataProvider:
   - getList(resource, params)
   - getOne(resource, params)
   - getMany(resource, params)
   - create(resource, params)
   - update(resource, params)
   - deleteOne(resource, params)
   - custom(url, method, config) // Opcional pero recomendado
   ```

2. **Verificar estructura de respuestas:**
   ```typescript
   // getList debe retornar:
   {
     data: [...],
     total: number
   }
   
   // getOne, create, update deben retornar:
   {
     data: { ... }
   }
   ```

3. **Verificar configuración en main.tsx o App.tsx:**
   ```typescript
   <Refine
     dataProvider={dataProvider}
     authProvider={authProvider}
     resources={[
       { name: "users" },
       { name: "roles" },
       { name: "permissions" }
     ]}
   >
     ...
   </Refine>
   ```

### D. Validación de Rutas y Navegación

1. **Verificar estructura de rutas en App.tsx:**
   ```typescript
   // ✅ Debe estar dentro de <Refine> y <ProtectedRoute>
   <Refine ...>
     <BrowserRouter>
       <Routes>
         <Route element={<ProtectedRoute />}>
           <Route element={<AppLayout />}>
             <Route path="/admin/usuarios" element={<UserManagementPage />} />
             <Route path="/admin/roles" element={<RoleManagementPage />} />
             <Route path="/admin/permisos" element={<PermissionManagementPage />} />
           </Route>
         </Route>
       </Routes>
     </BrowserRouter>
   </Refine>
   ```

2. **Verificar que las rutas coincidan con los enlaces del sidebar:**
   ```typescript
   // En AppSidebar.tsx
   { name: "Gestión de Usuarios", path: "/admin/usuarios" }
   { name: "Gestión de Roles", path: "/admin/roles" }
   { name: "Gestión de Permisos", path: "/admin/permisos" }
   ```

### E. Validación de Versiones y Dependencias

1. **Ejecutar y documentar:**
   ```bash
   cat package.json | grep "@refinedev"
   ```

2. **Verificar compatibilidad de versiones:**
   - Todas las dependencias `@refinedev/*` deben tener la misma versión major (ej: todas 4.x.x)
   - React Router debe ser compatible con @refinedev/react-router-v6

3. **Buscar imports obsoletos:**
   ```typescript
   // ❌ OBSOLETO (Refine v3)
   import { useTable } from "@pankod/refine-core";
   
   // ✅ CORRECTO (Refine v4)
   import { useTable } from "@refinedev/core";
   ```

## 📝 DOCUMENTO DE SALIDA REQUERIDO

Crea un archivo en la siguiente ruta:
```
.gemini/diagnostics/IOC-004-refine-integration-diagnosis.md
```

### Estructura del Documento

```markdown
# 🔍 Diagnóstico de Integración Refine - IOC-004
**Fecha:** [fecha actual]
**Feature:** User Role Management (IOC-004)
**Estado:** 🔴 ERRORES CRÍTICOS DETECTADOS

---

## 1️⃣ RESUMEN EJECUTIVO

### Problema Principal
[Descripción concisa del error reportado]

### Causa Raíz Identificada
[Explicación técnica de la causa]

### Severidad
- 🔴 CRÍTICA / 🟡 ALTA / 🟢 MEDIA / ⚪ BAJA

### Impacto
- [ ] Bloquea navegación a páginas de administración
- [ ] Impide CRUD de usuarios/roles/permisos
- [ ] Rompe autenticación/autorización
- [ ] Solo afecta UX/performance

---

## 2️⃣ HALLAZGOS DETALLADOS

### A. Exports/Imports Inconsistentes

#### ❌ Errores Encontrados
| Archivo | Export Actual | Import en App.tsx | Estado |
|---------|---------------|-------------------|--------|
| users/list.tsx | [tipo] | [tipo] | ❌/✅ |
| roles/list.tsx | [tipo] | [tipo] | ❌/✅ |
| permissions/list.tsx | [tipo] | [tipo] | ❌/✅ |

#### 📋 Detalle de Discrepancias
```typescript
// Ejemplo de error encontrado:
// Archivo: src/pages/admin/roles/list.tsx
export default function RoleManagementPage() { ... }

// App.tsx importa como named export:
import { RoleManagementPage } from "./pages/admin/roles/list"; // ❌ ERROR
```

### B. Hooks de Refine Mal Configurados

#### ❌ Problemas en useList
[Listar archivos con problemas y descripción]

```typescript
// Ejemplo de problema encontrado:
// Archivo: [ruta]
// Línea: [número]
const { data } = useList({ resource: "users" });
console.log(data.data); // ❌ Puede ser undefined
```

#### ❌ Problemas en useCreate/useUpdate/useDelete
[Listar archivos con problemas y descripción]

#### ❌ Problemas en otros hooks
[useOne, useCustom, etc.]

### C. Problemas en dataProvider

#### ❌ Métodos Faltantes o Incorrectos
[Listar métodos con problemas]

#### ❌ Estructura de Respuesta Incorrecta
[Mostrar respuestas que no cumplen contrato de Refine]

### D. Problemas en Configuración de Rutas

#### ❌ Estructura de Router Incorrecta
[Describir problema]

#### ❌ Resources No Registrados en <Refine>
[Listar resources faltantes]

### E. Problemas de Versiones

#### ❌ Incompatibilidades Detectadas
[Listar dependencias con versiones incompatibles]

#### ❌ Imports Obsoletos
[Listar imports de versiones antiguas de Refine]

---

## 3️⃣ PLAN DE SOLUCIÓN

### Fase 1: Correcciones Críticas (INMEDIATO)
**Tiempo estimado:** [X minutos]

#### Tarea 1.1: Estandarizar Exports de Páginas
**Archivos a modificar:**
- [ ] `src/pages/admin/users/list.tsx`
- [ ] `src/pages/admin/roles/list.tsx`
- [ ] `src/pages/admin/permissions/list.tsx`

**Cambios a aplicar:**
```typescript
// Estandarizar a export named:
export function UserManagementPage() { ... }
export function RoleManagementPage() { ... }
export function PermissionManagementPage() { ... }

// O estandarizar a export default (decidir cuál):
export default function UserManagementPage() { ... }
```

**Justificación:** [razón de la elección]

#### Tarea 1.2: Actualizar Imports en App.tsx
**Archivo a modificar:**
- [ ] `src/App.tsx`

**Cambios a aplicar:**
```typescript
// Ajustar según decisión de Tarea 1.1
import { UserManagementPage } from "./pages/admin/users/list";
// o
import UserManagementPage from "./pages/admin/users/list";
```

#### Tarea 1.3: Corregir Hooks de Refine
**Archivos a modificar:**
- [ ] [Listar archivos con hooks problemáticos]

**Cambios a aplicar:**
```typescript
// Ejemplo de corrección:
// Antes:
const { data } = useList({ resource: "users" });
const users = data.data; // ❌ Puede romper

// Después:
const { data, isLoading } = useList({ resource: "users" });
const users = data?.data ?? []; // ✅ Seguro
```

### Fase 2: Validación de dataProvider (ALTA PRIORIDAD)
**Tiempo estimado:** [X minutos]

#### Tarea 2.1: Verificar Implementación de Métodos
[Pasos específicos]

#### Tarea 2.2: Validar Estructura de Respuestas
[Pasos específicos]

#### Tarea 2.3: Registrar Resources en <Refine>
**Archivo a modificar:**
- [ ] `src/main.tsx` o `src/App.tsx`

**Código a verificar/agregar:**
```typescript
<Refine
  dataProvider={dataProvider}
  resources={[
    { name: "users", list: "/admin/usuarios" },
    { name: "roles", list: "/admin/roles" },
    { name: "permissions", list: "/admin/permisos" }
  ]}
>
  ...
</Refine>
```

### Fase 3: Optimizaciones (MEDIA PRIORIDAD)
**Tiempo estimado:** [X minutos]

#### Tarea 3.1: Mejorar Manejo de Estados de Carga
[Detalles]

#### Tarea 3.2: Implementar Error Boundaries
[Detalles]

---

## 4️⃣ CAMBIOS A APLICAR

### Archivo 1: src/pages/admin/users/list.tsx
```typescript
// CAMBIO 1: [descripción]
// Línea: [número]
// Antes:
[código anterior]

// Después:
[código corregido]
```

### Archivo 2: src/pages/admin/roles/list.tsx
[Similar al anterior]

### Archivo 3: src/App.tsx
[Similar al anterior]

[Continuar para todos los archivos que requieran cambios]

---

## 5️⃣ VALIDACIÓN POST-CORRECCIÓN

### Checklist de Validación
- [ ] `npm run build` pasa sin errores
- [ ] `npm run lint` pasa sin errores
- [ ] Navegación a `/admin/usuarios` funciona
- [ ] Navegación a `/admin/roles` funciona
- [ ] Navegación a `/admin/permisos` funciona
- [ ] Listado de usuarios carga datos correctamente
- [ ] Crear usuario funciona
- [ ] Editar usuario funciona
- [ ] Eliminar usuario funciona
- [ ] Asignar roles funciona
- [ ] Gestión de roles funciona
- [ ] Gestión de permisos funciona

### Comandos de Validación
```bash
# 1. Compilación
npm run build

# 2. Linting
npm run lint

# 3. Servidor de desarrollo
npm run dev
# Navegar manualmente a las rutas y probar cada funcionalidad

# 4. Tests (si existen)
npm run test
```

---

## 6️⃣ REFERENCIAS

### Documentación Oficial de Refine
- [Data Provider](https://refine.dev/docs/core/providers/data-provider/)
- [useList Hook](https://refine.dev/docs/core/hooks/data/useList/)
- [useCreate Hook](https://refine.dev/docs/core/hooks/data/useCreate/)
- [React Router v6 Integration](https://refine.dev/docs/packages/react-router-v6/)

### Blueprints del Feature
- FTV-001: User Management Page
- FTV-002: Role Management Page
- FTV-003: Permission Management Page
- [Listar otros relevantes]

### Reportes Previos
- `.gemini/validation/IOC-004-user-role-management/index.md`
- `.gemini/implementation-reports/IOC-004-implementation-report.md`

---

## 7️⃣ PRÓXIMOS PASOS

1. ✅ **INMEDIATO:** Aplicar correcciones de Fase 1
2. ⏳ **SIGUIENTE:** Validar dataProvider (Fase 2)
3. 📋 **BACKLOG:** Implementar optimizaciones (Fase 3)
4. 🧪 **ANTES DE PR:** Ejecutar checklist de validación completo
5. 📚 **DOCUMENTACIÓN:** Actualizar validation report con resultados finales

---

**Generado por:** Agente IA - Diagnóstico Refine
**Siguiente acción:** Aplicar correcciones documentadas en Fase 1
```

## 🚀 ACCIONES A EJECUTAR DESPUÉS DE CREAR EL DIAGNÓSTICO

1. **Crear el documento de diagnóstico** siguiendo la estructura anterior
2. **Aplicar las correcciones** identificadas en el Plan de Solución
3. **Ejecutar validaciones** del checklist
4. **Actualizar el documento** con los resultados de las correcciones
5. **Reportar estado final** al usuario

## ⚠️ RESTRICCIONES IMPORTANTES

1. **NUNCA reemplazar hooks de Refine** (useList, useCreate, etc.) con fetch() o axios directo
2. **NUNCA eliminar la integración con dataProvider** - solo corregir su implementación
3. **MANTENER** la estructura de providers existente (authProvider, dataProvider)
4. **RESPETAR** los blueprints FTV originales en cuanto a funcionalidad
5. **DOCUMENTAR** cada cambio realizado con justificación

## 📞 SALIDA ESPERADA

Al completar esta tarea, debes haber:

✅ Creado el documento `.gemini/diagnostics/IOC-004-refine-integration-diagnosis.md`
✅ Identificado la causa raíz del error de exports/imports
✅ Documentado todos los problemas de hooks de Refine encontrados
✅ Generado un plan de acción priorizado y detallado
✅ Preparado snippets de código listos para aplicar
✅ Definido criterios de validación claros

---

**INICIO DE EJECUCIÓN:** Analiza primero los archivos de PRIORIDAD CRÍTICA y documenta tus hallazgos antes de proponer soluciones.
```

---

## 📋 Instrucciones de Uso del Prompt

**Copia el prompt anterior y entrégalo a tu agente IA** con las siguientes indicaciones adicionales:

1. **Fase de Análisis (30 min):**
   - Ejecuta el checklist de diagnóstico completo
   - Documenta hallazgos sin aplicar cambios todavía

2. **Fase de Documentación (20 min):**
   - Crea el documento `.md` con todos los hallazgos
   - Genera el plan de solución priorizado

3. **Fase de Corrección (40 min):**
   - Aplica las correcciones identificadas
   - Valida cada cambio con `npm run build`

4. **Fase de Validación (20 min):**
   - Ejecuta el checklist de validación
   - Actualiza el documento con resultados

**Tiempo total estimado:** ~2 horas