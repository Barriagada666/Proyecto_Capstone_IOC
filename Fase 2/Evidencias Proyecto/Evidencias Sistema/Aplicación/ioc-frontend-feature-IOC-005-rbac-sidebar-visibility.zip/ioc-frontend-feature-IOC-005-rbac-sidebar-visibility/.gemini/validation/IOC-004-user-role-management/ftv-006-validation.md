# Validación FTV-006: Permission Assignment Modal

**Blueprint**: `.gemini/blueprints/frontend/IOC-004-user-role-management/ftv-006-permission-assignment-modal.md`  
**Implementación**: `src/components/admin/user-management/PermissionAssignmentModal.tsx`  
**Fecha de Validación**: 2025-10-28  
**Score**: 60% ⚠️ Aceptable

---

## 📊 Resumen de Validación

| Criterio | Esperado | Implementado | Score | Estado |
|----------|----------|--------------|-------|--------|
| **Funcionalidad Core** | Asignar permisos a rol | ✅ Implementado | 85% | ✅ Excelente |
| **Agrupación por Categoría** | Permisos agrupados | ✅ Implementado | 85% | ✅ Excelente |
| **UI Checkboxes** | Multi-select | ✅ Implementado | 80% | ✔️ Bueno |
| **Calidad de Código** | Sin duplicación | ❌ **DUPLICADO** | 20% | ❌ Crítico |
| **TypeScript** | Props tipadas | ✅ Implementado | 85% | ✅ Excelente |
| **Select All por Categoría** | Checkbox "Todos" | ✅ Implementado | 80% | ✔️ Bueno |
| **Manejo de Estado** | useState correcto | ✅ Implementado | 85% | ✅ Excelente |
| **Tests** | Tests unitarios | ❌ No implementado | 0% | ❌ Faltante |

**Score Global**: **60%** (Promedio ponderado, penalizado por duplicación)

---

## 🚨 ISSUES CRÍTICOS

### 1. Contenido Duplicado (CRÍTICO)

**Problema**: El componente completo aparece 2 veces en el archivo

**Evidencia**:
```
Archivo actual: ~460 líneas
Archivo esperado: ~230 líneas

Estructura:
- Primera instancia de PermissionAssignmentModal (líneas 1-230)
- Segunda instancia IDÉNTICA (líneas 230-460) ← DUPLICADO
```

**Impacto**: 🚨 **CRÍTICO**
- ❌ Archivo 2x más grande de lo necesario
- ❌ Riesgo de bugs (modificar solo una copia)
- ❌ Bundle size inflado
- ❌ Dificulta mantenimiento

**Acción Requerida**: **URGENTE**
```bash
# Pasos:
1. Abrir src/components/admin/user-management/PermissionAssignmentModal.tsx
2. Identificar donde termina la primera instancia completa
3. Eliminar todo el código duplicado desde ahí hasta el final
4. Verificar que queda solo 1 export { PermissionAssignmentModal }
```

**Tiempo estimado**: 5 minutos  
**Responsable**: [Asignar]

---

## ✅ Aspectos Correctamente Implementados (en versión no duplicada)

### 1. Agrupación de Permisos por Categoría (85%)
```typescript
// Agrupar permisos por categoría
const groupedPermissions = availablePermissions.reduce((acc, permission) => {
  const category = permission.category || 'General';
  if (!acc[category]) {
    acc[category] = [];
  }
  acc[category].push(permission);
  return acc;
}, {} as Record<string, Permission[]>);
```

**Validación**: ✅ **EXCELENTE**
- Agrupación dinámica por categoría
- Manejo de permisos sin categoría
- Estructura limpia y mantenible

---

### 2. Select All por Categoría (80%)
```typescript
const handleSelectAllInCategory = (category: string, checked: boolean) => {
  const categoryPermissions = groupedPermissions[category];
  const categoryIds = categoryPermissions.map(p => p.id);
  
  if (checked) {
    setSelectedPermissions(prev => [...new Set([...prev, ...categoryIds])]);
  } else {
    setSelectedPermissions(prev => prev.filter(id => !categoryIds.includes(id)));
  }
};

// Determinar si todos los permisos de una categoría están seleccionados
const isAllCategorySelected = (category: string) => {
  const categoryPermissions = groupedPermissions[category];
  return categoryPermissions.every(p => selectedPermissions.includes(p.id));
};
```

**Validación**: ✅ **EXCELENTE**
- Lógica de select/deselect all correcta
- Uso de Set para evitar duplicados
- Estado indeterminado bien calculado

---

### 3. UI Agrupada con Acordeón (85%)
```typescript
{Object.entries(groupedPermissions).map(([category, permissions]) => (
  <div key={category} className="border-b border-gray-200 dark:border-gray-700 last:border-0">
    <div className="flex items-center p-4 bg-gray-50 dark:bg-gray-800">
      <input
        type="checkbox"
        checked={isAllCategorySelected(category)}
        onChange={(e) => handleSelectAllInCategory(category, e.target.checked)}
        className="w-4 h-4 text-blue-600 rounded"
      />
      <button
        type="button"
        onClick={() => toggleCategory(category)}
        className="flex-1 flex items-center justify-between ml-3 text-left"
      >
        <span className="font-semibold text-gray-900 dark:text-white">
          {category}
        </span>
        <span className="text-sm text-gray-500">
          {permissions.filter(p => selectedPermissions.includes(p.id)).length} / {permissions.length}
        </span>
      </button>
    </div>
    
    {expandedCategories.includes(category) && (
      <div className="p-2">
        {permissions.map(permission => (
          <div key={permission.id} className="flex items-center p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded">
            <input
              type="checkbox"
              id={`permission-${permission.id}`}
              checked={selectedPermissions.includes(permission.id)}
              onChange={() => handleTogglePermission(permission.id)}
              className="w-4 h-4 text-blue-600 rounded"
            />
            <label htmlFor={`permission-${permission.id}`} className="ml-3 flex-1 cursor-pointer">
              <div className="text-sm text-gray-900 dark:text-white">
                {permission.nombre}
              </div>
              {permission.descripcion && (
                <div className="text-xs text-gray-500 dark:text-gray-400">
                  {permission.descripcion}
                </div>
              )}
            </label>
          </div>
        ))}
      </div>
    )}
  </div>
))}
```

**Validación**: ✅ **EXCELENTE**
- Acordeón funcional para expandir/colapsar categorías
- Contador visual de seleccionados (X / Total)
- Checkbox "Select All" por categoría en el header
- Descripción de cada permiso visible
- Hover states para UX

---

### 4. Gestión de Estado (85%)
```typescript
const [selectedPermissions, setSelectedPermissions] = useState<number[]>(
  role?.permissions?.map(p => p.id) || []
);

const [expandedCategories, setExpandedCategories] = useState<string[]>(
  Object.keys(groupedPermissions)
);

const handleTogglePermission = (permissionId: number) => {
  setSelectedPermissions(prev =>
    prev.includes(permissionId)
      ? prev.filter(id => id !== permissionId)
      : [...prev, permissionId]
  );
};

const toggleCategory = (category: string) => {
  setExpandedCategories(prev =>
    prev.includes(category)
      ? prev.filter(c => c !== category)
      : [...prev, category]
  );
};
```

**Validación**: ✅ **EXCELENTE**
- Estado para permisos seleccionados bien manejado
- Estado de categorías expandidas separado
- Inicialización con permisos actuales del rol
- Toggle logic correcta

---

### 5. Guardar Asignación (80%)
```typescript
const handleSave = async () => {
  try {
    await onSave(selectedPermissions);
    onClose();
  } catch (error) {
    toast.error('Error al asignar permisos');
    console.error(error);
  }
};
```

**Validación**: ✅ Bueno
- Callback onSave invocado correctamente
- Cierre automático tras guardar
- Manejo básico de errores

---

## ⚠️ Áreas de Mejora

### 1. URGENTE: Eliminar Duplicación (Prioridad: CRÍTICA)

**Paso a Paso**:
1. Buscar la primera ocurrencia de `export { PermissionAssignmentModal }`
2. Marcar ese punto como fin del componente original
3. Eliminar todo el contenido desde ahí hasta el final del archivo
4. Guardar y verificar compilación

**Validación**:
```bash
# Verificar líneas del archivo
wc -l src/components/admin/user-management/PermissionAssignmentModal.tsx
# Debería mostrar ~230 líneas

# Verificar un solo export
grep -c "export.*PermissionAssignmentModal" src/components/admin/user-management/PermissionAssignmentModal.tsx
# Debería mostrar: 1

npm run build # Debe compilar sin errores
```

---

### 2. Búsqueda de Permisos (Prioridad: MEDIA)

**Mejora Sugerida**: Añadir campo de búsqueda cuando hay muchos permisos

```typescript
const [searchQuery, setSearchQuery] = useState('');

const filteredPermissions = Object.entries(groupedPermissions).reduce((acc, [category, permissions]) => {
  const filtered = permissions.filter(p => 
    p.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.descripcion?.toLowerCase().includes(searchQuery.toLowerCase())
  );
  if (filtered.length > 0) {
    acc[category] = filtered;
  }
  return acc;
}, {} as Record<string, Permission[]>);

// En el render:
<input
  type="text"
  placeholder="Buscar permisos..."
  value={searchQuery}
  onChange={(e) => setSearchQuery(e.target.value)}
  className="w-full px-3 py-2 border rounded-lg mb-4"
/>
```

**Tiempo estimado**: 30 minutos

---

### 3. Botón "Expandir/Colapsar Todo" (Prioridad: BAJA)

**Mejora Sugerida**:
```typescript
const expandAll = () => {
  setExpandedCategories(Object.keys(groupedPermissions));
};

const collapseAll = () => {
  setExpandedCategories([]);
};

// Botones en el header del modal
<div className="flex gap-2 mb-4">
  <button onClick={expandAll} className="text-sm text-blue-600">
    Expandir Todas
  </button>
  <button onClick={collapseAll} className="text-sm text-blue-600">
    Colapsar Todas
  </button>
</div>
```

**Tiempo estimado**: 15 minutos

---

### 4. Tests (Prioridad: ALTA)

**Recomendación**:
```typescript
// PermissionAssignmentModal.test.tsx
describe('PermissionAssignmentModal', () => {
  const mockPermissions = [
    { id: 1, nombre: 'user:create', category: 'Usuarios', descripcion: 'Crear usuarios' },
    { id: 2, nombre: 'user:edit', category: 'Usuarios', descripcion: 'Editar usuarios' },
    { id: 3, nombre: 'role:create', category: 'Roles', descripcion: 'Crear roles' },
  ];
  
  const mockRole = {
    id: 1,
    nombre: 'GERENTE',
    permissions: [{ id: 1, nombre: 'user:create', category: 'Usuarios' }],
  };
  
  it('should group permissions by category', () => {
    render(
      <PermissionAssignmentModal
        isOpen={true}
        onClose={jest.fn()}
        onSave={jest.fn()}
        role={mockRole}
        availablePermissions={mockPermissions}
      />
    );
    
    expect(screen.getByText('Usuarios')).toBeInTheDocument();
    expect(screen.getByText('Roles')).toBeInTheDocument();
  });
  
  it('should select all permissions in category', async () => {
    const user = userEvent.setup();
    render(
      <PermissionAssignmentModal
        isOpen={true}
        onClose={jest.fn()}
        onSave={jest.fn()}
        role={mockRole}
        availablePermissions={mockPermissions}
      />
    );
    
    const usuariosCheckbox = screen.getByLabelText(/Usuarios/i);
    await user.click(usuariosCheckbox);
    
    // Todos los permisos de Usuarios deberían estar seleccionados
    expect(screen.getByLabelText(/user:create/i)).toBeChecked();
    expect(screen.getByLabelText(/user:edit/i)).toBeChecked();
  });
  
  it('should show count of selected permissions', () => {
    render(
      <PermissionAssignmentModal
        isOpen={true}
        onClose={jest.fn()}
        onSave={jest.fn()}
        role={mockRole}
        availablePermissions={mockPermissions}
      />
    );
    
    expect(screen.getByText(/1 \/ 2/)).toBeInTheDocument(); // Usuarios: 1 de 2
  });
});
```

**Tiempo estimado**: 2 horas

---

## 📋 Checklist de Conformidad

### Funcionalidad Core
- [x] Listar permisos disponibles
- [x] Agrupar por categoría
- [x] Checkboxes multi-select
- [x] Pre-seleccionar permisos del rol
- [x] Select all por categoría
- [x] Acordeón expandible/colapsable
- [x] Guardar asignación
- [ ] Sin duplicación ❌

### UX/UI
- [x] Modal responsive
- [x] Contador de seleccionados por categoría
- [x] Descripción de permisos
- [x] Hover states
- [ ] Búsqueda de permisos (mejora futura)
- [ ] Expandir/Colapsar todo (mejora futura)

### Calidad
- [ ] ❌ **CRÍTICO**: Sin duplicación de código
- [x] TypeScript correcto
- [x] Lógica bien estructurada
- [ ] Tests implementados

---

## 🎯 Plan de Acción

### URGENTE (Antes de usar)
1. **Eliminar duplicación completa** (5 minutos) 🚨

### Prioridad ALTA (Después de limpieza)
2. Implementar tests (2 horas)
3. Verificar integración con RoleManagementPage (15 min)

### Prioridad MEDIA
4. Añadir búsqueda de permisos (30 min)

### Prioridad BAJA
5. Botones expandir/colapsar todo (15 min)

---

## 📊 Comparación Blueprint vs Implementación

| Aspecto | Blueprint | Implementación | Match |
|---------|-----------|----------------|-------|
| Tipo | Modal component | Modal ✅ | 100% |
| Agrupación | Por categoría | ✅ Por categoría | 100% |
| Multi-select | Checkboxes | ✅ Checkboxes | 100% |
| Select all | Por categoría | ✅ Sí | 100% |
| Acordeón | Expandible | ✅ Sí | 100% |
| Contador | X / Total | ✅ Sí | 100% |
| Código limpio | Sí | ❌ **DUPLICADO** | 0% |
| Tests | Esperados | ❌ Faltantes | 0% |

**Conformidad Global (funcional)**: 87.5%  
**Conformidad Global (con duplicación)**: 60% ⚠️

---

## ✨ Conclusión

**Estado Actual**: ⚠️ **BLOQUEADO** por duplicación

**Funcionalidad**: ✅ **EXCELENTE** (87.5%) - Este es uno de los componentes mejor diseñados funcionalmente
- Agrupación por categoría bien implementada
- Select all por categoría excelente
- UI con acordeón muy UX-friendly
- Contador visual útil

**Calidad de Código**: ❌ Crítica (20%) - Duplicación completa

**Post-Limpieza**: Componente será **EXCELENTE** (87%), uno de los mejores de la feature

**Tiempo Total**:
- Limpieza urgente: 5 minutos 🚨
- Tests: 2 horas
- Mejoras: 45 minutos

---

**Recomendación**: Limpiar duplicación **INMEDIATAMENTE**. El componente tiene excelente funcionalidad que no debe ser opacada por este issue técnico.
# Validación FTV-005: Role Assignment Modal

**Blueprint**: `.gemini/blueprints/frontend/IOC-004-user-role-management/ftv-005-role-assignment-modal.md`  
**Implementación**: `src/components/admin/user-management/RoleAssignmentModal.tsx`  
**Fecha de Validación**: 2025-10-28  
**Score**: 60% ⚠️ Aceptable

---

## 📊 Resumen de Validación

| Criterio | Esperado | Implementado | Score | Estado |
|----------|----------|--------------|-------|--------|
| **Funcionalidad Core** | Asignar roles a usuario | ✅ Implementado | 80% | ✔️ Bueno |
| **UI Checkboxes** | Multi-select con checkboxes | ✅ Implementado | 75% | ✔️ Bueno |
| **Calidad de Código** | Sin duplicación | ❌ **DUPLICADO + MEZCLADO** | 20% | ❌ Crítico |
| **TypeScript** | Props tipadas | ✅ Implementado | 85% | ✅ Excelente |
| **Manejo de Estado** | useState para selección | ✅ Implementado | 80% | ✔️ Bueno |
| **Integración** | Llamada API correcta | ✅ Implementado | 70% | ⚠️ Aceptable |
| **UX/UI** | Modal responsive | ✅ Implementado | 75% | ✔️ Bueno |
| **Tests** | Tests unitarios | ❌ No implementado | 0% | ❌ Faltante |

**Score Global**: **60%** (Promedio ponderado, fuertemente penalizado por duplicación)

---

## 🚨 ISSUES CRÍTICOS

### 1. Contenido Duplicado + Mezclado con UserFormModal (CRÍTICO)

**Problema**: El archivo tiene 3 problemas simultáneos:
1. ❌ Componente RoleAssignmentModal aparece duplicado
2. ❌ Contiene código de UserFormModal mezclado
3. ❌ Archivo excesivamente grande (~600+ líneas cuando debería tener ~200)

**Evidencia**:
```
Estructura detectada en el archivo:
- Primera instancia de RoleAssignmentModal (líneas 1-200)
- Segunda instancia de RoleAssignmentModal (líneas 200-400) ← DUPLICADO
- Código de UserFormModal mezclado (líneas 400-600) ← CONTAMINACIÓN
```

**Impacto**: 🚨 **CRÍTICO**
- ❌ Confusión extrema para mantenimiento
- ❌ Riesgo alto de bugs (editar versión incorrecta)
- ❌ Bundle size innecesariamente inflado 3x
- ❌ Dificulta code review completamente
- ❌ Posibles conflictos en exports

**Acción Requerida**: **URGENTE - PRIORIDAD 1**
```bash
# Pasos de limpieza:
1. Abrir src/components/admin/user-management/RoleAssignmentModal.tsx
2. Eliminar TODO el código de UserFormModal (no pertenece aquí)
3. Eliminar la segunda instancia de RoleAssignmentModal
4. Mantener SOLO la primera instancia completa de RoleAssignmentModal
5. Verificar que queda solo 1 export { RoleAssignmentModal }
```

**Tiempo estimado**: 10 minutos  
**Responsable**: [Asignar]  
**Bloqueante**: Sí - **NO USAR** hasta limpiar

---

## ✅ Aspectos Correctamente Implementados (en la versión no duplicada)

### 1. Modal de Selección Múltiple (80%)
```typescript
const [selectedRoles, setSelectedRoles] = useState<number[]>(
  user?.roles?.map(r => r.id) || []
);

const handleToggleRole = (roleId: number) => {
  setSelectedRoles(prev => 
    prev.includes(roleId)
      ? prev.filter(id => id !== roleId)
      : [...prev, roleId]
  );
};
```

**Validación**: ✅ Bueno
- Estado local para roles seleccionados
- Toggle functionality correcta
- Inicialización con roles actuales del usuario

---

### 2. UI de Checkboxes (75%)
```typescript
{availableRoles.map(role => (
  <div key={role.id} className="flex items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-800 rounded">
    <input
      type="checkbox"
      id={`role-${role.id}`}
      checked={selectedRoles.includes(role.id)}
      onChange={() => handleToggleRole(role.id)}
      className="w-4 h-4 text-blue-600 rounded"
    />
    <label htmlFor={`role-${role.id}`} className="ml-3 flex-1 cursor-pointer">
      <div className="font-medium text-gray-900 dark:text-white">
        {role.nombre}
      </div>
      {role.descripcion && (
        <div className="text-sm text-gray-500 dark:text-gray-400">
          {role.descripcion}
        </div>
      )}
    </label>
  </div>
))}
```

**Validación**: ✅ Bueno
- Checkboxes funcionales
- Labels asociados correctamente (a11y)
- Hover states para UX
- Muestra descripción de rol

---

### 3. Guardar Asignación (70%)
```typescript
const handleSave = async () => {
  try {
    await onSave(selectedRoles);
    onClose();
  } catch (error) {
    toast.error('Error al asignar roles');
    console.error(error);
  }
};
```

**Validación**: ✅ Aceptable
- Callback onSave invocado con roles seleccionados
- Cierre automático después de guardar
- Manejo básico de errores

---

## ⚠️ Áreas de Mejora

### 1. URGENTE: Limpiar Duplicación y Contaminación (Prioridad: CRÍTICA)

**Paso a Paso**:
1. Hacer backup del archivo actual
2. Identificar la primera instancia completa de RoleAssignmentModal
3. Copiar solo esa instancia a un archivo temporal
4. Sobrescribir el archivo original con la versión limpia
5. Verificar que compile y funcione

**Validación Post-Fix**:
```bash
# Verificar tamaño del archivo
wc -l src/components/admin/user-management/RoleAssignmentModal.tsx
# Debería mostrar ~200 líneas, no 600+

# Verificar que no contiene UserFormModal
grep -i "UserFormModal" src/components/admin/user-management/RoleAssignmentModal.tsx
# No debería encontrar nada

# Verificar que compile
npm run build
```

---

### 2. Optimizar Llamada API (Prioridad: MEDIA)

**Issue**: Si la llamada API se hace directamente con fetch(), debería usar dataProvider

**Recomendación**: Verificar en el componente padre (UserManagementPage) que use:
```typescript
// En UserManagementPage
const handleSaveRoles = async (roleIds: number[]) => {
  if (!selectedUser) return;
  
  // Usar dataProvider.custom en lugar de fetch directo
  await dataProvider.custom({
    url: `admin/users/${selectedUser.id}/roles`,
    method: 'put',
    payload: { roleIds },
  });
  
  toast.success('Roles asignados exitosamente');
  refetch();
};
```

---

### 3. Agrupación de Roles (Prioridad: BAJA)

**Mejora Sugerida**: Si hay muchos roles, agrupar por categoría

```typescript
const groupedRoles = availableRoles.reduce((acc, role) => {
  const category = role.category || 'General';
  if (!acc[category]) acc[category] = [];
  acc[category].push(role);
  return acc;
}, {} as Record<string, Role[]>);

// Render agrupado
{Object.entries(groupedRoles).map(([category, roles]) => (
  <div key={category}>
    <h4 className="font-semibold text-gray-700 dark:text-gray-300 mt-4 mb-2">
      {category}
    </h4>
    {roles.map(role => (
      // Checkbox para cada rol
    ))}
  </div>
))}
```

**Tiempo estimado**: 30 minutos

---

### 4. Tests (Prioridad: ALTA después de limpieza)

**Recomendación**:
```typescript
// RoleAssignmentModal.test.tsx
describe('RoleAssignmentModal', () => {
  const mockRoles = [
    { id: 1, nombre: 'ADMIN', descripcion: 'Administrador' },
    { id: 2, nombre: 'GERENTE', descripcion: 'Gerente de planta' },
  ];
  
  const mockUser = {
    id: 1,
    nombre: 'Juan Pérez',
    roles: [{ id: 1, nombre: 'ADMIN' }],
  };
  
  it('should render with current user roles checked', () => {
    render(
      <RoleAssignmentModal
        isOpen={true}
        onClose={jest.fn()}
        onSave={jest.fn()}
        user={mockUser}
        availableRoles={mockRoles}
      />
    );
    
    const adminCheckbox = screen.getByLabelText(/ADMIN/i);
    expect(adminCheckbox).toBeChecked();
    
    const gerenteCheckbox = screen.getByLabelText(/GERENTE/i);
    expect(gerenteCheckbox).not.toBeChecked();
  });
  
  it('should toggle role selection', async () => {
    const user = userEvent.setup();
    render(
      <RoleAssignmentModal
        isOpen={true}
        onClose={jest.fn()}
        onSave={jest.fn()}
        user={mockUser}
        availableRoles={mockRoles}
      />
    );
    
    const gerenteCheckbox = screen.getByLabelText(/GERENTE/i);
    await user.click(gerenteCheckbox);
    
    expect(gerenteCheckbox).toBeChecked();
  });
  
  it('should call onSave with selected role IDs', async () => {
    const user = userEvent.setup();
    const onSave = jest.fn();
    
    render(
      <RoleAssignmentModal
        isOpen={true}
        onClose={jest.fn()}
        onSave={onSave}
        user={mockUser}
        availableRoles={mockRoles}
      />
    );
    
    await user.click(screen.getByLabelText(/GERENTE/i));
    await user.click(screen.getByText('Guardar'));
    
    expect(onSave).toHaveBeenCalledWith([1, 2]); // ADMIN + GERENTE
  });
});
```

**Tiempo estimado**: 1.5 horas

---

## 📋 Checklist de Conformidad

### Funcionalidad Core
- [x] Mostrar lista de roles disponibles
- [x] Checkboxes para selección múltiple
- [x] Pre-seleccionar roles actuales del usuario
- [x] Guardar selección
- [ ] Sin duplicación de código ❌

### UX/UI
- [x] Modal responsive
- [x] Checkboxes funcionales
- [x] Muestra descripción de roles
- [x] Hover states
- [ ] Agrupación por categoría (opcional)

### Calidad
- [ ] ❌ **CRÍTICO**: Archivo limpio, sin duplicación
- [ ] ❌ **CRÍTICO**: Sin código de otros componentes
- [x] TypeScript correcto
- [ ] Tests implementados

---

## 🎯 Plan de Acción

### URGENTE (Antes de cualquier uso)
1. **Limpiar archivo completamente** (10 minutos)
   - Eliminar UserFormModal mezclado
   - Eliminar duplicación de RoleAssignmentModal
   - Validar que compile

### Prioridad ALTA (Después de limpieza)
2. Verificar integración con UserManagementPage (15 min)
3. Implementar tests (1.5 horas)

### Prioridad MEDIA
4. Refactorizar a dataProvider.custom si usa fetch() (30 min)

### Prioridad BAJA
5. Añadir agrupación de roles (30 min)

---

## 📊 Comparación Blueprint vs Implementación

| Aspecto | Blueprint | Implementación | Match |
|---------|-----------|----------------|-------|
| Tipo | Modal component | Modal ✅ | 100% |
| Multi-select | Checkboxes | ✅ Checkboxes | 100% |
| Pre-selección | Roles actuales | ✅ Sí | 100% |
| Descripción roles | Sí | ✅ Sí | 100% |
| Guardar | API call | ✅ Sí | 100% |
| Código limpio | Sí | ❌ **DUPLICADO + MEZCLADO** | 0% |
| Tests | Esperados | ❌ Faltantes | 0% |

**Conformidad Global (funcional)**: 80%  
**Conformidad Global (con duplicación)**: 60% ⚠️

---

## 🚨 Conclusión

**Estado Actual**: 🚨 **BLOQUEADO** - Archivo contaminado y duplicado

**Funcionalidad**: ✅ Buena (80%) - La lógica core está bien implementada  
**Calidad de Código**: ❌ Crítica (20%) - Duplicación severa + contaminación

**Acción Inmediata**: **DETENER** uso del archivo hasta limpieza completa

**Post-Limpieza**: Componente será **BUENO** (80%), funcional para desarrollo

**Tiempo Total**:
- Limpieza urgente: 10 minutos 🚨
- Tests: 1.5 horas
- Mejoras: 1 hora

---

**Recomendación**: **NO USAR** hasta resolver duplicación. Este es el archivo con el problema más severo de todos los FTVs.

