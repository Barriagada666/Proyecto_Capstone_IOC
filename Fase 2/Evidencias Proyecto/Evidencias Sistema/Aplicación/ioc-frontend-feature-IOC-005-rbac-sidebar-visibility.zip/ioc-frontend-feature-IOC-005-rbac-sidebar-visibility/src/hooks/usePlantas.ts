import { useList } from '@refinedev/core';
import { useEffect, useState } from 'react';
import { Planta } from '../types/user-management';
import { normalizeListResponse } from '../utils/normalizeListResponse';
import { supabase } from '../lib/supabaseClient';

// Simple in-memory cache (module-scoped). TTL configurable.
let cachedPlantas: Planta[] | null = null;
let cacheAt = 0;
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

type UseListPlantasResult = {
  data?: { data?: Planta[] } | Planta[];
  result?: unknown;
  isLoading?: boolean;
  isFetching?: boolean;
  refetch?: () => void;
  query?: { error?: unknown; isError?: boolean };
};

export const usePlantas = () => {
  // Disable the automatic Refine/dataProvider fetch for "plantas" by default.
  // This prevents the app from issuing GET /api/v1/plantas when the backend
  // doesn't expose that endpoint. We still call the hook (rules of hooks)
  // but keep it disabled and rely on the Supabase fallback or manual refetch.
  const listResult = useList({ resource: 'plantas', pagination: { pageSize: 200 }, queryOptions: { enabled: false } }) as unknown as UseListPlantasResult;

  // Normalize different possible shapes returned by providers
  const raw = (listResult.result ?? listResult.data) ?? listResult;
  const fetched = normalizeListResponse<Planta>(raw);

  const now = Date.now();
  const isCacheValid = cachedPlantas !== null && (now - cacheAt) < CACHE_TTL_MS;

  // local state to hold fallback supabase data (so we can return it reactively)
  const [fallbackPlantas, setFallbackPlantas] = useState<Planta[] | null>(null);

  // If fetched returned something and cache is stale or empty, update cache
  if (fetched.length > 0 && (!isCacheValid || (cachedPlantas && cachedPlantas.length !== fetched.length))) {
    cachedPlantas = fetched;
    cacheAt = now;
  }

  // Fallback: if refine returned nothing (fetched is empty) and cache is empty/stale, try a direct supabase query once
  useEffect(() => {
    let mounted = true;
    const tryFallback = async () => {
      const now2 = Date.now();
      const cacheValidNow = cachedPlantas !== null && (now2 - cacheAt) < CACHE_TTL_MS;
      console.debug('[usePlantas] tryFallback triggered', { fetchedLength: fetched.length, cacheValidNow, cachedPlantasLength: cachedPlantas?.length ?? 0 });
      if (fetched.length === 0 && !cacheValidNow) {
        try {
          const { data, error } = await supabase.from('plantas').select('*').order('name', { ascending: true });
          if (!mounted) return;
          if (error) {
            console.debug('[usePlantas] fallback supabase error', error);
            return;
          }
          console.debug('[usePlantas] fallback supabase returned', { length: data?.length ?? 0 });
          if (data && data.length > 0) {
            cachedPlantas = data as Planta[];
            cacheAt = Date.now();
            setFallbackPlantas(data as Planta[]);
          }
        } catch (err) {
          console.debug('[usePlantas] unexpected fallback error', err);
        }
      }
    };

    void tryFallback();
    return () => { mounted = false; };
  }, [fetched.length]);

  // Decide what to return: prefer cache when valid, otherwise the freshly fetched list, otherwise fallback
  const plantas = isCacheValid ? (cachedPlantas as Planta[]) : (fetched.length > 0 ? fetched : (fallbackPlantas ?? []));

  // Derive error state from refine result if available
  const isError = !!(listResult.query && listResult.query.isError) || false;
  const error = listResult.query?.error ?? undefined;

  const refetch = () => {
    // Clear cache so subsequent consumers will use fresh data
    cachedPlantas = null;
    cacheAt = 0;
    setFallbackPlantas(null);
    return listResult.refetch?.();
  };

  return {
    plantas,
    isLoading: listResult.isLoading ?? false,
    isFetching: listResult.isFetching ?? false,
    isError,
    error,
    refetch,
    raw: listResult,
  };
};
