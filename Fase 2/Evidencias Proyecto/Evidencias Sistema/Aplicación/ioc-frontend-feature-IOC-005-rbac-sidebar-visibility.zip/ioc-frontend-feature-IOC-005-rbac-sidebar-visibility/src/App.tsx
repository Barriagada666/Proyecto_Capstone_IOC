import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Refine } from "@refinedev/core";
import { Toaster } from "react-hot-toast";
import { ProtectedRoute } from "./components/auth/ProtectedRoute";
import { RoleProtectedRoute } from "./components/auth/RoleProtectedRoute";
import Account from "./pages/Account";
import SignIn from "./pages/AuthPages/SignIn";
import SignUp from "./pages/AuthPages/SignUp";
import ResetPassword from "./pages/AuthPages/ResetPassword";
import UpdatePassword from "./pages/AuthPages/UpdatePassword";
import NotFound from "./pages/OtherPage/NotFound";
import AppLayout from "./layout/AppLayout";
import Home from "./pages/Dashboard/Home";
import AdminDashboardPage from "./pages/admin/AdminDashboardPage";
import DataIngestionPage from "./pages/admin/DataIngestionPage";
import DashboardsPage from "./pages/DashboardsPage"; // Importar la nueva página
import Blank from "./pages/Blank";
import GerencialDashboardPage from "./pages/GerencialDashboardPage";
// User Role Management Pages
import { UserManagementPage } from "./pages/admin/users/list";
import { RoleManagementPage } from "./pages/admin/roles/list";
import { PermissionManagementPage } from "./pages/admin/permissions/list";
// Refine Providers
import { dataProvider } from "./providers/dataProvider";
import { authProvider } from "./providers/authProvider";

export default function App() {
  return (
    <Refine
      dataProvider={dataProvider}
      authProvider={authProvider}
      resources={[
        { name: "admin/users", meta: { label: "Usuarios" } },
        { name: "admin/roles", meta: { label: "Roles" } },
        { name: "admin/permissions", meta: { label: "Permisos" } },
        // Register plantas resource so hooks like useList({ resource: 'plantas' }) work
        { name: "plantas", meta: { label: "Plantas" } },
      ]}
      options={{
        syncWithLocation: false,
        warnWhenUnsavedChanges: false,
      }}
    >
      <Router>
      <Toaster
        position="top-right"
        reverseOrder={false}
        toastOptions={{
          success: {
            duration: 3000,
          },
          error: {
            duration: 4000,
          },
        }}
      />
      <Routes>
        {/* Rutas Protegidas */}
        <Route element={<ProtectedRoute />}>
          <Route element={<AppLayout />}>
            <Route index path="/" element={<Home />} />
            <Route path="/account" element={<Account />} />

            {/* Dashboards Analíticos - Solo ADMIN y ANALISTA */}
            <Route element={<RoleProtectedRoute allowedRoles={["ADMIN", "ANALISTA"]} redirectTo="/" />}>
              <Route path="/dashboards" element={<DashboardsPage />} />
            </Route>

            {/* Dashboard Gerencial - Solo ADMIN y GERENTE */}
            <Route element={<RoleProtectedRoute allowedRoles={["ADMIN", "GERENTE"]} redirectTo="/" />}>
              <Route path="/dashboards/gerencial" element={<GerencialDashboardPage />} />
            </Route>

            {/* Rutas de Administración - Solo ADMIN */}
            <Route element={<RoleProtectedRoute allowedRoles={["ADMIN"]} redirectTo="/" />}>
              <Route path="/admin/usuarios" element={<UserManagementPage />} />
              <Route path="/admin/roles" element={<RoleManagementPage />} />
              <Route path="/admin/permisos" element={<PermissionManagementPage />} />
              <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
              <Route path="/admin/ingesta-datos" element={<DataIngestionPage />} />
              <Route path="/admin/contenido-analitico" element={<Blank />} />
              <Route path="/admin/acceso-seguridad" element={<Blank />} />
            </Route>
          </Route>
        </Route>

        {/* Rutas Públicas */}
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/update-password" element={<UpdatePassword />} />
        
        {/* Ruta de Fallback */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
    </Refine>
  );
}
