// =================================================================
// FTV-009: Empty State Component
// Fuente de Verdad: .gemini/blueprints/frontend/IOC-004-user-role-management/ftv-009-empty-state.md
// =================================================================

import React from 'react';
import { cn } from '../../../utils/cn';

interface EmptyStateProps {
  /** Título del estado vacío */
  title: string;

  /** Descripción del estado vacío */
  description?: string;

  /** Texto del botón de acción */
  actionLabel?: string;

  /** Callback del botón de acción */
  onAction?: () => void;

  /** Icono personalizado */
  icon?: React.ReactNode;

  /** Clase CSS adicional */
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  description,
  actionLabel,
  onAction,
  icon,
  className
}) => {
  const defaultIcon = (
    <svg
      className="w-16 h-16 text-gray-400 dark:text-gray-600"
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
      />
    </svg>
  );

  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center py-12 px-4 text-center',
        className
      )}
      role="status"
      aria-live="polite"
    >
      <div className="mb-4">
        {icon || defaultIcon}
      </div>

      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
        {title}
      </h3>

      {description && (
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-6 max-w-md">
          {description}
        </p>
      )}

      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className={cn(
            'inline-flex items-center gap-2 px-4 py-2 rounded-lg',
            'bg-blue-600 text-white font-medium text-sm',
            'hover:bg-blue-700 focus:outline-none focus:ring-2',
            'focus:ring-blue-500 focus:ring-offset-2',
            'transition-colors duration-200',
            'dark:bg-blue-500 dark:hover:bg-blue-600'
          )}
          aria-label={actionLabel}
        >
          <svg
            className="w-5 h-5"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 4v16m8-8H4"
            />
          </svg>
          {actionLabel}
        </button>
      )}
    </div>
  );
};

EmptyState.displayName = 'EmptyState';


