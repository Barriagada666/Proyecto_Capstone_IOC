import React from 'react';

interface TableSkeletonProps {
  rows?: number;
  columns?: number;
  className?: string;
}

export const TableSkeleton: React.FC<TableSkeletonProps> = ({ rows = 5, columns = 6, className = '' }) => {
  return (
    <div role="status" aria-live="polite" className={`p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 ${className}`}>
      <span className="sr-only">Cargando lista de elementos…</span>
      <div className="animate-pulse">
        {/* Header */}
        <div className="flex gap-4 mb-4">
          {Array.from({ length: columns }).map((_, i) => (
            <div key={i} className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/5" />
          ))}
        </div>

        {/* Rows */}
        <div className="space-y-3">
          {Array.from({ length: rows }).map((_, r) => (
            <div key={r} className="flex gap-4 items-center">
              {Array.from({ length: columns }).map((_, c) => (
                <div key={c} className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-1/5" />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

