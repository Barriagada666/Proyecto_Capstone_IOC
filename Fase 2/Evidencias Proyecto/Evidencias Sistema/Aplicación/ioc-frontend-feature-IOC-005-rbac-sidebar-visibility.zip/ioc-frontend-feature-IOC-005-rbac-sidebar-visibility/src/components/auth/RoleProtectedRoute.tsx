import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

interface RoleProtectedRouteProps {
  allowedRoles: string[];
  redirectTo?: string;
}

export const RoleProtectedRoute = ({
  allowedRoles,
  redirectTo = '/'
}: RoleProtectedRouteProps) => {
  const { user, roles } = useAuth();

  if (!user) {
    return <Navigate to="/signin" replace />;
  }

  // Check if user has at least one of the allowed roles
  const hasAccess = allowedRoles.some(role => roles.includes(role));

  if (!hasAccess) {
    return <Navigate to={redirectTo} replace />;
  }

  return <Outlet />;
};

