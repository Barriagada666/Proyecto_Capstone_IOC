// =================================================================
// FTV-008: Role Badge Component
// Fuente de Verdad: .gemini/blueprints/frontend/IOC-004-user-role-management/ftv-008-role-badge.md
// =================================================================

import React from 'react';
import { RoleVariant } from '../../../types/user-management/role.types';
import { cn } from '../../../utils/cn';

interface RoleBadgeProps {
  role: string;
  size?: 'sm' | 'md' | 'lg';
  removable?: boolean;
  onRemove?: (role: string) => void;
  className?: string;
  disabled?: boolean;
}

const ROLE_VARIANTS: Record<string, RoleVariant> = {
  ADMIN: {
    bg: 'bg-red-100 dark:bg-red-900',
    text: 'text-red-800 dark:text-red-200',
    border: 'border-red-200 dark:border-red-800',
    label: 'Administrador'
  },
  GERENTE: {
    bg: 'bg-blue-100 dark:bg-blue-900',
    text: 'text-blue-800 dark:text-blue-200',
    border: 'border-blue-200 dark:border-blue-800',
    label: 'Gerente'
  },
  ANALISTA: {
    bg: 'bg-green-100 dark:bg-green-900',
    text: 'text-green-800 dark:text-green-200',
    border: 'border-green-200 dark:border-green-800',
    label: 'Analista'
  },
  DEFAULT: {
    bg: 'bg-gray-100 dark:bg-gray-800',
    text: 'text-gray-800 dark:text-gray-200',
    border: 'border-gray-200 dark:border-gray-700',
    label: 'Desconocido'
  }
};

const SIZE_VARIANTS = {
  sm: { padding: 'px-2 py-0.5', text: 'text-xs', gap: 'gap-1' },
  md: { padding: 'px-2.5 py-1', text: 'text-sm', gap: 'gap-1.5' },
  lg: { padding: 'px-3 py-1.5', text: 'text-base', gap: 'gap-2' }
};

const RoleBadge: React.FC<RoleBadgeProps> = ({
  role,
  size = 'md',
  removable = false,
  onRemove,
  className,
  disabled = false
}) => {
  const variant = ROLE_VARIANTS[role] || ROLE_VARIANTS.DEFAULT;
  const sizeConfig = SIZE_VARIANTS[size];

  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!disabled && onRemove) {
      onRemove(role);
    }
  };

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border font-medium transition-colors',
        sizeConfig.padding,
        sizeConfig.text,
        sizeConfig.gap,
        variant.bg,
        variant.text,
        variant.border,
        disabled && 'opacity-50 cursor-not-allowed',
        !disabled && removable && 'pr-1',
        className
      )}
      role="status"
      aria-label={`Rol: ${variant.label}`}
    >
      <span>{variant.label}</span>

      {removable && (
        <button
          type="button"
          onClick={handleRemove}
          disabled={disabled}
          className={cn(
            'ml-0.5 rounded-full p-0.5 transition-colors',
            'hover:bg-black/10 dark:hover:bg-white/10',
            'focus:outline-none focus:ring-2 focus:ring-offset-1',
            disabled && 'cursor-not-allowed'
          )}
          aria-label={`Remover rol ${variant.label}`}
        >
          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      )}
    </span>
  );
};

RoleBadge.displayName = 'RoleBadge';

export { RoleBadge };

