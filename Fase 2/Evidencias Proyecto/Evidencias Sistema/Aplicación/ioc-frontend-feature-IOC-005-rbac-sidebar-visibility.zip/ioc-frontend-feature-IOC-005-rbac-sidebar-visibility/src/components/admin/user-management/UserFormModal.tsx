// =================================================================
// FTV-004: User Form Modal Component
// Fuente de Verdad: .gemini/blueprints/frontend/IOC-004-user-role-management/ftv-004-user-form-modal.md
// =================================================================

import React, { useEffect, useMemo } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { userFormSchema, UserFormValues } from '../../../schemas/user.schema';
import { User, Planta } from '../../../types/user-management';
import { Role } from '../../../types/user-management/role.types';
import { RoleBadge } from './RoleBadge';
import { cn } from '../../../utils/cn';
import flatpickr from 'flatpickr';
import 'flatpickr/dist/flatpickr.min.css';
import { Spanish } from 'flatpickr/dist/l10n/es.js';
import toast from 'react-hot-toast';
import { usePlantas } from '../../../hooks/usePlantas';
import { supabase } from '../../../lib/supabaseClient';

type FlatpickrInstance = ReturnType<typeof flatpickr>;
type FlatpickrOptions = Parameters<typeof flatpickr>[1];

interface UserFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: UserFormValues) => Promise<void>;
  user?: User;
  plantas?: Planta[];
  loading?: boolean;
  availableRoles?: Role[];
  rolesLoading?: boolean;
}

const UserFormModal: React.FC<UserFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  user,
  plantas = [],
  loading = false,
  availableRoles = [],
  rolesLoading = false
}) => {
  const isEditMode = !!user;
  const [showPassword, setShowPassword] = React.useState(false);

  // Map user role names to IDs for edit mode
  const getUserRoleIds = (user?: User, availableRoles?: Role[]): number[] => {
    if (!user || !availableRoles) return [];
    return availableRoles
      .filter(role => user.roles.includes(role.name))
      .map(role => role.id);
  };

  const {
     control,
     register,
     handleSubmit,
     watch,
     formState: { errors, isSubmitting },
      setValue,
      trigger,
      reset
    } = useForm({
    resolver: zodResolver(userFormSchema),
    defaultValues: user ? {
      email: user.email,
      primerNombre: user.primerNombre,
      segundoNombre: user.segundoNombre || '',
      primerApellido: user.primerApellido,
      segundoApellido: user.segundoApellido || '',
      plantaId: user.plantaId || undefined,
      centroCosto: user.centroCosto || '',
      fechaContrato: user.fechaContrato || '',
      isActive: user.isActive,
      roles: getUserRoleIds(user, availableRoles)
    } : {
      email: '',
      password: '',
      primerNombre: '',
      segundoNombre: '',
      primerApellido: '',
      segundoApellido: '',
      centroCosto: '',
      fechaContrato: '',
      isActive: true,
      roles: []
    }
  });

  useEffect(() => {
    if (isOpen && user) {
      reset({
        email: user.email,
        primerNombre: user.primerNombre,
        segundoNombre: user.segundoNombre || '',
        primerApellido: user.primerApellido,
        segundoApellido: user.segundoApellido || '',
        plantaId: user.plantaId || undefined,
        centroCosto: user.centroCosto || '',
        fechaContrato: user.fechaContrato || '',
        isActive: user.isActive,
        roles: getUserRoleIds(user, availableRoles)
      });
    }
  }, [isOpen, user, reset, availableRoles]);

  // Clear the password field when the modal is closed to avoid leaving generated passwords in the DOM
  useEffect(() => {
    if (!isOpen) {
      setValue('password', '');
    }
  }, [isOpen, setValue]);

  // watch password to show inline message when generated or present
  const passwordValue = watch('password');

  // Use centralized refine hook to load plantas (or use prop if provided)
  const { plantas: fetchedPlantas, isLoading: plantasLoading, isError: plantasError, refetch: refetchPlantas } = usePlantas();

  // Last-resort local fallback: if neither prop nor hook provide plantas, fetch directly here
  const [localPlantas, setLocalPlantas] = React.useState<Planta[]>([]);
  useEffect(() => {
    let mounted = true;
    if (!isOpen) return;
    const fetchLocal = async () => {
      try {
        console.debug('[UserFormModal] running modal fallback supabase fetch for plantas (forced on open)');
        const { data, error } = await supabase.from('plantas').select('id,name').order('name', { ascending: true });
        if (!mounted) return;
        if (error) {
          console.error('[UserFormModal] Supabase fallback error in modal:', error);
          toast.error('Error cargando plantas (fallback)');
          return;
        }
        console.debug('[UserFormModal] Supabase fallback returned', { length: data?.length ?? 0, data });
        if (data && data.length > 0) {
          setLocalPlantas(data as Planta[]);
        }
      } catch (err) {
        console.error('Unexpected supabase fallback error in modal:', err);
        toast.error('Error cargando plantas (fallback)');
      }
    };
    void fetchLocal();
    return () => { mounted = false; };
  }, [isOpen]);

  // Merge plantas from prop, hook and local fallback, deduplicate by id
  const mergedPlantas = useMemo(() => {
    const map = new Map<number, Planta>();
    // priority: prop plantas first (so they override), then fetched, then local
    (plantas || []).forEach((p) => map.set(p.id, p));
    (fetchedPlantas || []).forEach((p) => { if (!map.has(p.id)) map.set(p.id, p); });
    (localPlantas || []).forEach((p) => { if (!map.has(p.id)) map.set(p.id, p); });
    return Array.from(map.values());
  }, [plantas, fetchedPlantas, localPlantas]);

  useEffect(() => {
    if (!isOpen) return;
    console.debug('[UserFormModal] plantas counts', { prop: (plantas || []).length, fetched: (fetchedPlantas || []).length, local: localPlantas.length, merged: mergedPlantas.length });
  }, [isOpen, plantas, fetchedPlantas, localPlantas, mergedPlantas]);

  // If modal opens and no plantas are available yet, trigger a refetch (covers providers that lazily fetch)
  useEffect(() => {
    if (!isOpen) return;
    const hasPropPlantas = plantas && plantas.length > 0;
    const hasFetched = fetchedPlantas && fetchedPlantas.length > 0;
    if (!hasPropPlantas && !hasFetched) {
      // attempt to refetch
      try {
        refetchPlantas?.();
      } catch {
        // ignore
      }
    }
  }, [isOpen, plantas, fetchedPlantas, refetchPlantas]);

  // Small DatePicker wrapper using flatpickr
  const DatePicker: React.FC<{ value?: string | undefined; onChange: (v: string) => void; id?: string; className?: string }> = ({ value, onChange, id, className }) => {
    const inputRef = React.useRef<HTMLInputElement | null>(null);

    useEffect(() => {
      if (!inputRef.current) return;
      const options: Partial<FlatpickrOptions> = {
        // store ISO date as the actual value (Y-m-d) while showing altInput in d/m/Y
        dateFormat: 'Y-m-d',
        altInput: true,
        altFormat: 'd/m/Y',
        locale: Spanish,
        defaultDate: value ?? undefined,
        allowInput: true,
        onChange: function (_selectedDates: Date[], dateStr: string) {
          // dateStr is in the dateFormat (Y-m-d)
          onChange(dateStr || '');
        }
      };

      const fp: FlatpickrInstance = flatpickr(inputRef.current as HTMLElement, options as FlatpickrOptions);

      return () => fp.destroy();
    }, [inputRef, onChange, value]);

    // keep input value in sync when form resets
    useEffect(() => {
      if (inputRef.current) {
        inputRef.current.value = value || '';
      }
    }, [value]);

    return <input id={id} ref={inputRef} className={className} readOnly={false} />;
  };

  const onSubmit = async (data: UserFormValues) => {
    try {
      await onSave(data);
      reset();
      onClose();
    } catch (error) {
      console.error('Error saving user:', error);
    }
  };

  // Generate a strong password that meets the schema regex
  const generateStrongPassword = (length = 12) => {
    const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lower = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const symbols = '@$!%*?&';
    const all = upper + lower + numbers + symbols;

    // ensure at least one of each
    let pwd = '';
    pwd += upper[Math.floor(Math.random() * upper.length)];
    pwd += lower[Math.floor(Math.random() * lower.length)];
    pwd += numbers[Math.floor(Math.random() * numbers.length)];
    pwd += symbols[Math.floor(Math.random() * symbols.length)];

    for (let i = 4; i < length; i++) {
      pwd += all[Math.floor(Math.random() * all.length)];
    }

    // shuffle
    pwd = pwd.split('').sort(() => 0.5 - Math.random()).join('');
    return pwd;
  };

  const handleGeneratePassword = async () => {
    const pwd = generateStrongPassword(12);
    setValue('password', pwd, { shouldDirty: true, shouldTouch: true });
    await trigger('password');
    // Keep password hidden by default for better UX (user can reveal if needed)
    toast.success('Contraseña generada (oculta)');
  };

  const handleCopyPassword = async () => {
    const val = (document.querySelector('input[name="password"]') as HTMLInputElement | null)?.value;
    if (!val) {
      toast.error('No hay contraseña para copiar');
      return;
    }
    try {
      await navigator.clipboard.writeText(val);
      toast.success('Contraseña copiada al portapapeles');
    } catch (err) {
      console.error('navigator.clipboard error:', err);
      // fallback
      try {
        const textarea = document.createElement('textarea');
        textarea.value = val;
        document.body.appendChild(textarea);
        textarea.select();
        // execCommand is deprecated but still needed as a fallback in some browsers.
        // Use a typed indirection to avoid referencing the deprecated DOM signature directly (TS6387).
        const exec = (document as unknown as { execCommand?: (...args: unknown[]) => boolean }).execCommand;
        if (typeof exec === 'function') {
          // call with document as thisArg to match original behavior
          exec.call(document, 'copy');
        } else {
          // execCommand isn't available — clean up and show an error without throwing.
          document.body.removeChild(textarea);
          toast.error('No se pudo copiar la contraseña (execCommand no disponible)');
          return;
        }
        document.body.removeChild(textarea);
        toast.success('Contraseña copiada al portapapeles');
      } catch (err2) {
        console.error('fallback clipboard error:', err2);
        toast.error('No se pudo copiar la contraseña');
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            {isEditMode ? 'Editar Usuario' : 'Crear Usuario'}
          </h2>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Correo Electrónico <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              {...register('email')}
              disabled={isEditMode}
              className={cn(
                'w-full px-4 py-2 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-gray-300 dark:border-gray-600',
                'focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 dark:disabled:bg-gray-700 disabled:cursor-not-allowed',
                errors.email && 'border-red-500 focus:ring-red-500'
              )}
            />
            {errors.email && <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.email.message}</p>}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Primer Nombre <span className="text-red-500">*</span>
              </label>
              <input type="text" {...register('primerNombre')} className={cn('w-full px-4 py-2 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent', errors.primerNombre && 'border-red-500 focus:ring-red-500')} />
              {errors.primerNombre && <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.primerNombre.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Segundo Nombre</label>
              <input type="text" {...register('segundoNombre')} className="w-full px-4 py-2 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Primer Apellido <span className="text-red-500">*</span>
              </label>
              <input type="text" {...register('primerApellido')} className={cn('w-full px-4 py-2 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent', errors.primerApellido && 'border-red-500 focus:ring-red-500')} />
              {errors.primerApellido && <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.primerApellido.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Segundo Apellido</label>
              <input type="text" {...register('segundoApellido')} className="w-full px-4 py-2 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Planta</label>
              {/* Render select with clear states: loading, error, empty, normal */}
              {(() => {
                const sourcePlantas = mergedPlantas;

                // Loading
                if (plantasLoading) {
                  return (
                    <div className="flex items-center gap-2">
                      <select {...register('plantaId', { valueAsNumber: true })} disabled className="w-full px-4 py-2 border rounded-lg bg-white dark:bg-gray-800 text-gray-500 border-gray-300 dark:border-gray-700 focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option>{'Cargando plantas...'}</option>
                      </select>
                      <svg className="w-5 h-5 animate-spin text-gray-500" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                      </svg>
                    </div>
                  );
                }

                // Error and no data: show retry
                if (plantasError && sourcePlantas.length === 0) {
                  return (
                    <div className="flex flex-col gap-2">
                      <p className="text-sm text-red-600 dark:text-red-400">No se pudieron cargar las plantas.</p>
                      <div>
                        <button type="button" onClick={() => refetchPlantas?.()} className="px-3 py-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded text-sm hover:bg-gray-50">Reintentar</button>
                      </div>
                    </div>
                  );
                }

                // Empty (no plantas found)
                if (!plantasLoading && sourcePlantas.length === 0) {
                  return (
                    <div className="flex flex-col gap-2">
                      <p className="text-sm text-gray-600 dark:text-gray-300">No hay plantas disponibles.</p>
                      <div>
                        <button type="button" onClick={() => refetchPlantas?.()} className="px-3 py-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded text-sm hover:bg-gray-50">Reintentar</button>
                      </div>
                    </div>
                  );
                }

                // Normal state: render select with options
                return (
                  <select {...register('plantaId', { valueAsNumber: true })} disabled={plantasLoading} className="w-full px-4 py-2 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="">{plantasLoading ? 'Cargando plantas...' : 'Seleccionar planta'}</option>
                    {sourcePlantas.map((planta) => (
                      <option key={planta.id} value={planta.id}>{planta.name}</option>
                    ))}
                  </select>
                );
              })()}
             </div>
            <div>
               <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Centro de Costo</label>
               <input type="text" {...register('centroCosto')} className="w-full px-4 py-2 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
             </div>
           </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Fecha de Contrato</label>
            <Controller
              control={control}
              name="fechaContrato"
              render={({ field }) => (
                <DatePicker
                  value={field.value as string}
                  onChange={async (v) => { field.onChange(v); await trigger('fechaContrato'); }}
                  className="w-full px-4 py-2 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              )}
            />
            {errors.fechaContrato && <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.fechaContrato.message}</p>}
          </div>

          {/* Role Selection Section */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Roles <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
              Seleccione al menos un rol para el usuario
            </p>

            <Controller
              control={control}
              name="roles"
              render={({ field }) => {
                const selectedRoleIds = new Set(field.value || []);

                const handleToggleRole = (roleId: number) => {
                  const newSelected = new Set(selectedRoleIds);
                  if (newSelected.has(roleId)) {
                    newSelected.delete(roleId);
                  } else {
                    newSelected.add(roleId);
                  }
                  field.onChange(Array.from(newSelected));
                };

                // Show loading state
                if (rolesLoading) {
                  return (
                    <div className="flex items-center gap-2 p-4 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-800">
                      <svg className="w-5 h-5 animate-spin text-gray-500" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                      </svg>
                      <span className="text-sm text-gray-600 dark:text-gray-400">Cargando roles...</span>
                    </div>
                  );
                }

                // Show empty state
                if (!availableRoles || availableRoles.length === 0) {
                  return (
                    <div className="p-4 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-800">
                      <p className="text-sm text-gray-600 dark:text-gray-400">No hay roles disponibles</p>
                    </div>
                  );
                }

                // Show role checkboxes
                return (
                  <div className="space-y-2 max-h-64 overflow-y-auto border border-gray-300 dark:border-gray-600 rounded-lg p-3 bg-white dark:bg-gray-800">
                    {availableRoles.map((role) => (
                      <label
                        key={role.id}
                        className={cn(
                          'flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors',
                          selectedRoleIds.has(role.id)
                            ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'
                            : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                        )}
                      >
                        <input
                          type="checkbox"
                          checked={selectedRoleIds.has(role.id)}
                          onChange={() => handleToggleRole(role.id)}
                          className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                        />
                        <div className="flex-1">
                          <RoleBadge role={role.name} size="sm" />
                          {role.description && (
                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                              {role.description}
                            </p>
                          )}
                        </div>
                      </label>
                    ))}
                  </div>
                );
              }}
            />
            {errors.roles && <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.roles.message}</p>}
          </div>

          {!isEditMode && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Contraseña <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  {...register('password')}
                  name="password"
                  placeholder="Ingrese una contraseña segura"
                  className={cn(
                    'w-full px-4 py-2 pr-28 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent',
                    errors.password && 'border-red-500 focus:ring-red-500'
                  )}
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
                  <button type="button" onClick={handleGeneratePassword} className="px-2 py-1 bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded text-sm hover:bg-gray-200 dark:hover:bg-gray-700">
                    Generar
                  </button>
                  <button type="button" onClick={handleCopyPassword} className="px-2 py-1 bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded text-sm hover:bg-gray-200 dark:hover:bg-gray-700">
                    Copiar
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 p-1"
                    aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
                  >
                    {showPassword ? (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                      </svg>
                    ) : (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                      </svg>
                    )}
                  </button>
                </div>
              </div>
              {errors.password && <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.password.message}</p>}

              {/* Inline status message for generated/present password (accessible) */}
              {passwordValue && (
                <p aria-live="polite" className="mt-2 text-sm text-gray-700 dark:text-gray-300">
                  Contraseña generada y oculta. Haz clic en "Mostrar" para verla o en "Copiar" para copiarla al portapapeles.
                </p>
              )}

              <div className="mt-2 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                 <p className="text-xs text-blue-800 dark:text-blue-200 font-medium mb-2">La contraseña debe cumplir con los siguientes requisitos:</p>
                 <ul className="text-xs text-blue-700 dark:text-blue-300 space-y-1">
                   <li className="flex items-start gap-2">
                     <span className="text-blue-600 dark:text-blue-400 mt-0.5">•</span>
                     <span>Mínimo 8 caracteres de longitud</span>
                   </li>
                   <li className="flex items-start gap-2">
                     <span className="text-blue-600 dark:text-blue-400 mt-0.5">•</span>
                     <span>Al menos una letra mayúscula (A-Z)</span>
                   </li>
                   <li className="flex items-start gap-2">
                     <span className="text-blue-600 dark:text-blue-400 mt-0.5">•</span>
                     <span>Al menos una letra minúscula (a-z)</span>
                   </li>
                   <li className="flex items-start gap-2">
                     <span className="text-blue-600 dark:text-blue-400 mt-0.5">•</span>
                     <span>Al menos un número (0-9)</span>
                   </li>
                   <li className="flex items-start gap-2">
                     <span className="text-blue-600 dark:text-blue-400 mt-0.5">•</span>
                     <span>Al menos un carácter especial (@$!%*?&)</span>
                   </li>
                 </ul>
               </div>
             </div>
           )}

          {isEditMode && (
            <div className="flex items-center gap-3">
              <input type="checkbox" id="isActive" {...register('isActive')} className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-2 focus:ring-blue-500" />
              <label htmlFor="isActive" className="text-sm font-medium text-gray-700 dark:text-gray-300">Usuario activo</label>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-6 border-t border-gray-200 dark:border-gray-700">
            <button type="button" onClick={onClose} disabled={isSubmitting} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
              Cancelar
            </button>
            <div className="flex flex-col items-end">
              {rolesLoading && (
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">Cargando roles... por favor espera antes de enviar</p>
              )}
              <button type="submit" disabled={isSubmitting || loading || rolesLoading} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                {isSubmitting || loading ? 'Guardando...' : isEditMode ? 'Actualizar' : 'Crear'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

UserFormModal.displayName = 'UserFormModal';

export { UserFormModal };
