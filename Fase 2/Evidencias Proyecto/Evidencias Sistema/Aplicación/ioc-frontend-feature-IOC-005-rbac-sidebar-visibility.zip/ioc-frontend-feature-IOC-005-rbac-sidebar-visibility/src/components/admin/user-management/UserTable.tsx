// =================================================================
// FTV-007: User Table Component
// Fuente de Verdad: .gemini/blueprints/frontend/IOC-004-user-role-management/ftv-007-user-table.md
// =================================================================

import React from 'react';
import { User } from '../../../types/user-management';
import { RoleBadge } from './RoleBadge';
import { EmptyState } from './EmptyState';
import { cn } from '../../../utils/cn';
import { TableSkeleton } from '../../common/TableSkeleton';

interface UserTableProps {
  /** Lista de usuarios */
  users: User[];

  /** Estado de carga */
  loading?: boolean;

  /** Callback para editar usuario */
  onEdit?: (user: User) => void;

  /** Callback para eliminar usuario */
  onDelete?: (user: User) => void;

  /** Callback para asignar roles */
  onAssignRoles?: (user: User) => void;

  /** Clase CSS adicional */
  className?: string;
}

export const UserTable: React.FC<UserTableProps> = ({
  users,
  loading = false,
  onEdit,
  onDelete,
  onAssignRoles,
  className
}) => {
  if (loading) {
    return <TableSkeleton rows={5} columns={6} className={className} />;
  }

  if (users.length === 0) {
    return (
      <EmptyState
        title="No hay usuarios"
        description="Aún no se han creado usuarios en el sistema. Comienza agregando el primer usuario."
        actionLabel="Crear Usuario"
        onAction={() => {}}
      />
    );
  }

  return (
    <div className={cn('overflow-x-auto', className)}>
      {/* Desktop Table View */}
      <table className="hidden lg:table w-full text-sm text-left">
        <thead className="text-xs uppercase bg-gray-50 dark:bg-gray-800 border-b dark:border-gray-700">
          <tr>
            <th scope="col" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-300">
              Nombre
            </th>
            <th scope="col" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-300">
              Correo
            </th>
            <th scope="col" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-300">
              Planta
            </th>
            <th scope="col" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-300">
              Roles
            </th>
            <th scope="col" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-300">
              Estado
            </th>
            <th scope="col" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-300">
              Acciones
            </th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr
              key={user.id}
              className="bg-white border-b dark:bg-gray-900 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
            >
              <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                {`${user.primerNombre} ${user.segundoNombre || ''} ${user.primerApellido} ${user.segundoApellido || ''}`.trim()}
              </td>
              <td className="px-6 py-4 text-gray-700 dark:text-gray-300">
                {user.email}
              </td>
              <td className="px-6 py-4 text-gray-700 dark:text-gray-300">
                {user.plantaNombre || '-'}
              </td>
              <td className="px-6 py-4">
                <div className="flex flex-wrap gap-1">
                  {user.roles.length > 0 ? (
                    user.roles.map((role: string) => (
                      <RoleBadge key={role} role={role} size="sm" />
                    ))
                  ) : (
                    <span className="text-gray-400 dark:text-gray-500 text-xs">Sin roles</span>
                  )}
                </div>
              </td>
              <td className="px-6 py-4">
                <StatusBadge isActive={user.isActive} />
              </td>
              <td className="px-6 py-4">
                <ActionButtons
                  user={user}
                  onEdit={onEdit}
                  onDelete={onDelete}
                  onAssignRoles={onAssignRoles}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Mobile Card View */}
      <div className="lg:hidden space-y-4">
        {users.map((user) => (
          <UserCard
            key={user.id}
            user={user}
            onEdit={onEdit}
            onDelete={onDelete}
            onAssignRoles={onAssignRoles}
          />
        ))}
      </div>
    </div>
  );
};

// Status Badge Component
const StatusBadge: React.FC<{ isActive: boolean }> = ({ isActive }) => (
  <span
    className={cn(
      'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium',
      isActive
        ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
        : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
    )}
  >
    <span className={cn('w-2 h-2 rounded-full', isActive ? 'bg-green-600' : 'bg-gray-600')} />
    {isActive ? 'Activo' : 'Inactivo'}
  </span>
);

// Action Buttons Component
interface ActionButtonsProps {
  user: User;
  onEdit?: (user: User) => void;
  onDelete?: (user: User) => void;
  onAssignRoles?: (user: User) => void;
}

const ActionButtons: React.FC<ActionButtonsProps> = ({ user, onEdit, onDelete, onAssignRoles }) => (
  <div className="flex items-center gap-2">
    {onAssignRoles && (
      <button
        onClick={() => onAssignRoles(user)}
        className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
        title="Asignar roles"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
      </button>
    )}
    {onEdit && (
      <button
        onClick={() => onEdit(user)}
        className="p-2 text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 rounded-lg transition-colors"
        title="Editar"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
        </svg>
      </button>
    )}
    {onDelete && (
      <button
        onClick={() => onDelete(user)}
        className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
        title="Eliminar"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
        </svg>
      </button>
    )}
  </div>
);

// Mobile User Card Component
interface UserCardProps {
  user: User;
  onEdit?: (user: User) => void;
  onDelete?: (user: User) => void;
  onAssignRoles?: (user: User) => void;
}

const UserCard: React.FC<UserCardProps> = ({ user, onEdit, onDelete, onAssignRoles }) => (
  <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
    <div className="flex justify-between items-start mb-3">
      <div>
        <h3 className="font-medium text-gray-900 dark:text-white">
          {`${user.primerNombre} ${user.primerApellido}`}
        </h3>
        <p className="text-sm text-gray-500 dark:text-gray-400">{user.email}</p>
      </div>
      <StatusBadge isActive={user.isActive} />
    </div>

    {user.plantaNombre && (
      <div className="mb-3 text-sm">
        <span className="text-gray-500 dark:text-gray-400">Planta: </span>
        <span className="text-gray-900 dark:text-white">{user.plantaNombre}</span>
      </div>
    )}

    <div className="mb-3">
      <div className="flex flex-wrap gap-1">
        {user.roles.length > 0 ? (
          user.roles.map((role) => (
            <RoleBadge key={role} role={role} size="sm" />
          ))
        ) : (
          <span className="text-gray-400 dark:text-gray-500 text-xs">Sin roles</span>
        )}
      </div>
    </div>

    <div className="flex gap-2 pt-3 border-t border-gray-200 dark:border-gray-700">
      <ActionButtons
        user={user}
        onEdit={onEdit}
        onDelete={onDelete}
        onAssignRoles={onAssignRoles}
      />
    </div>
  </div>
);

UserTable.displayName = 'UserTable';
