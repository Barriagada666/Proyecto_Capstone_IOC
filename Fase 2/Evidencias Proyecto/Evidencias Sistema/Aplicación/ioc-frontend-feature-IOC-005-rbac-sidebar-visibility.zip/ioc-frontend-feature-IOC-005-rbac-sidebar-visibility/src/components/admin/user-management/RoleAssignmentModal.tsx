// =================================================================
// FTV-005: Role Assignment Modal Component
// Fuente de Verdad: .gemini/blueprints/frontend/IOC-004-user-role-management/ftv-005-role-assignment-modal.md
// =================================================================

import React, { useState, useEffect } from 'react';
import { User, Role } from '../../../types/user-management';
import { RoleBadge } from './RoleBadge';
import { cn } from '../../../utils/cn';

interface RoleAssignmentModalProps {
  /** Si el modal está abierto */
  isOpen: boolean;

  /** Callback para cerrar el modal */
  onClose: () => void;

  /** Usuario al que se asignarán roles */
  user?: User;

  /** Lista de todos los roles disponibles */
  availableRoles: Role[];

  /** Callback para guardar los cambios */
  onSave: (userId: number, roleIds: number[]) => Promise<void>;

  /** Estado de carga */
  loading?: boolean;
}

export const RoleAssignmentModal: React.FC<RoleAssignmentModalProps> = ({
  isOpen,
  onClose,
  user,
  availableRoles,
  onSave,
  loading = false
}) => {
  const [selectedRoles, setSelectedRoles] = useState<Set<string>>(new Set());
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen && user) {
      setSelectedRoles(new Set(user.roles));
    }
  }, [isOpen, user]);

  const handleToggleRole = (roleName: string) => {
    const newSelected = new Set(selectedRoles);
    if (newSelected.has(roleName)) {
      newSelected.delete(roleName);
    } else {
      newSelected.add(roleName);
    }
    setSelectedRoles(newSelected);
  };

  const handleSave = async () => {
    if (!user) return;

    setIsSubmitting(true);
    try {
      const roleIds = availableRoles
        .filter(role => selectedRoles.has(role.name))
        .map(role => role.id);

      await onSave(user.id, roleIds);
      onClose();
    } catch (error) {
      console.error('Error saving roles:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div
        className="bg-white dark:bg-gray-900 rounded-lg shadow-xl max-w-md w-full"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Asignar Roles
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {user.primerNombre} {user.primerApellido}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Current Roles */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Roles Actuales
            </h3>
            <div className="flex flex-wrap gap-2">
              {user.roles.length > 0 ? (
                user.roles.map((role: string) => (
                  <RoleBadge key={role} role={role} size="sm" />
                ))
              ) : (
                <span className="text-sm text-gray-400 dark:text-gray-500">Sin roles asignados</span>
              )}
            </div>
          </div>

          {/* Role Selection */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
              Seleccionar Roles
            </h3>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {availableRoles.map((role) => (
                <label
                  key={role.id}
                  className={cn(
                    'flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors',
                    selectedRoles.has(role.name)
                      ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'
                      : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                  )}
                >
                  <input
                    type="checkbox"
                    checked={selectedRoles.has(role.name)}
                    onChange={() => handleToggleRole(role.name)}
                    className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                  />
                  <div className="flex-1">
                    <RoleBadge role={role.name} size="sm" />
                    {role.description && (
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {role.description}
                      </p>
                    )}
                  </div>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 p-6 border-t border-gray-200 dark:border-gray-700">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSubmitting || loading}
            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting || loading ? 'Guardando...' : 'Guardar Cambios'}
          </button>
        </div>
      </div>
    </div>
  );
};

RoleAssignmentModal.displayName = 'RoleAssignmentModal';