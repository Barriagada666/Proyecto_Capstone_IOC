// =================================================================
// FTV-006: Permission Assignment Modal Component
// Fuente de Verdad: .gemini/blueprints/frontend/IOC-004-user-role-management/ftv-006-permission-assignment-modal.md
// =================================================================

import React, { useState, useEffect } from 'react';
import { Role } from '../../../types/user-management';
import { Permission, GroupedPermissions } from '../../../types/user-management';
import { cn } from '../../../utils/cn';

interface PermissionAssignmentModalProps {
  /** Si el modal está abierto */
  isOpen: boolean;

  /** Callback para cerrar el modal */
  onClose: () => void;

  /** Rol al que se asignarán permisos */
  role?: Role;

  /** Lista de todos los permisos disponibles */
  availablePermissions: Permission[];

  /** Callback para guardar los cambios */
  onSave: (roleId: number, permissionIds: number[]) => Promise<void>;

  /** Estado de carga */
  loading?: boolean;
}

export const PermissionAssignmentModal: React.FC<PermissionAssignmentModalProps> = ({
  isOpen,
  onClose,
  role,
  availablePermissions,
  onSave,
  loading = false
}) => {
  const [selectedPermissions, setSelectedPermissions] = useState<Set<string>>(new Set());
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen && role) {
      setSelectedPermissions(new Set(role.permissions));
    }
  }, [isOpen, role]);

  const handleTogglePermission = (permissionName: string) => {
    const newSelected = new Set(selectedPermissions);
    if (newSelected.has(permissionName)) {
      newSelected.delete(permissionName);
    } else {
      newSelected.add(permissionName);
    }
    setSelectedPermissions(newSelected);
  };

  // Toggle all permissions in a category (permissions array provided)
  const handleToggleCategory = (permissions: Permission[]) => {
    const categoryPermissions = permissions.map((p) => p.name);
    const allSelected = categoryPermissions.every((p) => selectedPermissions.has(p));

    const newSelected = new Set(selectedPermissions);
    if (allSelected) {
      categoryPermissions.forEach((p) => newSelected.delete(p));
    } else {
      categoryPermissions.forEach((p) => newSelected.add(p));
    }
    setSelectedPermissions(newSelected);
  };

  const handleSave = async () => {
    if (!role) return;

    setIsSubmitting(true);
    try {
      const permissionIds = availablePermissions
        .filter(permission => selectedPermissions.has(permission.name))
        .map(permission => permission.id);

      await onSave(role.id, permissionIds);
      onClose();
    } catch (error) {
      console.error('Error saving permissions:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Group permissions by category
  const groupedPermissions: GroupedPermissions = availablePermissions.reduce((acc, permission) => {
    const category = permission.category || 'Sin Categoría';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(permission);
    return acc;
  }, {} as GroupedPermissions);

  if (!isOpen || !role) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div
        className="bg-white dark:bg-gray-900 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Asignar Permisos
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Rol: {role.name}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Summary */}
          <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
            <p className="text-sm text-blue-800 dark:text-blue-200">
              <span className="font-medium">{selectedPermissions.size}</span> de{' '}
              <span className="font-medium">{availablePermissions.length}</span> permisos seleccionados
            </p>
          </div>

          {/* Permission Groups */}
          <div className="space-y-4">
            {Object.entries(groupedPermissions).map(([category, permissions]) => {
              const allSelected = permissions.every(p => selectedPermissions.has(p.name));
              const someSelected = permissions.some(p => selectedPermissions.has(p.name));

              return (
                <div key={category} className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                  {/* Category Header */}
                  <div className="bg-gray-50 dark:bg-gray-800 p-3 border-b border-gray-200 dark:border-gray-700">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={allSelected}
                        ref={(input) => {
                          if (input) {
                            input.indeterminate = someSelected && !allSelected;
                          }
                        }}
                        onChange={() => handleToggleCategory(permissions)}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                      />
                      <span className="font-medium text-gray-900 dark:text-white">
                        {category}
                      </span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        ({permissions.filter(p => selectedPermissions.has(p.name)).length}/{permissions.length})
                      </span>
                    </label>
                  </div>

                  {/* Permissions List */}
                  <div className="p-3 space-y-2">
                    {permissions.map((permission) => (
                      <label
                        key={permission.id}
                        className={cn(
                          'flex items-start gap-3 p-2 rounded-lg cursor-pointer transition-colors',
                          selectedPermissions.has(permission.name)
                            ? 'bg-blue-50 dark:bg-blue-900/20'
                            : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                        )}
                      >
                        <input
                          type="checkbox"
                          checked={selectedPermissions.has(permission.name)}
                          onChange={() => handleTogglePermission(permission.name)}
                          className="mt-0.5 w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-900 dark:text-white">
                            {permission.name}
                          </p>
                          {permission.description && (
                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                              {permission.description}
                            </p>
                          )}
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 p-6 border-t border-gray-200 dark:border-gray-700">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSubmitting || loading}
            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting || loading ? 'Guardando...' : 'Guardar Cambios'}
          </button>
        </div>
      </div>
    </div>
  );
};

PermissionAssignmentModal.displayName = 'PermissionAssignmentModal';