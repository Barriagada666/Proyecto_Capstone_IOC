// =================================================================
// Role Assignment Service
// Implements the correct flow documented in .gemini/frontend-role-agent.md
// =================================================================

import { Role } from '../types/user-management';

/**
 * Service to synchronize user roles using the correct backend endpoints.
 *
 * IMPORTANT: The backend does NOT accept 'roles' field in PUT /api/v1/admin/users/{id}
 * Instead, use the dedicated assignment endpoints:
 * - POST /api/v1/admin/assignments/users/{userId}/roles/{roleId}
 * - DELETE /api/v1/admin/assignments/users/{userId}/roles/{roleId}
 */

interface SyncRolesOptions {
  userId: number;
  desiredRoleNames: string[];
  availableRoles: Role[];
  token: string;
  baseUrl?: string;
}

interface RoleChangeResult {
  added: string[];
  removed: string[];
  failed: Array<{ role: string; action: 'add' | 'remove'; error: string }>;
}

/**
 * Synchronize user roles using the assignment endpoints.
 *
 * Flow:
 * 1. GET current user roles
 * 2. Calculate diff (toAdd, toRemove)
 * 3. Resolve roleId for each role name
 * 4. POST to assign new roles
 * 5. DELETE to remove old roles
 * 6. Verify final state
 */
export async function syncUserRoles(options: SyncRolesOptions): Promise<RoleChangeResult> {
  const { userId, desiredRoleNames, availableRoles, token, baseUrl = '/api/v1' } = options;

  const headers = {
    'Authorization': `Bearer ${token}`,
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  };

  const result: RoleChangeResult = {
    added: [],
    removed: [],
    failed: [],
  };

  // 1. Get current user roles
  const userRes = await fetch(`${baseUrl}/admin/users/${userId}`, { headers });

  if (!userRes.ok) {
    throw new Error(`Failed to fetch user: ${userRes.status} ${userRes.statusText}`);
  }

  const user = await userRes.json();
  const currentRoles = new Set<string>(user.roles || []);

  // 2. Calculate differences
  const desiredRoles = new Set<string>(desiredRoleNames);
  const toAdd = Array.from(desiredRoles).filter(r => !currentRoles.has(r));
  const toRemove = Array.from(currentRoles).filter(r => !desiredRoles.has(r));

  // Helper: resolve role ID from name
  const getRoleId = (roleName: string): number | null => {
    const role = availableRoles.find(r => r.name?.toLowerCase() === roleName.toLowerCase());
    return role ? role.id : null;
  };

  // 3. Assign new roles
  for (const roleName of toAdd) {
    try {
      const roleId = getRoleId(roleName);
      if (!roleId) {
        result.failed.push({
          role: roleName,
          action: 'add',
          error: 'Role not found in available roles',
        });
        continue;
      }

      const assignRes = await fetch(
        `${baseUrl}/admin/assignments/users/${userId}/roles/${roleId}`,
        { method: 'POST', headers }
      );

      if (!assignRes.ok) {
        const errorText = await assignRes.text();
        result.failed.push({
          role: roleName,
          action: 'add',
          error: `${assignRes.status}: ${errorText}`,
        });
      } else {
        result.added.push(roleName);
      }
    } catch (error) {
      result.failed.push({
        role: roleName,
        action: 'add',
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  // 4. Remove old roles
  for (const roleName of toRemove) {
    try {
      const roleId = getRoleId(roleName);
      if (!roleId) {
        result.failed.push({
          role: roleName,
          action: 'remove',
          error: 'Role not found in available roles',
        });
        continue;
      }

      const removeRes = await fetch(
        `${baseUrl}/admin/assignments/users/${userId}/roles/${roleId}`,
        { method: 'DELETE', headers }
      );

      if (!removeRes.ok) {
        const errorText = await removeRes.text();
        result.failed.push({
          role: roleName,
          action: 'remove',
          error: `${removeRes.status}: ${errorText}`,
        });
      } else {
        result.removed.push(roleName);
      }
    } catch (error) {
      result.failed.push({
        role: roleName,
        action: 'remove',
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  // 5. Verify final state (optional but recommended)
  const verifyRes = await fetch(`${baseUrl}/admin/users/${userId}`, { headers });
  if (verifyRes.ok) {
    // we intentionally don't log the final roles here to keep console clean
    await verifyRes.json();
  }

  return result;
}

/**
 * Helper to format result for user-friendly messages
 */
export function formatRoleChangeResult(result: RoleChangeResult): string {
  const messages: string[] = [];

  if (result.added.length > 0) {
    messages.push(`✅ Roles asignados: ${result.added.join(', ')}`);
  }

  if (result.removed.length > 0) {
    messages.push(`🗑️ Roles removidos: ${result.removed.join(', ')}`);
  }

  if (result.failed.length > 0) {
    messages.push(`❌ Fallos: ${result.failed.map(f => `${f.role} (${f.action})`).join(', ')}`);
  }

  return messages.join('\n') || 'Sin cambios';
}
