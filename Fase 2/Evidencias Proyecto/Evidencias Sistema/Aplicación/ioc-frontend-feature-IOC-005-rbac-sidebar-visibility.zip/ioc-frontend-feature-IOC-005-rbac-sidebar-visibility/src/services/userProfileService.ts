// =================================================================
// User Profile Service
// Servicio para obtener información del perfil del usuario actual
// =================================================================

export interface UserProfile {
  id: number;
  email: string;
  fullName: string;
  plantaId: number;
  plantaCode: string;
  plantaName: string;
  centroCosto: string;
  fechaContrato: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  roles: string[];
}

/**
 * Obtiene el perfil del usuario autenticado desde /api/v1/users/me
 */
export const fetchUserProfile = async (token: string): Promise<UserProfile | null> => {
  try {
    const res = await fetch('/api/v1/users/me', {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });

    if (!res.ok) {
      console.warn('GET /api/v1/users/me failed with status:', res.status);
      return null;
    }

    const json = await res.json();
    return json as UserProfile;
  } catch (error) {
    console.error('Error fetching user profile:', error);
    return null;
  }
};

