// =================================================================
// Permission Assignment Service
// Implements the correct flow documented in .gemini/frontend-role-permissions-agent.md
// =================================================================

import { Permission } from '../types/user-management';

/**
 * Service to synchronize role permissions using the correct backend endpoints.
 *
 * IMPORTANT: The backend does NOT accept 'permissions' field in PUT /api/v1/admin/roles/{id}
 * Instead, use the dedicated assignment endpoints:
 * - POST /api/v1/admin/assignments/roles/{roleId}/permissions/{permissionId}
 * - DELETE /api/v1/admin/assignments/roles/{roleId}/permissions/{permissionId}
 */

interface SyncPermissionsOptions {
  roleId: number;
  desiredPermissionIds: number[];
  availablePermissions: Permission[];
  token: string;
  baseUrl?: string;
}

interface PermissionChangeResult {
  added: number[];
  removed: number[];
  failed: Array<{ permissionId: number; action: 'add' | 'remove'; error: string }>;
}

/**
 * Synchronize role permissions using the assignment endpoints.
 *
 * Flow:
 * 1. GET current role permissions
 * 2. Calculate diff (toAdd, toRemove)
 * 3. POST to assign new permissions
 * 4. DELETE to remove old permissions
 * 5. Verify final state
 */
export async function syncRolePermissions(options: SyncPermissionsOptions): Promise<PermissionChangeResult> {
  const { roleId, desiredPermissionIds, availablePermissions, token, baseUrl = '/api/v1' } = options;

  const headers = {
    'Authorization': `Bearer ${token}`,
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  };

  const result: PermissionChangeResult = {
    added: [],
    removed: [],
    failed: [],
  };

  // 1. Get current role permissions
  const roleRes = await fetch(`${baseUrl}/admin/roles/${roleId}`, { headers });

  if (!roleRes.ok) {
    throw new Error(`Failed to fetch role: ${roleRes.status} ${roleRes.statusText}`);
  }

  const role = await roleRes.json();

  // Backend can return permissions as strings (names), numbers (IDs), or Permission objects
  const currentPermissions = new Set<number>(
    (role.permissions || []).map((p: Permission | number | string) => {
      if (typeof p === 'number') return p;
      if (typeof p === 'string') {
        // Permission is a name string, find the ID from availablePermissions
        const found = availablePermissions.find(ap => ap.name === p);
        return found ? found.id : -1; // -1 will be filtered out
      }
      return p.id;
    }).filter((id: number) => id !== -1)
  );

  // 2. Calculate differences
  const desired = new Set<number>(desiredPermissionIds);
  const toAdd = Array.from(desired).filter(id => !currentPermissions.has(id));
  const toRemove = Array.from(currentPermissions).filter(id => !desired.has(id));

  // Helper: validate permission exists
  const permissionExists = (permissionId: number): boolean => {
    return availablePermissions.some(p => p.id === permissionId);
  };

  // 3. Assign new permissions
  for (const permissionId of toAdd) {
    try {
      if (!permissionExists(permissionId)) {
        result.failed.push({
          permissionId,
          action: 'add',
          error: 'Permission not found in available permissions',
        });
        continue;
      }

      const assignRes = await fetch(
        `${baseUrl}/admin/assignments/roles/${roleId}/permissions/${permissionId}`,
        { method: 'POST', headers }
      );

      if (!assignRes.ok) {
        const errorText = await assignRes.text();
        result.failed.push({
          permissionId,
          action: 'add',
          error: `${assignRes.status}: ${errorText}`,
        });
      } else {
        result.added.push(permissionId);
      }
    } catch (error) {
      result.failed.push({
        permissionId,
        action: 'add',
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  // 4. Remove old permissions
  for (const permissionId of toRemove) {
    try {
      if (!permissionExists(permissionId)) {
        result.failed.push({
          permissionId,
          action: 'remove',
          error: 'Permission not found in available permissions',
        });
        continue;
      }

      const removeRes = await fetch(
        `${baseUrl}/admin/assignments/roles/${roleId}/permissions/${permissionId}`,
        { method: 'DELETE', headers }
      );

      if (!removeRes.ok) {
        const errorText = await removeRes.text();
        result.failed.push({
          permissionId,
          action: 'remove',
          error: `${removeRes.status}: ${errorText}`,
        });
      } else {
        result.removed.push(permissionId);
      }
    } catch (error) {
      result.failed.push({
        permissionId,
        action: 'remove',
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  // 5. Verify final state (optional but recommended)
  const verifyRes = await fetch(`${baseUrl}/admin/roles/${roleId}`, { headers });
  if (verifyRes.ok) {
    await verifyRes.json();
  }

  return result;
}

/**
 * Helper to format result for user-friendly messages
 */
export function formatPermissionChangeResult(result: PermissionChangeResult): string {
  const messages: string[] = [];

  if (result.added.length > 0) {
    messages.push(`✅ Permisos asignados: ${result.added.length}`);
  }

  if (result.removed.length > 0) {
    messages.push(`🗑️ Permisos removidos: ${result.removed.length}`);
  }

  if (result.failed.length > 0) {
    messages.push(`❌ Fallos: ${result.failed.length}`);
  }

  return messages.join('\n') || 'Sin cambios';
}

