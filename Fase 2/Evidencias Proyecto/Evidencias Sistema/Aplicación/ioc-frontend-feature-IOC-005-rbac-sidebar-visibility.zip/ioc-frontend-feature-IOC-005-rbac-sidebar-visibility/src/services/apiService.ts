import axios, { AxiosInstance } from "axios";
import type { StartProcessResponse, EtlJobStatusDto } from "../types/api";
import { getApiBaseUrl } from '../utils/getApiBaseUrl';
let tokenProvider: (() => Promise<string | null> | string | null) | null = null;
let signOutHandler: (() => Promise<void> | void) | null = null;

export function setTokenProvider(provider: typeof tokenProvider) {
  tokenProvider = provider;
}

export function setSignOut(handler: typeof signOutHandler) {
  signOutHandler = handler;
}

// ETL endpoints are mounted under /api/etl (not under /api/v1).
// Use the normalized API base (origin or value from VITE_API_BASE_URL) but
// strip any trailing `/api/v1` if present to avoid creating `/api/v1/api/etl`.
const rawBase = getApiBaseUrl();
let apiBaseURL = rawBase.replace(/\/api\/v1$/, '');

// If the configured base accidentally includes ETL-specific paths (e.g. '/api/etl' or a full
// endpoint like '/api/etl/start-process'), prefer the origin so that POST /api/etl/start-process
// resolves correctly and we don't produce duplicated paths.
try {
  const u = new URL(rawBase);
  if (u.pathname.includes('/api/etl')) {
    console.warn('[apiService] VITE_API_BASE_URL contains ETL path; using origin to avoid duplicate paths.');
    apiBaseURL = u.origin;
  }
} catch {
  // ignore URL parsing errors
}

apiBaseURL = apiBaseURL.replace(/\/$/, '');

// Create axios instance for ETL endpoints
const client: AxiosInstance = axios.create({
  baseURL: apiBaseURL,
  // Don't set a default Content-Type - let axios auto-detect based on request body
  // (FormData will be sent as multipart/form-data, JSON will be application/json)
});

// Add request interceptor to include JWT token
client.interceptors.request.use(
  async (config) => {
    if (tokenProvider) {
      const token = await tokenProvider();
      if (token) {
        config.headers = config.headers || {};
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Add response interceptor to handle auth errors
client.interceptors.response.use(
  (res) => res,
  async (error) => {
    const status = error?.response?.status as number | undefined;
    if ((status === 401 || status === 403) && signOutHandler) {
      try { await signOutHandler(); } catch {
        // ignore signOut errors
      }
    }
    return Promise.reject(error);
  }
);

export async function startEtlProcess(file: File, opts?: { signal?: AbortSignal }): Promise<StartProcessResponse> {
  const form = new FormData();
  form.append("file", file);
  const res = await client.post<StartProcessResponse>("/api/etl/start-process", form, {
    signal: opts?.signal,
    headers: { Accept: "application/json" },
  });
  return res.data;
}

export async function getEtlJobStatus(jobId: string, opts?: { signal?: AbortSignal }): Promise<EtlJobStatusDto> {
  const res = await client.get<EtlJobStatusDto>(`/api/etl/jobs/${encodeURIComponent(jobId)}/status`, {
    signal: opts?.signal,
    headers: { Accept: "application/json" },
  });
  return res.data;
}

