// =================================================================
// FTV-001: User Management Page
// Fuente de Verdad: Feature IOC-004 - User Role Management
// =================================================================

import React, { useState, useEffect, useRef } from 'react';
import { useList, useDelete, useCreate, useUpdate } from '@refinedev/core';
import { User, Role } from '../../../types/user-management';
import { UserFormValues } from '../../../schemas/user.schema';
import { UserTable } from '../../../components/admin/user-management/UserTable';
import { UserFormModal } from '../../../components/admin/user-management/UserFormModal';
import { RoleAssignmentModal } from '../../../components/admin/user-management/RoleAssignmentModal';
import { EmptyState } from '../../../components/admin/user-management/EmptyState';
import toast from 'react-hot-toast';
import { normalizeListResponse } from '../../../utils/normalizeListResponse';
import { TableSkeleton } from '../../../components/common/TableSkeleton';
import MetricCardSkeleton from '../../../components/ui/skeletons/MetricCardSkeleton';
import { normalizeUser } from '../../../utils/normalizeUser';
import { syncUserRoles } from '../../../services/roleAssignmentService';
import { supabase } from '../../../lib/supabaseClient';

export const UserManagementPage: React.FC = () => {
  // Estados locales
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Local overrides for specific users (used to show instant UI updates after role sync)
  const [userOverrides, setUserOverrides] = useState<Record<number, User>>({});

  // Fetch users using Refine hooks
  type UseListUsersResult = {
    // Some providers return { data: User[] } and others may return { data: { data: User[] } }
    data?: { data?: User[] } | User[];
    result?: unknown;
    isLoading?: boolean;
    isFetching?: boolean;
    refetch?: () => void;
  };

  const usersList = useList({
    resource: 'admin/users',
    pagination: { pageSize: 50 },
  }) as unknown as UseListUsersResult;

  // Normalize different possible shapes returned by the dataProvider/backend
  const rawUsersData = (usersList.result ?? usersList.data) ?? usersList;

  const users = normalizeListResponse<User>(rawUsersData);

  // Apply local overrides to show the most recent data immediately.
  const usersWithMappedNames = users.map((u) => {
    const normalized = normalizeUser(u);
    const overridden = userOverrides[normalized.id];
    return overridden ?? normalized;
  });

  // Read loading flags separately (some providers expose one or the other)
  const isLoading = usersList.isLoading ?? false;
  const isFetching = usersList.isFetching ?? false;
  const refetch = usersList.refetch;

  // Controlled skeleton state with minimum display time and a maximum guard.
  const [showSkeleton, setShowSkeleton] = useState(true);
  const mountedAtRef = useRef<number | null>(null);
  const maxTimeoutRef = useRef<number | null>(null);

  // Detect if the provider returned any data/result shape (stable primitive flag)
  const hasFetchedData = typeof usersList.data !== 'undefined' || typeof usersList.result !== 'undefined';

  // When server data changes (refetch), clear local overrides so server state takes precedence.
  // ⚠️ DISABLED temporarily to allow overrides to persist until server catches up
  // useEffect(() => {
  //   if (typeof rawUsersData !== 'undefined') {
  //     // clear overrides that may be stale after a successful refetch
  //     setUserOverrides(prev => (Object.keys(prev).length ? {} : prev));
  //   }
  // }, [rawUsersData]);

  useEffect(() => {
    mountedAtRef.current = Date.now();
    // If provider flags indicate loading, keep skeleton. Otherwise we'll
    // wait for provider data or a small minimum time.
    // Start a max guard so skeleton doesn't remain forever if provider never responds.
    const MAX_MS = 3000; // don't keep skeleton forever
    maxTimeoutRef.current = window.setTimeout(() => {
      setShowSkeleton(false);
    }, MAX_MS) as unknown as number;

    return () => {
      if (maxTimeoutRef.current) {
        clearTimeout(maxTimeoutRef.current);
        maxTimeoutRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const MIN_MS = 200;

    // If provider says loading/fetching, show skeleton immediately
    if (isLoading || isFetching) {
      setShowSkeleton(true);
      return;
    }

    // Provider not loading: use the precomputed stable flag or fallback to users.length
    const effectiveHasFetched = hasFetchedData || users.length > 0;

    const mountedAt = mountedAtRef.current ?? 0;
    const elapsed = Date.now() - mountedAt;

    if (effectiveHasFetched && elapsed >= MIN_MS) {
      setShowSkeleton(false);
    } else if (effectiveHasFetched) {
      // Ensure minimum display time
      const remaining = MIN_MS - elapsed;
      const t = window.setTimeout(() => setShowSkeleton(false), remaining);
      return () => clearTimeout(t);
    }
    // Otherwise: keep showing skeleton until data arrives or max timeout fires
  }, [isLoading, isFetching, hasFetchedData, users.length]);

  // Debug toggle: force skeleton when ?skeleton=1 is present (useful for testing)
  const forceSkeleton = typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('skeleton') === '1';
  if (forceSkeleton) console.debug('[UserManagement] forceSkeleton active via query param');

  const showLoading = forceSkeleton || showSkeleton;

  // ✅ Solo consideramos que terminó la carga si:
  // 1. No está en loading/fetching
  // 2. El skeleton está oculto
  // 3. Los datos fueron efectivamente obtenidos del backend
  const isReallyLoaded = !isLoading && !isFetching && !showLoading && hasFetchedData;

  // Mutations
  const { mutate: deleteUser } = useDelete();
  const { mutate: createUser } = useCreate();
  const { mutate: updateUser } = useUpdate();

  // Handlers
  const handleCreateUser = () => {
    setSelectedUser(null);
    setIsCreateModalOpen(true);
  };

  const handleEditUser = (user: User) => {
    setSelectedUser(user);
    setIsEditModalOpen(true);
  };

  const handleDeleteUser = (user: User) => {
    if (confirm('¿Estás seguro de eliminar este usuario? Esta acción no se puede deshacer.')) {
      deleteUser(
        {
          resource: 'admin/users',
          id: String(user.id)
        },
        {
          onSuccess: () => {
            toast.success('Usuario eliminado exitosamente');
            refetch?.();
          },
          onError: (error) => {
            console.error('Error deleting user:', error);
            toast.error('Error al eliminar usuario');
          },
        }
      );
    }
  };

  const handleAssignRoles = (user: User) => {
    setSelectedUser(user);
    setIsRoleModalOpen(true);
  };

  // Helper: fetch fresh single user and store override
  const fetchAndOverrideUser = async (userId: number, token?: string) => {
    try {
      const headers: Record<string, string> = { Accept: 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/v1/admin/users/${userId}`, { headers });
      if (!res.ok) {
        return null;
      }
      const raw = await res.json();
      const normalized = normalizeUser(raw);
      setUserOverrides(prev => {
        const updated = { ...prev, [userId]: normalized };
        return updated;
      });
      return normalized;
    } catch {
      // swallow error silently; UI will refetch or stay optimistic
      return null;
    }
  };

  // Filtrado local
  const filteredUsers = usersWithMappedNames.filter((user: User) =>
    user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.primerNombre?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.primerApellido?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Load available roles for RoleAssignmentModal
  type UseListRolesResult = {
    data?: { data?: Role[] };
    isLoading?: boolean;
    refetch?: () => void;
  };

  const rolesListForModal = useList({
    resource: 'admin/roles',
    pagination: { pageSize: 200 },
  }) as unknown as UseListRolesResult;

  const rawRolesForModal = (rolesListForModal as unknown as Record<string, unknown>)?.['result'] ??
    (rolesListForModal as unknown as Record<string, unknown>)?.['data'] ?? rolesListForModal;

  const availableRoles = normalizeListResponse<Role>(rawRolesForModal);
  const rolesLoading = rolesListForModal.isLoading ?? false;

  // Handler to save assigned roles for a user
  // ⚠️ IMPORTANT: Uses the correct assignment endpoints, NOT PUT /admin/users/{id}
  // See: .gemini/frontend-role-agent.md for full documentation
  const handleSaveRoles = async (userId: number, roleIds: number[]): Promise<void> => {
    // Map numeric IDs to role names (strings)
    const missing = roleIds.filter(id => !availableRoles.some(r => r.id === id));
    if (missing.length > 0) {
      const msg = `Roles inválidos: ${missing.join(',')}`;
      console.error('[UserManagement] handleSaveRoles invalid role ids:', { missing });
      toast.error('No se pudieron asignar roles: hay roles inválidos');
      throw new Error(msg);
    }

    const roleNames: string[] = roleIds
      .map(id => availableRoles.find(r => r.id === id)!.name);

    // Optimistic update: show new roles immediately in the UI
    try {
      const existing = usersWithMappedNames.find(u => u.id === userId);
      const optimistic: User = {
        id: userId,
        supabaseUserId: existing?.supabaseUserId ?? '',
        email: existing?.email ?? '',
        primerNombre: existing?.primerNombre ?? '',
        segundoNombre: existing?.segundoNombre ?? undefined,
        primerApellido: existing?.primerApellido ?? '',
        segundoApellido: existing?.segundoApellido ?? undefined,
        plantaId: existing?.plantaId ?? undefined,
        plantaNombre: existing?.plantaNombre ?? undefined,
        centroCosto: existing?.centroCosto ?? undefined,
        fechaContrato: existing?.fechaContrato ?? undefined,
        isActive: existing?.isActive ?? true,
        lastLoginAt: existing?.lastLoginAt ?? undefined,
        createdAt: existing?.createdAt ?? new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        deletedAt: existing?.deletedAt ?? undefined,
        roles: roleNames,
      } as User;

      setUserOverrides(prev => ({ ...prev, [userId]: optimistic }));
    } catch {
      // ignore optimistic failures
    }

    try {
      // Get auth token
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;

      if (!token) {
        toast.error('No se encontró token de autenticación');
        throw new Error('No authentication token');
      }

      // Use the correct role assignment service
      toast.loading('Actualizando roles...', { id: 'role-sync' });

      const result = await syncUserRoles({
        userId,
        desiredRoleNames: roleNames,
        availableRoles,
        token,
      });

      // Report results
      if (result.failed.length > 0) {
        toast.error(
          `Roles parcialmente actualizados. Fallos: ${result.failed.length}`,
          { id: 'role-sync' }
        );
        // If partial/failed, refetch to reconcile the real state
        refetch?.();
        try {
          await fetchAndOverrideUser(userId, token);
        } catch {
          void fetchAndOverrideUser(userId);
        }
      } else {
        toast.success('Roles actualizados exitosamente', { id: 'role-sync' });
      }

      // Refresh user list to show updated roles (ask the hook to refetch),
      // and also fetch the single user to apply an immediate override in UI.
      refetch?.();

      // fetch the fresh user and apply override so UI updates instantly even if list endpoint is eventually consistent
      try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token;
        await fetchAndOverrideUser(userId, token);
      } catch {
        // best-effort
        void fetchAndOverrideUser(userId);
      }
    } catch (error) {
      toast.error('Error al actualizar roles', { id: 'role-sync' });
      throw error;
    }
  };

  // Handlers for create/update to pass to UserFormModal
  // ⚠️ IMPORTANT: Backend does NOT accept 'roles' in POST body either
  // We create the user first, then assign roles using the assignment endpoints
  const handleCreateSubmit = async (data: UserFormValues): Promise<void> => {
    // Validate roles
    const roleIds = data.roles || [];
    const missing = roleIds.filter(id => !availableRoles.some(r => r.id === id));
    if (missing.length > 0) {
      const msg = `Roles inválidos en creación: ${missing.join(',')}`;
      console.error('[UserManagement] handleCreateSubmit invalid role ids:', { missing });
      toast.error('No se pudo crear el usuario: roles inválidos seleccionados');
      throw new Error(msg);
    }

    const roleNames = roleIds.map(id => availableRoles.find(r => r.id === id)!.name);

    // Remove roles from payload (backend doesn't accept it)
    // roles intentionally ignored (assigned separately via assignment endpoints)
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { roles: _roles, ...userDataWithoutRoles } = data;
    const payload = userDataWithoutRoles as unknown as Record<string, unknown>;

    try {
      toast.loading('Creando usuario...', { id: 'create-user' });

      // Step 1: Create the user (without roles)
      const createdUser = await new Promise<User>((resolve, reject) => {
        createUser(
          {
            resource: 'admin/users',
            values: payload,
          },
          {
            onSuccess: (response) => {
              const userData = response?.data as User;
              resolve(userData);
            },
            onError: (error) => {
              console.error('Error creating user:', error);
              reject(error);
            },
          }
        );
      });

      toast.success('Usuario creado', { id: 'create-user' });

      // Step 2: Assign roles if any were selected
      if (roleNames.length > 0 && createdUser?.id) {
        toast.loading('Asignando roles...', { id: 'assign-roles' });

        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token;

        if (!token) {
          toast.error('No se encontró token de autenticación', { id: 'assign-roles' });
          throw new Error('No authentication token');
        }

        const result = await syncUserRoles({
          userId: createdUser.id,
          desiredRoleNames: roleNames,
          availableRoles,
          token,
        });

        if (result.failed.length > 0) {
          toast.error(
            `Usuario creado pero algunos roles fallaron: ${result.failed.length}`,
            { id: 'assign-roles' }
          );
        } else {
          toast.success('Roles asignados exitosamente', { id: 'assign-roles' });
        }

        // Apply override for the new user to show roles immediately
        try {
          const { data: { session } } = await supabase.auth.getSession();
          const token = session?.access_token;
          await fetchAndOverrideUser(createdUser.id, token);
        } catch {
          void fetchAndOverrideUser(createdUser.id);
        }
      }

      // Success: refresh and close modal
      refetch?.();
      setIsCreateModalOpen(false);
    } catch (error) {
      console.error('Error in handleCreateSubmit:', error);
      toast.error('Error al crear usuario', { id: 'create-user' });
      throw error;
    }
  };

  const handleUpdateSubmit = async (data: UserFormValues): Promise<void> => {
    if (!selectedUser) {
      throw new Error('No selected user');
    }

    // Validate roles
    const roleIds = data.roles || [];
    const missing = roleIds.filter(id => !availableRoles.some(r => r.id === id));
    if (missing.length > 0) {
      const msg = `Roles inválidos en actualización: ${missing.join(',')}`;
      console.error('[UserManagement] handleUpdateSubmit invalid role ids:', { missing });
      toast.error('No se pudo actualizar el usuario: roles inválidos seleccionados');
      throw new Error(msg);
    }

    const roleNames = roleIds.map(id => availableRoles.find(r => r.id === id)!.name);

    // Remove roles from payload (backend doesn't accept it in PUT)
    // roles intentionally ignored (assigned separately via assignment endpoints)
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { roles: _roles, ...userDataWithoutRoles } = data;
    const payload = userDataWithoutRoles as unknown as Record<string, unknown>;

    try {
      toast.loading('Actualizando usuario...', { id: 'update-user' });

      // Step 1: Update user basic data (without roles)
      await new Promise<void>((resolve, reject) => {
        updateUser(
          {
            resource: 'admin/users',
            id: selectedUser.id,
            values: payload,
          },
          {
            onSuccess: () => {
              resolve();
            },
            onError: (error) => {
              console.error('Error updating user:', error);
              reject(error);
            },
          }
        );
      });

      toast.success('Usuario actualizado', { id: 'update-user' });

      // Step 2: Sync roles using the correct assignment endpoints
      toast.loading('Actualizando roles...', { id: 'update-roles' });

      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;

      if (!token) {
        toast.error('No se encontró token de autenticación', { id: 'update-roles' });
        throw new Error('No authentication token');
      }

      const result = await syncUserRoles({
        userId: selectedUser.id,
        desiredRoleNames: roleNames,
        availableRoles,
        token,
      });

      if (result.failed.length > 0) {
        toast.error(
          `Usuario actualizado pero algunos roles fallaron: ${result.failed.length}`,
          { id: 'update-roles' }
        );
      } else {
        toast.success('Roles actualizados exitosamente', { id: 'update-roles' });
      }

      // Success: refresh and close modal
      refetch?.();

      // Fetch and override the updated user so UI reflects changes immediately
      try {
        await fetchAndOverrideUser(selectedUser.id, token);
      } catch {
        void fetchAndOverrideUser(selectedUser.id);
      }
      setIsEditModalOpen(false);
      setSelectedUser(null);
    } catch (error) {
      console.error('Error in handleUpdateSubmit:', error);
      toast.error('Error al actualizar usuario', { id: 'update-user' });
      throw error;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Gestión de Usuarios
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            Administra usuarios y sus permisos de acceso al sistema
          </p>
        </div>
        <button
          onClick={handleCreateUser}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700
                     transition-colors flex items-center gap-2 focus:outline-none focus:ring-2
                     focus:ring-blue-500 focus:ring-offset-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Nuevo Usuario
        </button>
      </div>

      {/* Search Bar */}
      <div className="flex gap-4">
        <div className="flex-1">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input
              type="text"
              placeholder="Buscar por nombre o email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600
                         rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white
                         focus:ring-2 focus:ring-blue-500 focus:border-transparent
                         placeholder-gray-400 dark:placeholder-gray-500"
            />
          </div>
        </div>
      </div>

      {/* Stats Card - use centralized MetricCardSkeleton for loading */}
      {showLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <MetricCardSkeleton key={i} />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <svg className="w-6 h-6 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                        d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total Usuarios</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{users.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                <svg className="w-6 h-6 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Usuarios Activos</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {users.filter((u: User) => u.isActive).length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
                <svg className="w-6 h-6 text-purple-600 dark:text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                        d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                </svg>
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Resultados</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{filteredUsers.length}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Empty State - Only show when NOT loading and there are no users */}
      {isReallyLoaded && filteredUsers.length === 0 && users.length === 0 && (
        <EmptyState
          title="No hay usuarios registrados"
          description="Comienza creando tu primer usuario en el sistema"
          actionLabel="Crear Usuario"
          onAction={handleCreateUser}
        />
      )}

      {/* No Results State - Only show when NOT loading, have users, but filter returned nothing */}
      {isReallyLoaded && filteredUsers.length === 0 && users.length > 0 && (
        <div className="text-center py-12">
          <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-white">No se encontraron resultados</h3>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Intenta con otros términos de búsqueda
          </p>
        </div>
      )}

      {/* User Table: show skeleton during loading OR table when we have data */}
      {showLoading ? (
        <TableSkeleton rows={5} columns={6} />
      ) : filteredUsers.length > 0 ? (
        <UserTable
          users={filteredUsers}
          loading={false}
          onEdit={handleEditUser}
          onDelete={handleDeleteUser}
          onAssignRoles={handleAssignRoles}
        />
      ) : null}

      {/* Modals */}
      {isCreateModalOpen && (
        <UserFormModal
          isOpen={isCreateModalOpen}
          onClose={() => {
            setIsCreateModalOpen(false);
            refetch?.();
          }}
          onSave={handleCreateSubmit}
          availableRoles={availableRoles}
          rolesLoading={rolesLoading}
        />
      )}

      {isEditModalOpen && selectedUser && (
        <UserFormModal
          isOpen={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            refetch?.();
          }}
          onSave={handleUpdateSubmit}
          user={selectedUser}
          availableRoles={availableRoles}
          rolesLoading={rolesLoading}
        />
      )}

      {isRoleModalOpen && selectedUser && (
        <RoleAssignmentModal
          isOpen={isRoleModalOpen}
          onClose={() => {
            setIsRoleModalOpen(false);
            refetch?.();
          }}
          user={selectedUser}
          availableRoles={availableRoles}
          onSave={handleSaveRoles}
          loading={rolesLoading}
        />
      )}
    </div>
  );
};

