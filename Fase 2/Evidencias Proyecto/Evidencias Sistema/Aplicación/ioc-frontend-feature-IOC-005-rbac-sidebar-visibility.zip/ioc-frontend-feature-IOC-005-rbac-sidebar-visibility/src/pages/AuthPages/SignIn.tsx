import PageMeta from "../../components/common/PageMeta";
import AuthLayout from "./AuthPageLayout";
import SignInForm from "../../components/auth/SignInForm";

export default function SignIn() {
  return (
    <>
      <PageMeta
        title="IOC - Cambiaso"
        description="Iniciar sesión - Sistema IOC Cambiaso"
      />
      <AuthLayout>
        <SignInForm />
      </AuthLayout>
    </>
  );
}
