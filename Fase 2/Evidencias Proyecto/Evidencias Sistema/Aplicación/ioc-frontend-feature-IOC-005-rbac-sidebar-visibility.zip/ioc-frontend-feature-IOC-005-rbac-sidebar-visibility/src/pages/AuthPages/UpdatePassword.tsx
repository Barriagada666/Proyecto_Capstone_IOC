import PageMeta from "../../components/common/PageMeta";
import AuthLayout from "./AuthPageLayout";
import UpdatePasswordForm from "../../components/auth/UpdatePasswordForm";

export default function UpdatePassword() {
  return (
    <>
      <PageMeta
        title="IOC - Cambiaso"
        description="Actualizar contraseña - Sistema IOC Cambiaso"
      />
      <AuthLayout>
        <UpdatePasswordForm />
      </AuthLayout>
    </>
  );
}
