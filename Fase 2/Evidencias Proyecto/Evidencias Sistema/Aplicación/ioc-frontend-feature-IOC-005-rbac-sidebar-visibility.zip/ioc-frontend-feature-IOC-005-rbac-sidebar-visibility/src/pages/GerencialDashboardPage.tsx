import React, { useCallback } from 'react';
import DashboardEmbed from '../components/DashboardEmbed';
import { useAuth } from '../hooks/useAuth';
import PageBreadcrumb from '../components/common/PageBreadCrumb';
import { getValidatedEnvId } from '../utils/env';
import loggingService from '../services/loggingService';

const DASHBOARD_GERENCIAL_ID = getValidatedEnvId('VITE_DASHBOARD_GERENCIAL_ID', 'Dashboard Gerencial ID');

const GerencialDashboardPage: React.FC = () => {
  const { user } = useAuth();

  const handleDashboardError = useCallback((error: Error, dashboardId: number) => {
    loggingService.error('Error al cargar el dashboard', {
      dashboardId,
      error: error.message,
    });
  }, []);

  const handleDashboardLoad = useCallback((dashboardId: number) => {
    loggingService.info(`Dashboard ${dashboardId} cargado exitosamente.`);
  }, []);

  // Simulación de roles hasta que se implementen en el backend/JWT
  const userRoles = user ? ['ROLE_ADMIN', 'ROLE_USER'] : [];
  const hasRole = (role: string) => userRoles.includes(role);

  return (
    <>
      <PageBreadcrumb pageTitle="Dashboard Gerencial" />
      <div className="p-4 md:p-6 space-y-6">
        {/* Dashboard Gerencial - User y Admin */}
        {(hasRole('ROLE_USER') || hasRole('ROLE_ADMIN')) && DASHBOARD_GERENCIAL_ID > 0 && (
          <section>
            <div className="mb-4">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white/90">Dashboard Gerencial</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">Indicadores y métricas gerenciales.</p>
            </div>
            <DashboardEmbed
              dashboardId={DASHBOARD_GERENCIAL_ID}
              className="h-[600px]"
              onError={(error) => handleDashboardError(error, DASHBOARD_GERENCIAL_ID)}
              onLoad={() => handleDashboardLoad(DASHBOARD_GERENCIAL_ID)}
            />
          </section>
        )}

        {/* Mensaje si no tiene acceso a ningún dashboard */}
        {userRoles.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">
              No tienes acceso a ningún dashboard. Por favor, contacta a tu administrador.
            </p>
          </div>
        )}
      </div>
    </>
  );
};

export default GerencialDashboardPage;

