// =================================================================
// FTV-003: Permission Management Page
// Fuente de Verdad: .gemini/blueprints/frontend/IOC-004-user-role-management/ftv-003-permission-management-page.md
// =================================================================

import React, { useState } from 'react';
import { useList, useDelete, useCreate } from '@refinedev/core';
import { Permission, GroupedPermissions } from '../../../types/user-management';
import { EmptyState } from '../../../components/admin/user-management/EmptyState';
import { RoleBadge } from '../../../components/admin/user-management/RoleBadge';
import toast from 'react-hot-toast';

export const PermissionManagementPage: React.FC = () => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', description: '', category: '' });

  // Fetch permissions
  type UseListPermissionsResult = {
    result?: { data?: Permission[] };
    query?: { isFetching?: boolean; refetch?: () => void; data?: Permission[] };
  };

  const permissionsList = useList({
    resource: 'admin/permissions',
    pagination: { pageSize: 100 },
  }) as unknown as UseListPermissionsResult;

  const permissions = permissionsList.result?.data || permissionsList.query?.data || [];
  const isLoading = permissionsList.query?.isFetching ?? false;
  const refetch = permissionsList.query?.refetch;

  // Mutations
  const { mutate: createPermission } = useCreate();
  const { mutate: deletePermission } = useDelete();

  // Group permissions by category
  const groupedPermissions: GroupedPermissions = permissions.reduce((acc: GroupedPermissions, permission: Permission) => {
    const category = permission.category || 'Sin Categoría';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(permission);
    return acc;
  }, {} as GroupedPermissions);

  const handleCreatePermission = async (e: React.FormEvent) => {
    e.preventDefault();

    createPermission(
      {
        resource: 'admin/permissions',
        values: formData,
      },
      {
        onSuccess: () => {
          toast.success('Permiso creado exitosamente');
          if (typeof refetch === 'function') refetch();
          setIsCreateModalOpen(false);
          setFormData({ name: '', description: '', category: '' });
        },
        onError: (error: unknown) => {
          const err = error as { response?: { data?: { message?: string } } };
          toast.error(err?.response?.data?.message || 'Error al crear permiso');
        },
      }
    );
  };

  const handleDeletePermission = async (permission: Permission) => {
    if (!window.confirm(`¿Está seguro de eliminar el permiso ${permission.name}?`)) {
      return;
    }

    deletePermission(
      {
        resource: 'admin/permissions',
        id: permission.id,
      },
      {
        onSuccess: () => {
          toast.success('Permiso eliminado exitosamente');
          if (typeof refetch === 'function') refetch();
        },
        onError: (error) => {
          toast.error('Error al eliminar permiso');
          console.error(error);
        },
      }
    );
  };

  return (
    <div className="p-6">
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Gestión de Permisos
        </h1>
        <p className="text-sm text-gray-600 dark:text-gray-400">
          Administra los permisos del sistema y visualiza los roles asociados
        </p>
      </div>

      {/* Statistics */}
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Total Permisos</h3>
            <p className="text-3xl font-bold text-gray-900 dark:text-white">{permissions.length}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Categorías</h3>
            <p className="text-3xl font-bold text-gray-900 dark:text-white">
              {Object.keys(groupedPermissions).length}
            </p>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="mb-6 flex justify-end">
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white font-medium text-sm rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Crear Permiso
        </button>
      </div>

      {/* Permissions List */}
      <div className="space-y-6">
        {isLoading ? (
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-12 text-center">
            <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto" />
          </div>
        ) : permissions.length === 0 ? (
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            <EmptyState
              title="No hay permisos"
              description="Aún no se han creado permisos en el sistema. Comienza agregando el primer permiso."
              actionLabel="Crear Permiso"
              onAction={() => setIsCreateModalOpen(true)}
            />
          </div>
        ) : (
          Object.entries(groupedPermissions).map(([category, perms]) => (
            <div
              key={category}
              className="bg-white dark:bg-gray-900 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden"
            >
              {/* Category Header */}
              <div className="bg-gray-50 dark:bg-gray-800 px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                  {category}
                  <span className="ml-2 text-sm font-normal text-gray-500 dark:text-gray-400">
                    ({perms.length} {perms.length === 1 ? 'permiso' : 'permisos'})
                  </span>
                </h2>
              </div>

              {/* Permissions */}
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {perms.map((permission) => (
                  <div
                    key={permission.id}
                    className="p-6 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-1">
                          {permission.name}
                        </h3>
                        {permission.description && (
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                            {permission.description}
                          </p>
                        )}
                        {permission.roles && permission.roles.length > 0 && (
                          <div className="flex flex-wrap gap-2">
                            <span className="text-xs text-gray-500 dark:text-gray-400">
                              Roles con este permiso:
                            </span>
                            {permission.roles.map((role) => (
                              <RoleBadge key={role} role={role} size="sm" />
                            ))}
                          </div>
                        )}
                      </div>
                      <button
                        onClick={() => handleDeletePermission(permission)}
                        className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors ml-4"
                        title="Eliminar"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Create Permission Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setIsCreateModalOpen(false)}>
          <div
            className="bg-white dark:bg-gray-900 rounded-lg shadow-xl max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Crear Permiso</h2>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <form onSubmit={handleCreatePermission} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Nombre del Permiso <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value.toUpperCase() })}
                  placeholder="MODULO:ACCION"
                  required
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Categoría
                </label>
                <input
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  placeholder="Nombre de la categoría"
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Descripción
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                >
                  Crear
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
