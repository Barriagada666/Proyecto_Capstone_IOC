// =================================================================
// FTV-002: Role Management Page
// Fuente de Verdad: Feature IOC-004 - User Role Management
// =================================================================

import React, { useState, useEffect, useRef } from 'react';
import { useList, useDelete, useCreate, useUpdate } from '@refinedev/core';
import { Role, Permission } from '../../../types/user-management';
import { EmptyState } from '../../../components/admin/user-management/EmptyState';
import { RoleBadge } from '../../../components/admin/user-management/RoleBadge';
import { PermissionAssignmentModal } from '../../../components/admin/user-management/PermissionAssignmentModal';
import toast from 'react-hot-toast';
import { normalizeListResponse } from '../../../utils/normalizeListResponse';
import DashboardSkeleton from '../../../components/ui/skeletons/DashboardSkeleton';
import MetricCardSkeleton from '../../../components/ui/skeletons/MetricCardSkeleton';
import { syncRolePermissions } from '../../../services/permissionAssignmentService';
import { supabase } from '../../../lib/supabaseClient';

export const RoleManagementPage: React.FC = () => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isPermissionModalOpen, setIsPermissionModalOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [formData, setFormData] = useState({ name: '', description: '' });

  // Local overrides for specific roles (used to show instant UI updates after permission sync)
  const [roleOverrides, setRoleOverrides] = useState<Record<number, Role>>({});

  // Fetch roles using Refine hooks
  type UseListRolesResult = {
    data?: { data?: Role[] } | Role[];
    result?: unknown;
    isLoading?: boolean;
    isFetching?: boolean;
    refetch?: () => void;
  };

  const rolesList = useList({
    resource: 'admin/roles',
    pagination: { pageSize: 50 },
  }) as unknown as UseListRolesResult;

  // Normalize response shapes (handles { content: [...] }, { data: [...] }, arrays, nested shapes, etc.)
  const rawRolesData = (rolesList.result ?? rolesList.data) ?? rolesList;

  const rawRoles = normalizeListResponse<Role>(rawRolesData);

  // Apply local overrides to show the most recent data immediately
  const roles = rawRoles.map((r) => {
    const overridden = roleOverrides[r.id];
    return overridden ?? r;
  });

  const isLoading = rolesList.isLoading ?? false;
  const isFetching = rolesList.isFetching ?? false;
  const refetch = rolesList.refetch;

  // Helper: fetch fresh single role and store override
  const fetchAndOverrideRole = async (roleId: number, token?: string) => {
    try {
      const headers: Record<string, string> = { Accept: 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/v1/admin/roles/${roleId}`, { headers });
      if (!res.ok) {
        return null;
      }
      const raw = await res.json();
      setRoleOverrides(prev => ({ ...prev, [roleId]: raw }));
      return raw;
    } catch {
      // swallow error silently; UI will refetch or stay optimistic
      return null;
    }
  };

  // Fetch available permissions for PermissionAssignmentModal
  type UseListPermissionsResult = {
    data?: { data?: Permission[] } | Permission[];
    result?: unknown;
    isLoading?: boolean;
    isFetching?: boolean;
    refetch?: () => void;
  };

  const permissionsList = useList({
    resource: 'admin/permissions',
    pagination: { pageSize: 200 },
  }) as unknown as UseListPermissionsResult;

  const rawPermissions = (permissionsList.result ?? permissionsList.data) ?? permissionsList;

  const permissions = normalizeListResponse<Permission>(rawPermissions);
  const permissionsLoading = permissionsList.isLoading ?? false;

  const { mutate: createRole } = useCreate();
  const { mutate: updateRole } = useUpdate();
  const { mutate: deleteRole } = useDelete();

  // Controlled skeleton state with minimum display time and a maximum guard (shared logic with users page)
  const [showSkeleton, setShowSkeleton] = useState(true);
  const mountedAtRef = useRef<number | null>(null);
  const maxTimeoutRef = useRef<number | null>(null);

  // Detect if the provider returned any data/result shape (stable primitive flag)
  const hasFetchedData = typeof rolesList.data !== 'undefined' || typeof rolesList.result !== 'undefined';

  useEffect(() => {
    mountedAtRef.current = Date.now();
    const MAX_MS = 3000;
    maxTimeoutRef.current = window.setTimeout(() => setShowSkeleton(false), MAX_MS) as unknown as number;
    return () => {
      if (maxTimeoutRef.current) {
        clearTimeout(maxTimeoutRef.current);
        maxTimeoutRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const MIN_MS = 200;
    if (isLoading || isFetching) {
      setShowSkeleton(true);
      return;
    }

    const effectiveHasFetched = hasFetchedData || roles.length > 0;
    const mountedAt = mountedAtRef.current ?? 0;
    const elapsed = Date.now() - mountedAt;
    if (effectiveHasFetched && elapsed >= MIN_MS) {
      setShowSkeleton(false);
    } else if (effectiveHasFetched) {
      const remaining = MIN_MS - elapsed;
      const t = window.setTimeout(() => setShowSkeleton(false), remaining);
      return () => clearTimeout(t);
    }
  }, [isLoading, isFetching, hasFetchedData, roles.length]);

  // Debug toggle: force skeleton when ?skeleton=1 is present (useful for testing)
  const forceSkeleton = typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('skeleton') === '1';

  const showLoading = forceSkeleton || showSkeleton;
  const isReallyLoaded = !isLoading && !isFetching && !showLoading && hasFetchedData;

  const handleCreateRole = (e: React.FormEvent) => {
    e.preventDefault();
    createRole(
      {
        resource: 'admin/roles',
        values: formData,
      },
      {
        onSuccess: () => {
          toast.success('Rol creado exitosamente');
          setIsCreateModalOpen(false);
          setFormData({ name: '', description: '' });
          refetch?.();
        },
        onError: (error) => {
          console.error('Error creating role:', error);
          toast.error('Error al crear rol');
        },
      }
    );
  };

  const handleUpdateRole = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) return;

    updateRole(
      {
        resource: 'admin/roles',
        id: selectedRole.id,
        values: formData,
      },
      {
        onSuccess: () => {
          toast.success('Rol actualizado exitosamente');
          setIsEditModalOpen(false);
          setSelectedRole(null);
          setFormData({ name: '', description: '' });
          refetch?.();
        },
        onError: (error) => {
          console.error('Error updating role:', error);
          toast.error('Error al actualizar rol');
        },
      }
    );
  };

  const handleDeleteRole = (roleId: number) => {
    if (confirm('¿Estás seguro de eliminar este rol? Los usuarios con este rol perderán sus permisos asociados.')) {
      deleteRole(
        { resource: 'admin/roles', id: String(roleId) },
        {
          onSuccess: () => {
            toast.success('Rol eliminado exitosamente');
            refetch?.();
          },
          onError: (error) => {
            console.error('Error deleting role:', error);
            toast.error('Error al eliminar rol');
          },
        }
      );
    }
  };

  const handleEditRole = (role: Role) => {
    setSelectedRole(role);
    setFormData({ name: role.name, description: role.description || '' });
    setIsEditModalOpen(true);
  };

  const handleManagePermissions = (role: Role) => {
    setSelectedRole(role);
    setIsPermissionModalOpen(true);
  };

  const handleSavePermissions = async (roleId: number, permissionIds: number[]): Promise<void> => {
    // Optimistic update: show new permissions immediately in the UI
    try {
      const existing = rawRoles.find(r => r.id === roleId);
      if (existing) {
        const optimistic: Role = {
          ...existing,
          permissions: permissions
            .filter(p => permissionIds.includes(p.id))
            .map(p => p.name),
        };
        setRoleOverrides(prev => ({ ...prev, [roleId]: optimistic }));
      }
    } catch {
      // ignore optimistic failures
    }

    try {
      // Get auth token
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;

      if (!token) {
        toast.error('No se encontró token de autenticación');
        throw new Error('No authentication token');
      }

      // Use the correct permission assignment service
      toast.loading('Actualizando permisos...', { id: 'permission-sync' });

      const result = await syncRolePermissions({
        roleId,
        desiredPermissionIds: permissionIds,
        availablePermissions: permissions,
        token,
      });

      // Report results
      if (result.failed.length > 0) {
        toast.error(
          `Permisos parcialmente actualizados. Fallos: ${result.failed.length}`,
          { id: 'permission-sync' }
        );
        // If partial/failed, refetch to reconcile the real state
        refetch?.();
        try {
          await fetchAndOverrideRole(roleId, token);
        } catch {
          void fetchAndOverrideRole(roleId);
        }
      } else {
        toast.success('Permisos actualizados exitosamente', { id: 'permission-sync' });
      }

      // Refresh role list to show updated permissions (ask the hook to refetch)
      refetch?.();

      // Fetch the fresh role and apply override so UI updates instantly
      try {
        await fetchAndOverrideRole(roleId, token);
      } catch {
        // best-effort
        void fetchAndOverrideRole(roleId);
      }
    } catch (error) {
      toast.error('Error al actualizar permisos', { id: 'permission-sync' });
      throw error;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Gestión de Roles
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            Define y administra roles del sistema y sus permisos asociados
          </p>
        </div>
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700
                     transition-colors flex items-center gap-2 focus:outline-none focus:ring-2
                     focus:ring-blue-500 focus:ring-offset-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Nuevo Rol
        </button>
      </div>

      {/* Stats Card - show skeleton for stats when loading */}
      {showLoading ? (
        <MetricCardSkeleton />
      ) : (
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
              <svg className="w-6 h-6 text-purple-600 dark:text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                      d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
              </svg>
            </div>
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total de Roles</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{roles.length}</p>
            </div>
          </div>
        </div>
      )}

      {/* Loading State */}
      {showLoading && (
        <DashboardSkeleton className="w-full" />
      )}

      {/* Empty State */}
      {isReallyLoaded && roles.length === 0 && (
        <EmptyState
          title="No hay roles definidos"
          description="Comienza creando tu primer rol en el sistema"
          actionLabel="Crear Rol"
          onAction={() => setIsCreateModalOpen(true)}
        />
      )}

      {/* Roles Grid */}
      {isReallyLoaded && roles.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {roles.map((role: Role) => (
            <div
              key={role.id}
              className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200
                         dark:border-gray-700 p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex justify-between items-start mb-4">
                <RoleBadge role={role.name} />
                <div className="flex gap-2">
                  <button
                    onClick={() => handleManagePermissions(role)}
                    className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-gray-700
                               rounded-lg transition-colors"
                    title="Gestionar Permisos"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                            d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                    </svg>
                  </button>
                  <button
                    onClick={() => handleEditRole(role)}
                    className="p-2 text-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700
                               rounded-lg transition-colors"
                    title="Editar Rol"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                            d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                    </svg>
                  </button>
                  <button
                    onClick={() => handleDeleteRole(role.id)}
                    className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-gray-700
                               rounded-lg transition-colors"
                    title="Eliminar Rol"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>

              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                {role.name}
              </h3>

              {role.description && (
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">
                  {role.description}
                </p>
              )}

              <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                          d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                  <span>{role.userCount || 0} usuarios</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                          d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                  </svg>
                  <span>{role.permissions?.length || 0} permisos</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Role Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
             onClick={() => setIsCreateModalOpen(false)}>
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow-xl max-w-md w-full"
               onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Crear Rol</h2>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200
                           rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <form onSubmit={handleCreateRole} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Nombre del Rol <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ej: Administrador, Editor, Visor"
                  required
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg
                             bg-white dark:bg-gray-800 text-gray-900 dark:text-white
                             focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Descripción
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  placeholder="Describe las responsabilidades de este rol"
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg
                             bg-white dark:bg-gray-800 text-gray-900 dark:text-white
                             focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300
                             bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600
                             rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg
                             hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500
                             focus:ring-offset-2 transition-colors"
                >
                  Crear
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Role Modal */}
      {isEditModalOpen && selectedRole && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
             onClick={() => setIsEditModalOpen(false)}>
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow-xl max-w-md w-full"
               onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Editar Rol</h2>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200
                           rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <form onSubmit={handleUpdateRole} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Nombre del Rol <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg
                             bg-white dark:bg-gray-800 text-gray-900 dark:text-white
                             focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Descripción
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg
                             bg-white dark:bg-gray-800 text-gray-900 dark:text-white
                             focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300
                             bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600
                             rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg
                             hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500
                             focus:ring-offset-2 transition-colors"
                >
                  Guardar Cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Permission Assignment Modal */}
      {isPermissionModalOpen && selectedRole && (
        <PermissionAssignmentModal
          isOpen={isPermissionModalOpen}
          onClose={() => {
            setIsPermissionModalOpen(false);
            refetch?.();
          }}
          role={selectedRole}
          availablePermissions={permissions}
          onSave={handleSavePermissions}
          loading={permissionsLoading}
        />
      )}
    </div>
  );
};
