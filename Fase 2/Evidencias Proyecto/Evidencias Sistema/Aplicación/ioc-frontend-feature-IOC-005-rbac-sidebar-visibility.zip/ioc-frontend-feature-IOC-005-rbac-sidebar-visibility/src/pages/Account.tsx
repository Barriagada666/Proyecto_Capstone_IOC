// =================================================================
// Account Page - User Profile
// Página de perfil del usuario autenticado
// =================================================================

import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { supabase } from "../lib/supabaseClient";
import PageBreadcrumb from "../components/common/PageBreadCrumb";
import Button from "../components/ui/button/Button";
import Badge from "../components/ui/badge/Badge";
import toast from "react-hot-toast";
import { fetchUserProfile, UserProfile } from "../services/userProfileService";

const Account = () => {
  const { user, session } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadProfile = async () => {
      if (!session?.access_token) {
        setLoading(false);
        return;
      }

      try {
        const data = await fetchUserProfile(session.access_token);
        setProfile(data);
      } catch (error) {
        console.error("Error loading profile:", error);
        toast.error("Error al cargar el perfil");
      } finally {
        setLoading(false);
      }
    };

    loadProfile();
  }, [session]);

  const handleSignOut = async () => {
    const toastId = toast.loading("Cerrando sesión...");
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast.error(`Error: ${error.message}`, { id: toastId });
    } else {
      toast.success("Has cerrado sesión.", { id: toastId });
      window.location.href = "/signin";
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return "No disponible";
    const date = new Date(dateString);
    return date.toLocaleDateString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  if (loading) {
    return (
      <>
        <PageBreadcrumb pageTitle="Mi Cuenta" />
        <div className="p-6">
          <div className="max-w-5xl mx-auto">
            <div className="animate-pulse space-y-6">
              <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 space-y-4">
                <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
                <div className="space-y-3">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <PageBreadcrumb pageTitle="Mi Cuenta" />
      <div className="p-6 space-y-6">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Mi Perfil
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Información de tu cuenta y permisos de acceso
            </p>
          </div>

          {/* Profile Card */}
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
            {/* Header with gradient */}
            <div className="bg-gradient-to-r from-brand-600 to-brand-700 px-6 py-8">
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                  <svg
                    className="w-10 h-10 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                    />
                  </svg>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">
                    {profile?.fullName || "Usuario"}
                  </h2>
                  <p className="text-brand-100 mt-1">{profile?.email || user?.email}</p>
                </div>
              </div>
            </div>

            {/* Profile Information */}
            <div className="p-6 space-y-6">
              {/* Personal Information Section */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                  <svg
                    className="w-5 h-5 text-brand-600 dark:text-brand-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                    />
                  </svg>
                  Información Personal
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                      Nombre Completo
                    </label>
                    <p className="text-sm text-gray-900 dark:text-white font-medium">
                      {profile?.fullName || "No disponible"}
                    </p>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                      Correo Electrónico
                    </label>
                    <p className="text-sm text-gray-900 dark:text-white font-medium">
                      {profile?.email || user?.email || "No disponible"}
                    </p>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                      Estado
                    </label>
                    <div>
                      {profile?.isActive !== false ? (
                        <Badge color="success" variant="light" size="sm">
                          <span className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 bg-success-500 rounded-full"></span>
                            Activo
                          </span>
                        </Badge>
                      ) : (
                        <Badge color="error" variant="light" size="sm">
                          <span className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 bg-error-500 rounded-full"></span>
                            Inactivo
                          </span>
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Work Information Section */}
              {profile && (
                <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                    <svg
                      className="w-5 h-5 text-brand-600 dark:text-brand-400"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                      />
                    </svg>
                    Información Laboral
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                        Planta Asignada
                      </label>
                      <p className="text-sm text-gray-900 dark:text-white font-medium">
                        {profile.plantaName || "No asignada"}
                      </p>
                      {profile.plantaCode && (
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                          Código: {profile.plantaCode}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                        Centro de Costo
                      </label>
                      <p className="text-sm text-gray-900 dark:text-white font-medium">
                        {profile.centroCosto || "No disponible"}
                      </p>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                        Fecha de Contrato
                      </label>
                      <p className="text-sm text-gray-900 dark:text-white font-medium">
                        {formatDate(profile.fechaContrato)}
                      </p>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                        Última Actualización
                      </label>
                      <p className="text-sm text-gray-900 dark:text-white font-medium">
                        {formatDate(profile.updatedAt)}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Roles Section */}
              {profile?.roles && profile.roles.length > 0 && (
                <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                    <svg
                      className="w-5 h-5 text-brand-600 dark:text-brand-400"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                      />
                    </svg>
                    Roles y Permisos
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {profile.roles.map((role) => (
                      <Badge
                        key={role}
                        color="primary"
                        variant="light"
                        size="md"
                      >
                        {role}
                      </Badge>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-3">
                    Tus roles determinan a qué secciones del sistema puedes acceder
                  </p>
                </div>
              )}

              {/* Account Details */}
              {profile && (
                <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                    <svg
                      className="w-5 h-5 text-brand-600 dark:text-brand-400"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                    Detalles de la Cuenta
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                        Fecha de Creación
                      </label>
                      <p className="text-sm text-gray-900 dark:text-white font-medium">
                        {formatDate(profile.createdAt)}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
                <div className="flex flex-wrap gap-3">
                  <Button onClick={handleSignOut} variant="secondary" size="md">
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                      />
                    </svg>
                    Cerrar Sesión
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Info Card */}
          <div className="mt-6 bg-blue-light-50 dark:bg-blue-light-950 border border-blue-light-200 dark:border-blue-light-900 rounded-lg p-4">
            <div className="flex gap-3">
              <svg
                className="w-5 h-5 text-blue-light-600 dark:text-blue-light-400 flex-shrink-0 mt-0.5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
              <div>
                <h4 className="text-sm font-medium text-blue-light-900 dark:text-blue-light-100">
                  Información de Contacto
                </h4>
                <p className="text-sm text-blue-light-700 dark:text-blue-light-300 mt-1">
                  Si necesitas actualizar tu información personal o tienes alguna duda sobre tus
                  permisos, contacta al administrador del sistema.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Account;

