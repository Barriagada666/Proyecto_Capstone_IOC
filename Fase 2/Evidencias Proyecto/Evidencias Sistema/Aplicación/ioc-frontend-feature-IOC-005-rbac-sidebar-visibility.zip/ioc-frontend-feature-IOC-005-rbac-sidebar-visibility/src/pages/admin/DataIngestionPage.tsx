import { useState, useEffect, useRef, useCallback } from 'react';
import toast from 'react-hot-toast';
import PageBreadcrumb from '../../components/common/PageBreadCrumb';
import DataUploadDropzone from '../../components/admin/DataUploadDropzone';
import UploadHistoryTable from '../../components/admin/UploadHistoryTable';
import ErrorLogModal from '../../components/admin/ErrorLogModal';
import ComponentCard from '../../components/common/ComponentCard';
import Button from '../../components/ui/button/Button';
import { startEtlProcess, getEtlJobStatus } from '../../services/apiService';
import * as apiErr from '../../utils/apiError';
import { useAuth } from '../../hooks/useAuth';

// --- Tipos ---
type UploadRecord = {
  id: string;
  fileName: string;
  uploadDate: string;
  status: 'Éxito' | 'Fallo' | 'En Progreso';
  user: string;
  errorCount: number;
};

// --- Componente Principal ---
const DataIngestionPage = () => {
  const { user } = useAuth();
  const [isUploading, setIsUploading] = useState(false);
  const [history, setHistory] = useState<UploadRecord[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalErrors, setModalErrors] = useState<string[]>([]);
  const abortCtrlRef = useRef<AbortController | null>(null);
  const pollersRef = useRef<Map<string, number>>(new Map());

  // Limpieza de polling al desmontar
  useEffect(() => {
    const pollers = pollersRef.current;
    const controller = abortCtrlRef.current;
    return () => {
      controller?.abort();
      for (const id of pollers.values()) {
        clearInterval(id);
      }
      pollers.clear();
    };
  }, []);

  const startPolling = useCallback((jobId: string) => {
    if (pollersRef.current.has(jobId)) return; // ya sondeando
    const intervalId = window.setInterval(async () => {
      try {
        const statusDto = await getEtlJobStatus(jobId);
        if (statusDto.status === 'EXITO' || statusDto.status === 'FALLO') {
          setHistory(prev => prev.map(rec => rec.id === jobId
            ? {
                ...rec,
                status: statusDto.status === 'EXITO' ? 'Éxito' : 'Fallo',
              }
            : rec,
          ));
          clearInterval(intervalId);
          pollersRef.current.delete(jobId);
          if (statusDto.status === 'EXITO') {
            toast.success('Proceso ETL finalizado con éxito.');
          } else {
            toast.error(statusDto.details || 'El proceso ETL falló.');
          }
        }
      } catch (err) {
        const parsed = apiErr.parseApiError(err);
        if (parsed.kind === 'auth') {
          // signOut es manejado por el interceptor
          clearInterval(intervalId);
          pollersRef.current.delete(jobId);
        }
        // otros errores: continuar intentando
      }
    }, 3000);
    pollersRef.current.set(jobId, intervalId);
  }, []);

  const handleFileSelect = async (file: File): Promise<boolean> => {
    if (isUploading) return false;
    setIsUploading(true);

    const ctrl = new AbortController();
    abortCtrlRef.current = ctrl;

    try {
      const res = await startEtlProcess(file, { signal: ctrl.signal });
      // Agregar a historial con estado inicial
      const record: UploadRecord = {
        id: res.jobId,
        fileName: res.fileName,
        uploadDate: new Date().toISOString(),
        status: 'En Progreso',
        user: user?.email ?? '—',
        errorCount: 0,
      };
      setHistory(prev => [record, ...prev]);
      toast.success('Archivo aceptado. Proceso iniciado.');
      startPolling(res.jobId);
      return true;
    } catch (err) {
      const parsed = apiErr.parseApiError(err);
      if (parsed.kind === 'abort') {
        toast('Subida cancelada.');
      } else if (parsed.status === 409) {
        toast.error('Este archivo ya ha sido procesado.');
      } else if (parsed.status === 413) {
        toast.error('El archivo excede el límite permitido.');
      } else if (parsed.kind === 'network') {
        toast.error('Error de red. Intenta nuevamente.');
      } else if (parsed.kind === 'auth') {
        // signOut + redirect manejado por interceptor / rutas
      } else {
        toast.error(parsed.message || 'Error inesperado al iniciar el proceso.');
      }
      // Registrar intento fallido en historial
      const failRecord: UploadRecord = {
        id: `fail-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        fileName: file.name,
        uploadDate: new Date().toISOString(),
        status: 'Fallo',
        user: user?.email ?? '—',
        errorCount: 1,
      };
      setHistory(prev => [failRecord, ...prev]);
      toast.error('Se registró un intento fallido en el historial.');
      return false;
    } finally {
      setIsUploading(false);
      abortCtrlRef.current = null;
    }
  };

  const handleCancel = () => {
    if (abortCtrlRef.current) {
      abortCtrlRef.current.abort();
    }
  };

  const handleViewDetails = (uploadId: string) => {
    // placeholder until error details endpoint is available
    void uploadId;
    setModalErrors([]);
    setIsModalOpen(true);
  };

  return (
    <>
      <PageBreadcrumb pageTitle="Centro de Ingesta de Datos de Producción" />
      <div className="p-4 md:p-6 space-y-6">
        <ComponentCard title="Iniciar Nuevo Proceso de Carga">
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <DataUploadDropzone onFileSelect={handleFileSelect} isUploading={isUploading} maxSize={50 * 1024 * 1024} data-testid="dropzone" />
            </div>
            {isUploading && (
              <Button variant="outline" onClick={handleCancel} data-testid="cancel-upload-btn">
                Cancelar
              </Button>
            )}
          </div>
        </ComponentCard>
        
        <ComponentCard title="Historial de Cargas">
          <UploadHistoryTable uploads={history} onViewDetails={handleViewDetails} data-testid="history-table" />
        </ComponentCard>
      </div>
      <ErrorLogModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} errors={modalErrors} />
    </>
  );
};

export default DataIngestionPage;
