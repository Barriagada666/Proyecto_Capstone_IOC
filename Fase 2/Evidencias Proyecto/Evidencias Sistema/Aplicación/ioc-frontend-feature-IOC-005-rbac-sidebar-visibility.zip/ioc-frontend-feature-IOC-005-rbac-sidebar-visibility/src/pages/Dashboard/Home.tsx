import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import Spinner from '../../components/ui/Spinner';

const Home: React.FC = () => {
  const { user, loading, roles } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Wait for authentication to load
    if (loading || !user) {
      return;
    }

    // DEBUG: Log roles to see exact values
    console.log('🔍 Home.tsx - User roles:', roles);
    console.log('🔍 Home.tsx - Roles array:', JSON.stringify(roles));

    // Redirect based on user roles (priority order)
    // Check for both Spanish and English role names
    if (roles.includes('ADMIN') || roles.includes('Administrador')) {
      console.log('✅ Redirecting to /admin/ingesta-datos');
      navigate('/admin/ingesta-datos', { replace: true });
      return;
    }

    if (roles.includes('GERENTE') || roles.includes('Gerente')) {
      console.log('✅ Redirecting to /dashboards/gerencial');
      navigate('/dashboards/gerencial', { replace: true });
      return;
    }

    if (roles.includes('ANALISTA') || roles.includes('Analista')) {
      console.log('✅ Redirecting to /dashboards');
      navigate('/dashboards', { replace: true });
      return;
    }

    // Fallback for users without specific roles
    console.log('⚠️ No matching roles, redirecting to /account');
    navigate('/account', { replace: true });
  }, [user, loading, roles, navigate]);

  // Show spinner while loading or redirecting
  return (
    <div className="flex items-center justify-center min-h-screen">
      <Spinner />
    </div>
  );
};

export default Home;