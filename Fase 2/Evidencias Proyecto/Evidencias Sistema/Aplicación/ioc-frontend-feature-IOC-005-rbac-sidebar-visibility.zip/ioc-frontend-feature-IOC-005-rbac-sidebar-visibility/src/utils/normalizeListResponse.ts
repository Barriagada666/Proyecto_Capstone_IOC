// Utility to normalize different list response shapes returned by various APIs/dataProviders
// It attempts to find an array of items in common keys used by different backends:
// - array itself
// - data, content, items, results, list, rows, records
// - nested under another object (e.g. { data: { content: [...] } })
// - refine v5 style: result or data on the hook result

export function normalizeListResponse<T>(raw: unknown): T[] {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw as T[];

  if (typeof raw === 'object') {
    const obj = raw as Record<string, unknown>;

    // Check top-level well-known keys
    const keys = ['result', 'data', 'content', 'items', 'results', 'list', 'rows', 'records'];

    for (const key of keys) {
      const v = obj[key];
      if (Array.isArray(v)) return v as T[];
      // if the value is an object, look inside for another array under known keys
      if (typeof v === 'object' && v !== null) {
        const nested = v as Record<string, unknown>;
        for (const k2 of keys) {
          if (Array.isArray(nested[k2])) return nested[k2] as T[];
        }
      }
    }
  }

  return [];
}
