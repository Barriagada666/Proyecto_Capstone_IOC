import {User} from '../types/user-management';

// Normaliza un usuario recibido desde la API hacia la forma que espera la UI
export function normalizeUser(raw: unknown): User {
  const r = (raw as Record<string, unknown> | null) ?? {};

  const id = (r['id'] as number | undefined) ?? 0;
  const email = (r['email'] as string | undefined) ?? '';

  // Name handling
  const fullName = (r['fullName'] as string | undefined) ?? (r['nombreCompleto'] as string | undefined) ?? '';
  const nameParts = String(fullName).trim() ? String(fullName).trim().split(/\s+/) : [];
  const primerNombreFromRaw = (r['primerNombre'] as string | undefined) ?? undefined;
  const primerNombre = primerNombreFromRaw ?? nameParts[0] ?? '';
  let segundoNombre = (r['segundoNombre'] as string | undefined) ?? '';
  let primerApellido = (r['primerApellido'] as string | undefined) ?? '';
  const segundoApellido = (r['segundoApellido'] as string | undefined) ?? '';

  if (!primerNombreFromRaw && nameParts.length > 0) {
    // derive when necessary
    if (nameParts.length === 1) {
      // only one token
      primerApellido = primerApellido || '';
    } else if (nameParts.length === 2) {
      primerApellido = primerApellido || nameParts[1];
    } else if (nameParts.length >= 3) {
      primerApellido = primerApellido || nameParts[nameParts.length - 1];
      segundoNombre = segundoNombre || nameParts.slice(1, nameParts.length - 1).join(' ');
    }
  }

  // Planta handling
  const planta = (r['planta'] as Record<string, unknown> | undefined);
  const plantaId = (r['plantaId'] as number | undefined) ?? (planta?.['id'] as number | undefined);
  const plantaNombre = (r['plantaNombre'] as string | undefined) ?? (r['plantaName'] as string | undefined) ?? (planta?.['name'] as string | undefined);

  // Helper to Title Case a string (handles multi-word and hyphenated parts)
  const titleCase = (input?: string | null) => {
    if (!input) return input;
    return String(input)
      .trim()
      .split(/\s+/)
      .map((word) => word
        .split('-')
        .map((part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
        .join('-')
      )
      .join(' ');
  };

  return {
      id,
      supabaseUserId: (r['supabaseUserId'] as string | undefined) ?? '',
      email,
      // Capitalize name parts for consistent display in UI
      primerNombre: titleCase(primerNombre) ?? '',
      segundoNombre: titleCase(segundoNombre) ?? undefined,
      primerApellido: titleCase(primerApellido) ?? '',
      segundoApellido: titleCase(segundoApellido) ?? undefined,
      plantaId: plantaId ?? undefined,
      plantaNombre: titleCase(plantaNombre) ?? undefined,
      centroCosto: (r['centroCosto'] as string | undefined) ?? undefined,
      fechaContrato: (r['fechaContrato'] as string | undefined) ?? undefined,
      isActive: (r['isActive'] as boolean | undefined) ?? true,
      lastLoginAt: (r['lastLoginAt'] as string | undefined) ?? undefined,
      createdAt: (r['createdAt'] as string | undefined) ?? new Date().toISOString(),
      updatedAt: (r['updatedAt'] as string | undefined) ?? new Date().toISOString(),
      deletedAt: (r['deletedAt'] as string | undefined) ?? undefined,
      roles: Array.isArray(r['roles']) ? (r['roles'] as unknown[]) : [],
  } as User;
}
