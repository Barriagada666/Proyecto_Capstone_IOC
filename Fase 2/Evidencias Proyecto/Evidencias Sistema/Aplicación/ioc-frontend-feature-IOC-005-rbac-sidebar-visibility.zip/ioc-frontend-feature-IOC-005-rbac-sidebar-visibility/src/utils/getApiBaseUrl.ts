// Utility to normalize VITE_API_BASE_URL for client usage
export function getApiBaseUrl(): string {
  const raw = import.meta.env.VITE_API_BASE_URL ?? '';
  if (!raw) {
    return (typeof location !== 'undefined') ? `${location.origin}` : '';
  }

  // If raw looks like a full URL, return it without trailing slash
  try {
    const u = new URL(raw);
    return `${u.origin}${u.pathname.replace(/\/$/, '')}`;
  } catch {
    // Not an absolute URL; if it starts with '/', resolve against current origin
    if (raw.startsWith('/')) {
      return (typeof location !== 'undefined') ? `${location.origin}${raw.replace(/\/$/, '')}` : raw.replace(/\/$/, '');
    }
    // Otherwise assume it's an origin-like string or path; return trimmed
    return raw.replace(/\/$/, '');
  }
}
