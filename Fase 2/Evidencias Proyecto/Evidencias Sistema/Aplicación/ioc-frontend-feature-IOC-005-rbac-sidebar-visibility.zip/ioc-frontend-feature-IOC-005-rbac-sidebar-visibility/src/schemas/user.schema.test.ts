import { describe, it, expect } from 'vitest';
import { userFormSchema } from './user.schema';

const toYMD = (d: Date) => d.toISOString().slice(0, 10);

describe('userFormSchema fechaContrato validation', () => {
  const basePayload = {
    email: 'test@example.com',
    password: 'Aa1@abcd',
    primerNombre: 'Nombre',
    primerApellido: 'Apellido',
    roles: [1],
  };

  it('accepts today', () => {
    const today = toYMD(new Date());
    const payload = { ...basePayload, fechaContrato: today };
    const res = userFormSchema.safeParse(payload);
    expect(res.success).toBe(true);
  });

  it('accepts past date', () => {
    const yesterday = toYMD(new Date(Date.now() - 24 * 60 * 60 * 1000));
    const payload = { ...basePayload, fechaContrato: yesterday };
    const res = userFormSchema.safeParse(payload);
    expect(res.success).toBe(true);
  });

  it('rejects future date', () => {
    const tomorrow = toYMD(new Date(Date.now() + 24 * 60 * 60 * 1000));
    const payload = { ...basePayload, fechaContrato: tomorrow };
    const res = userFormSchema.safeParse(payload);
    expect(res.success).toBe(false);
    if (!res.success) {
      // check error message exists for fechaContrato
      const issues = res.error.issues.filter((i) => i.path.includes('fechaContrato'));
      expect(issues.length).toBeGreaterThan(0);
    }
  });

  it('allows empty fechaContrato', () => {
    const payload = { ...basePayload, fechaContrato: undefined };
    const res = userFormSchema.safeParse(payload);
    expect(res.success).toBe(true);
  });
});

