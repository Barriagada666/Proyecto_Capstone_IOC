// =================================================================
// ROLE VALIDATION SCHEMAS - IOC-004
// Fuente de Verdad: .gemini/sprints/technical-designs/TD-IOC-004-User-Role-Management-claude.md
// =================================================================

import { z } from 'zod';

/**
 * Schema de validación para crear/editar rol
 */
export const roleFormSchema = z.object({
  name: z
    .string()
    .min(1, 'El nombre del rol es requerido')
    .max(50, 'El nombre no puede tener más de 50 caracteres')
    .regex(/^[A-Z_]+$/, 'Solo se permiten mayúsculas y guiones bajos'),

  description: z
    .string()
    .max(255, 'La descripción no puede tener más de 255 caracteres')
    .optional()
    .or(z.literal(''))
});

export type RoleFormValues = z.infer<typeof roleFormSchema>;

