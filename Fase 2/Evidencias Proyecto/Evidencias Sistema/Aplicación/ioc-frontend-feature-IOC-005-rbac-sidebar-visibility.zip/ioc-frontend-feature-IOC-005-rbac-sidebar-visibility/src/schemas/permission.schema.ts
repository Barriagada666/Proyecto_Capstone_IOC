// =================================================================
// PERMISSION VALIDATION SCHEMAS - IOC-004
// Fuente de Verdad: .gemini/sprints/technical-designs/TD-IOC-004-User-Role-Management-claude.md
// =================================================================

import { z } from 'zod';

/**
 * Schema de validación para crear/editar permiso
 */
export const permissionFormSchema = z.object({
  name: z
    .string()
    .min(1, 'El nombre del permiso es requerido')
    .max(100, 'El nombre no puede tener más de 100 caracteres')
    .regex(/^[A-Z_:]+$/, 'Solo se permiten mayúsculas, guiones bajos y dos puntos'),

  description: z
    .string()
    .max(255, 'La descripción no puede tener más de 255 caracteres')
    .optional()
    .or(z.literal('')),

  category: z
    .string()
    .max(50, 'La categoría no puede tener más de 50 caracteres')
    .optional()
    .or(z.literal(''))
});

export type PermissionFormValues = z.infer<typeof permissionFormSchema>;
 

// =================================================================
// USER VALIDATION SCHEMAS - IOC-004
// Fuente de Verdad: .gemini/sprints/technical-designs/TD-IOC-004-User-Role-Management-claude.md
// =================================================================

/**
 * Schema de validación para crear/editar usuario
 */
export const userFormSchema = z.object({
  email: z
    .string()
    .min(1, 'El correo electrónico es requerido')
    .email('Debe ser un correo electrónico válido')
    .max(255, 'El correo no puede tener más de 255 caracteres'),

  primerNombre: z
    .string()
    .min(1, 'El primer nombre es requerido')
    .max(100, 'El primer nombre no puede tener más de 100 caracteres')
    .regex(/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/, 'Solo se permiten letras'),

  segundoNombre: z
    .string()
    .max(100, 'El segundo nombre no puede tener más de 100 caracteres')
    .regex(/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*$/, 'Solo se permiten letras')
    .optional()
    .or(z.literal('')),

  primerApellido: z
    .string()
    .min(1, 'El primer apellido es requerido')
    .max(100, 'El primer apellido no puede tener más de 100 caracteres')
    .regex(/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/, 'Solo se permiten letras'),

  segundoApellido: z
    .string()
    .max(100, 'El segundo apellido no puede tener más de 100 caracteres')
    .regex(/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*$/, 'Solo se permiten letras')
    .optional()
    .or(z.literal('')),

  plantaId: z
    .number()
    .int('Debe ser un número entero')
    .positive('Debe ser mayor a 0')
    .optional()
    .nullable(),

  centroCosto: z
    .string()
    .max(50, 'El centro de costo no puede tener más de 50 caracteres')
    .optional()
    .or(z.literal('')),

  fechaContrato: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Formato de fecha inválido (YYYY-MM-DD)')
    .optional()
    .or(z.literal('')),

  supabaseUserId: z
    .string()
    .uuid('Debe ser un UUID válido')
    .optional(), // Optional for edit mode

  roles: z
    .array(z.string())
    .optional(),

  isActive: z
    .boolean()
    .optional()
});

export type UserFormValues = z.infer<typeof userFormSchema>;
 

/**
 * Schema de validación para filtros de usuario
 */
export const userFiltersSchema = z.object({
  search: z.string().optional(),
  plantaId: z.number().int().positive().optional(),
  isActive: z.boolean().optional(),
  page: z.number().int().min(0).optional(),
  size: z.number().int().min(1).max(100).optional()
});

export type UserFiltersValues = z.infer<typeof userFiltersSchema>;
 
