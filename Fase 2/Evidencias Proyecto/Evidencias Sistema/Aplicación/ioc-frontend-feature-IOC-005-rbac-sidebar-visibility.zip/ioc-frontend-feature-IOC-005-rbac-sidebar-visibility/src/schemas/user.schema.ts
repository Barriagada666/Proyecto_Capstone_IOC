import { z } from 'zod';

// Strong password validation regex
const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

// Schema for the user creation / edit form used by UserFormModal
export const userFormSchema = z.object({
  email: z.string().email({ message: 'Correo inválido' }),
  password: z
    .string()
    .min(8, { message: 'La contraseña debe tener al menos 8 caracteres' })
    .regex(strongPasswordRegex, {
      message: 'La contraseña debe cumplir con todos los requisitos de seguridad'
    })
    .optional(),
  primerNombre: z.string().min(1, { message: 'Requerido' }),
  segundoNombre: z.string().optional().nullable(),
  primerApellido: z.string().min(1, { message: 'Requerido' }),
  segundoApellido: z.string().optional().nullable(),
  plantaId: z.union([z.number().int().positive(), z.undefined()]).optional(),
  centroCosto: z.string().max(50, { message: 'Máximo 50 caracteres' }).optional().nullable(),
  // fechaContrato: ISO date string (YYYY-MM-DD). Optional/null/empty allowed.
  // Validate that, when provided, the date is not in the future.
  fechaContrato: z.string().optional().nullable().refine((val) => {
    if (!val) return true; // allow empty/null/undefined
    // Expect format YYYY-MM-DD (produced by flatpickr with dateFormat 'Y-m-d')
    const parsed = new Date(val);
    if (Number.isNaN(parsed.getTime())) return false; // invalid date string
    // Compare dates using local date parts to avoid timezone (UTC) shifts.
    const toLocalYMD = (d: Date) => {
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${y}-${m}-${day}`;
    };
    const provided = toLocalYMD(parsed);
    const today = toLocalYMD(new Date());
    return provided <= today;
  }, { message: 'La fecha de contrato no puede ser posterior a la fecha actual' }),
  roles: z.array(z.number().int().positive())
    .min(1, { message: 'Debe seleccionar al menos un rol' })
    .nonempty({ message: 'Debe seleccionar al menos un rol' }),
  isActive: z.boolean().optional(),
});

export type UserFormValues = z.infer<typeof userFormSchema>;
