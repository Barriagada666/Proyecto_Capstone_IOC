// Auth context: keep only auth-related context here
import { createContext } from 'react';
import type { Session, User } from '@supabase/supabase-js';

export interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  roles: string[];
}

// Use undefined default so hooks can assert presence of Provider
export const AuthContext = createContext<AuthContextType | undefined>(undefined);
