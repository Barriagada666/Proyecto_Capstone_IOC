import { useEffect, useState, useRef } from 'react';
import { supabase } from '../lib/supabaseClient';
import type { AuthChangeEvent, Session, User } from '@supabase/supabase-js';
import { AuthContext } from './authContext';

// Deduplicate in-flight /api/v1/users/me requests per access token
const inFlightRoleRequests = new Map<string, Promise<string[]>>();

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [roles, setRoles] = useState<string[]>([]);
  // Guard refs to avoid duplicate network calls (React strict-mode + auth listener)
  const prevAccessTokenRef = useRef<string | null>(null);
  const didInitialFetchRef = useRef(false);

  // Fetch the current user's profile from authenticated endpoint
  const fetchMyProfileRoles = async (token: string): Promise<string[]> => {
    // Reuse existing in-flight promise for this token
    const existing = inFlightRoleRequests.get(token);
    if (existing) return existing;

    const promise = (async () => {
      try {
        const res = await fetch('/api/v1/users/me', {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        });

        // If endpoint not accessible or user not allowed, return empty to let JWT fallback run
        if (!res.ok) {
          console.warn('GET /api/v1/users/me failed with status:', res.status);
          return [];
        }

        const json = await res.json();
        console.log('✅ Roles fetched from /api/v1/users/me:', json.roles);
        return Array.isArray(json.roles) ? json.roles : [];
      } catch (e) {
        console.error('Error fetching /api/v1/users/me:', e);
        return [];
      }
    })();

    // store and ensure cleanup when done
    inFlightRoleRequests.set(token, promise);
    promise.finally(() => inFlightRoleRequests.delete(token));
    return promise;
  };

  useEffect(() => {
    const setData = async () => {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;
      setSession(session);
      setUser(session?.user ?? null);

      // Track current token to avoid duplicate fetches
      prevAccessTokenRef.current = session?.access_token ?? null;

      let extractedRoles: string[] = [];

      if (session?.user) {
        const u = session.user;

        // Prefer secure /api/v1/users/me (authenticated, non-admin)
        if (session.access_token) {
          extractedRoles = await fetchMyProfileRoles(session.access_token);
        }

        // Fallback: read roles from JWT claims (app_metadata/user_metadata)
        if (extractedRoles.length === 0) {
          console.log('⚠️ No roles from backend, trying JWT metadata...');
          if ((u as any).app_metadata?.roles) extractedRoles = (u as any).app_metadata.roles;
          else if (u.user_metadata?.roles) extractedRoles = u.user_metadata.roles;
          else if ((u as any).raw_app_meta_data?.roles) extractedRoles = (u as any).raw_app_meta_data.roles;
          else if ((u as any).raw_user_meta_data?.roles) extractedRoles = (u as any).raw_user_meta_data.roles;

          if (extractedRoles.length > 0) {
            console.log('✅ Roles found in JWT metadata:', extractedRoles);
          } else {
            console.warn('❌ No roles found in backend or JWT metadata');
          }
        }
      }

      if (!Array.isArray(extractedRoles)) extractedRoles = [];
      setRoles(extractedRoles);
      setLoading(false);
      didInitialFetchRef.current = true;
    };

    setData();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (_event: AuthChangeEvent, session: Session | null) => {
        setSession(session);
        setUser(session?.user ?? null);

        // If access token didn't change and we already did the initial fetch, skip duplicate work
        if (didInitialFetchRef.current && session?.access_token === prevAccessTokenRef.current) {
          // still ensure loading is false
          setLoading(false);
          return;
        }

        // Update tracked token
        prevAccessTokenRef.current = session?.access_token ?? null;

        let extractedRoles: string[] = [];

        if (session?.user) {
          const u = session.user;

          if (session.access_token) {
            extractedRoles = await fetchMyProfileRoles(session.access_token);
          }

          if (extractedRoles.length === 0) {
            if ((u as any).app_metadata?.roles) extractedRoles = (u as any).app_metadata.roles;
            else if (u.user_metadata?.roles) extractedRoles = u.user_metadata.roles;
            else if ((u as any).raw_app_meta_data?.roles) extractedRoles = (u as any).raw_app_meta_data.roles;
            else if ((u as any).raw_user_meta_data?.roles) extractedRoles = (u as any).raw_user_meta_data.roles;
          }
        }

        if (!Array.isArray(extractedRoles)) extractedRoles = [];
        setRoles(extractedRoles);
        setLoading(false);
        didInitialFetchRef.current = true;
      }
    );

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, []);

  const value = { user, session, loading, roles };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
