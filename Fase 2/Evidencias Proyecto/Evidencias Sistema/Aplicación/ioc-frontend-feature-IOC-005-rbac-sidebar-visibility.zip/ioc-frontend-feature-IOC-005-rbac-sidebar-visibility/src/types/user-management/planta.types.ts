// =================================================================
// PLANTA TYPES - IOC-004
// Fuente de Verdad: .gemini/sprints/technical-designs/TD-IOC-004-User-Role-Management-claude.md
// =================================================================

/**
 * Planta industrial
 */
export interface Planta {
  id: number;
  code: string;
  name: string;
  address?: string;
  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
}
