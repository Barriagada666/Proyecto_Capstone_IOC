// =================================================================
// PERMISSION MANAGEMENT TYPES - IOC-004
// Fuente de Verdad: .gemini/sprints/technical-designs/TD-IOC-004-User-Role-Management-claude.md
// =================================================================

/**
 * Permiso del sistema
 */
export interface Permission {
  id: number;
  name: string;
  description?: string;
  category?: string;
  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
  roles?: string[];
}

/**
 * DTO para crear permiso
 */
export interface CreatePermissionDto {
  name: string;
  description?: string;
  category?: string;
}

/**
 * DTO para actualizar permiso
 */
export interface UpdatePermissionDto {
  name?: string;
  description?: string;
  category?: string;
}

/**
 * Permisos agrupados por categoría
 */
export interface GroupedPermissions {
  [category: string]: Permission[];
}

