// =================================================================
// ROLE MANAGEMENT TYPES - IOC-004
// Fuente de Verdad: .gemini/sprints/technical-designs/TD-IOC-004-User-Role-Management-claude.md
// =================================================================

/**
 * Rol con información de permisos
 */
export interface Role {
  id: number;
  name: string;
  description?: string;
  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
  permissions: string[];
  userCount?: number;
}

/**
 * DTO para crear rol
 */
export interface CreateRoleDto {
  name: string;
  description?: string;
}

/**
 * DTO para actualizar rol
 */
export interface UpdateRoleDto {
  name?: string;
  description?: string;
}

/**
 * Resumen de rol con estadísticas
 */
export interface RoleSummary {
  id: number;
  name: string;
  description?: string;
  userCount: number;
  permissionCount: number;
}

/**
 * Tipo de rol conocido
 */
export type RoleType = 'ADMIN' | 'GERENTE' | 'ANALISTA';

/**
 * Configuración visual de rol
 */
export interface RoleVariant {
  bg: string;
  text: string;
  border: string;
  label: string;
}

