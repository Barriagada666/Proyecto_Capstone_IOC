// =================================================================
// USER MANAGEMENT TYPES - IOC-004
// =================================================================

/**
 * Usuario completo con información de roles
 */
export interface User {
  id: number;
  supabaseUserId: string;
  email: string;
  primerNombre: string;
  segundoNombre?: string;
  primerApellido: string;
  segundoApellido?: string;
  plantaId?: number;
  plantaNombre?: string;
  centroCosto?: string;
  fechaContrato?: string; // YYYY-MM-DD
  isActive: boolean;
  lastLoginAt?: string; // ISO 8601
  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
  deletedAt?: string; // ISO 8601
  roles: string[];
}

/**
 * DTO para crear usuario
 */
export interface CreateUserDto {
  email: string;
  primerNombre: string;
  segundoNombre?: string;
  primerApellido: string;
  segundoApellido?: string;
  plantaId?: number;
  centroCosto?: string;
  fechaContrato?: string; // YYYY-MM-DD
  supabaseUserId: string;
  roles?: string[];
}

/**
 * DTO para actualizar usuario
 */
export interface UpdateUserDto {
  primerNombre?: string;
  segundoNombre?: string;
  primerApellido?: string;
  segundoApellido?: string;
  plantaId?: number;
  centroCosto?: string;
  fechaContrato?: string; // YYYY-MM-DD
  isActive?: boolean;
}

/**
 * Respuesta paginada de usuarios (forma local)
 */
export interface UsersResponse {
  items: User[];
  pagination: {
    page: number;
    size: number;
    totalElements: number;
    totalPages: number;
  };
}

/**
 * Filtros para listado de usuarios
 */
export interface UserFilters {
  page?: number;
  size?: number;
  search?: string;
  plantaId?: number;
  isActive?: boolean;
}
