// =================================================================
// DATA PROVIDER - REST API (Spring Boot)
// Fuente de Verdad: .gemini/prompts-v2/ftv-generador-refine.md
// =================================================================

import { DataProvider } from '@refinedev/core';
import axios, { AxiosInstance } from 'axios';
import { supabase } from '../lib/supabaseClient';
import { getApiBaseUrl } from '../utils/getApiBaseUrl';
// Prefer an explicit VITE_API_BASE_URL set at build/deploy time (e.g. on Vercel).
// For admin/data endpoints we expect the API v1 prefix. Use the normalized base and append /api/v1
// only when the normalized base does not already contain it.
const normalizedBase = getApiBaseUrl().replace(/\/$/, '');
const API_URL = normalizedBase.endsWith('/api/v1') ? normalizedBase : `${normalizedBase}/api/v1`;
// Create axios instance with interceptors
const axiosInstance: AxiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add JWT token to requests
axiosInstance.interceptors.request.use(
  async (config) => {
    try {
      // Prefer supabase client session (more reliable than localStorage and handles refresh)
      const { data } = await supabase.auth.getSession();
      const session = data?.session;
      if (session?.access_token) {
        config.headers = config.headers || {};
        config.headers.Authorization = `Bearer ${session.access_token}`;
      } else {
        // Fallback to localStorage if needed
        const token = localStorage.getItem('supabase.auth.token');
        if (token) {
          const authData = JSON.parse(token);
          if (authData?.access_token) {
            config.headers = config.headers || {};
            config.headers.Authorization = `Bearer ${authData.access_token}`;
          }
        }
      }
    } catch {
      // ignore session retrieval errors — we'll try localStorage fallback
      const token = localStorage.getItem('supabase.auth.token');
      if (token) {
        try {
          const authData = JSON.parse(token);
          if (authData?.access_token) {
            config.headers = config.headers || {};
            config.headers.Authorization = `Bearer ${authData.access_token}`;
          }
        } catch {
          // ignore
        }
      }
    }
    // Diagnostic log: show outgoing request URL and Authorization header (for debugging only)
    try {
      console.debug('[axios] Outgoing request', { url: config.url, method: config.method, authorization: config.headers?.Authorization });
    } catch {
      // ignore
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Handle 401 errors
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    try {
      const status = error?.response?.status;
      const url = error?.config?.url;
      console.error('[axios] Response error', { status, url, message: error?.message });
    } catch {
      // ignore
    }
    if (error.response?.status === 401) {
      localStorage.removeItem('supabase.auth.token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const dataProvider: DataProvider = {
  getList: async ({ resource, pagination, filters, sorters }) => {
    // Extract pagination values safely
    let page = 1;
    let size = 10;

    if (pagination?.mode === 'server') {
      page = (pagination as { current?: number }).current ?? 1;
      size = (pagination as { pageSize?: number }).pageSize ?? 10;
    }

    const params: Record<string, string | number> = {
      page: page - 1, // Spring uses 0-based pagination
      size: size,
    };

    // Add filters
    if (filters) {
      filters.forEach((filter) => {
        if ('field' in filter && filter.value !== undefined) {
          params[filter.field] = filter.value;
        }
      });
    }

    // Add sorters
    if (sorters && sorters.length > 0) {
      params.sort = sorters.map((s) => `${s.field},${s.order}`).join('&');
    }

    const { data } = await axiosInstance.get(`/${resource}`, { params });

    return {
      data: data.items || data.content || data,
      total: data.pagination?.totalElements || data.totalElements || data.length,
    };
  },

  getOne: async ({ resource, id }) => {
    const { data } = await axiosInstance.get(`/${resource}/${id}`);
    return { data };
  },

  create: async ({ resource, variables }) => {
    const { data } = await axiosInstance.post(`/${resource}`, variables);
    return { data };
  },

  update: async ({ resource, id, variables }) => {
    const { data } = await axiosInstance.put(`/${resource}/${id}`, variables);
    return { data };
  },

  deleteOne: async ({ resource, id }) => {
    const { data } = await axiosInstance.delete(`/${resource}/${id}`);
    return { data };
  },

  getApiUrl: () => API_URL,

  custom: async ({ url, method, payload, query, headers }) => {
    const { data } = await axiosInstance({
      url,
      method,
      data: payload,
      params: query,
      headers,
    });
    return { data };
  },
};
