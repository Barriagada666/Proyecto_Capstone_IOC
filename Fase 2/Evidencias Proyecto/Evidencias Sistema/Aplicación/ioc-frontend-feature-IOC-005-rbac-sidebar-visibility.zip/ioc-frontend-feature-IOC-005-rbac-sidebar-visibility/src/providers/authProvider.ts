// =================================================================
// AUTH PROVIDER - Supabase Auth
// Fuente de Verdad: .gemini/prompts-v2/ftv-generador-refine.md
// =================================================================

import type { AuthProvider } from '@refinedev/core';
import { supabase } from '../lib/supabaseClient';

export const authProvider: AuthProvider = {
  login: async ({ email, password }: { email: string; password: string }) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return {
          success: false,
          error: {
            name: 'LoginError',
            message: error.message,
          },
        };
      }

      if (data?.session) {
        // Store token for axios interceptor
        localStorage.setItem('supabase.auth.token', JSON.stringify({
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
        }));

        return {
          success: true,
          redirectTo: '/admin',
        };
      }

      return {
        success: false,
        error: {
          name: 'LoginError',
          message: 'No se pudo iniciar sesión',
        },
      };
    } catch (error: unknown) {
      return {
        success: false,
        error: {
          name: 'LoginError',
          message: error instanceof Error ? error.message : 'Error al iniciar sesión',
        },
      };
    }
  },

  logout: async () => {
    try {
      const { error } = await supabase.auth.signOut();

      if (error) {
        return {
          success: false,
          error: {
            name: 'LogoutError',
            message: error.message,
          },
        };
      }

      localStorage.removeItem('supabase.auth.token');

      return {
        success: true,
        redirectTo: '/login',
      };
    } catch (error: unknown) {
      return {
        success: false,
        error: {
          name: 'LogoutError',
          message: error instanceof Error ? error.message : 'Error al cerrar sesión',
        },
      };
    }
  },

  check: async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();

      if (error || !session) {
        return {
          authenticated: false,
          redirectTo: '/login',
          error: {
            name: 'Unauthorized',
            message: 'No autorizado',
          },
        };
      }

      return {
        authenticated: true,
      };
    } catch (error: unknown) {
      return {
        authenticated: false,
        redirectTo: '/login',
        error: {
          name: 'Unauthorized',
          message: error instanceof Error ? error.message : 'Error de autenticación',
        },
      };
    }
  },

  getPermissions: async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();

      if (session?.user) {
        // Extract roles/permissions from JWT claims
        return session.user.user_metadata?.roles || [];
      }

      return null;
    } catch {
      return null;
    }
  },

  getIdentity: async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (user) {
        return {
          id: user.id,
          name: user.user_metadata?.full_name || user.email,
          email: user.email,
          avatar: user.user_metadata?.avatar_url,
        };
      }

      return null;
    } catch {
      return null;
    }
  },

  onError: async (error: unknown) => {
    const status = error && typeof error === 'object' && 'status' in error ? (error as { status: number }).status : null;
    const errorObj = error instanceof Error ? error : new Error('Unknown error');

    if (status === 401 || status === 403) {
      return {
        logout: true,
        redirectTo: '/login',
        error: errorObj,
      };
    }

    return { error: errorObj };
  },
};

