# Plan de Refactorización: Sistema RBAC Basado en Permisos

**Fecha**: 16 de noviembre de 2025  
**Versión**: 1.0  
**Autor**: Equipo de Desarrollo IOC Frontend  
**Estado**: Propuesto

---

## 📋 Tabla de Contenidos

1. [Resumen Ejecutivo](#resumen-ejecutivo)
2. [Análisis de la Situación Actual](#análisis-de-la-situación-actual)
3. [Problema Identificado](#problema-identificado)
4. [Solución Propuesta](#solución-propuesta)
5. [Arquitectura de la Solución](#arquitectura-de-la-solución)
6. [Plan de Implementación](#plan-de-implementación)
7. [Impacto y Riesgos](#impacto-y-riesgos)
8. [Cronograma](#cronograma)
9. [Criterios de Aceptación](#criterios-de-aceptación)

---

## 1. Resumen Ejecutivo

### Contexto

El backend del sistema IOC ha implementado un **sistema de control de acceso basado en permisos granulares** (RBAC - Role-Based Access Control) que permite un control fino sobre qué acciones puede realizar cada usuario en el sistema.

### Problema

Actualmente, el frontend utiliza un enfoque simplificado basado únicamente en **roles** (`ADMIN`, `GERENTE`, `ANALISTA`), lo cual crea:

- ❌ Desalineación con el backend
- ❌ Falta de flexibilidad en el control de acceso
- ❌ Imposibilidad de aprovechar permisos granulares
- ❌ Control de UI limitado y rígido

### Solución

Refactorizar el frontend para que el control de acceso se base en la **lista de permisos efectivos** del usuario, sincronizándose perfectamente con el backend y permitiendo un control de UI mucho más fino y seguro.

### Beneficios Esperados

- ✅ Alineación perfecta con el backend
- ✅ Control de acceso granular y flexible
- ✅ Seguridad centralizada en el servidor
- ✅ Mejor experiencia de usuario (UI adaptativa)
- ✅ Facilita futuras expansiones del sistema

---

## 2. Análisis de la Situación Actual

### 2.1. Estado del Backend

El backend implementa un sistema RBAC completo con:

#### Estructura de Permisos

```
Usuario → Roles → Permisos
   ↓        ↓         ↓
  Juan   ADMIN   DASHBOARD_VIEW
          ↓      DASHBOARD_WRITE
       GERENTE   USER_READ
                 USER_WRITE
                 ROLE_READ
                 ...
```

#### Permisos Disponibles (Ejemplos)

```typescript
// Dashboards
- DASHBOARD_VIEW
- DASHBOARD_WRITE
- DASHBOARD_DELETE
- DASHBOARD_SHARE

// Usuarios
- USER_READ
- USER_WRITE
- USER_DELETE

// Roles y Permisos
- ROLE_READ
- ROLE_WRITE
- PERMISSION_READ
- PERMISSION_WRITE

// Plantas
- PLANTA_READ
- PLANTA_WRITE

// Datos/ETL
- DATA_INGEST
- DATA_VALIDATE
- DATA_EXPORT
```

#### Endpoint de Permisos Efectivos

El backend NO expone directamente un endpoint `/me/permissions`, pero:

1. Los permisos están incluidos en el **JWT token** como claims
2. O se pueden obtener mediante el endpoint de usuario actual
3. O se pueden calcular en el frontend desde los roles del usuario

### 2.2. Estado del Frontend

#### Estructura Actual

```typescript
// ❌ Actual: Solo verifica roles
const { user } = useAuth();
const userRoles = user?.roles || []; // ['ADMIN', 'GERENTE']

// Control de acceso básico
if (userRoles.includes('ADMIN')) {
  // Mostrar opciones de admin
}
```

#### Limitaciones Identificadas

1. **No hay gestión de permisos**: Solo se usan roles
2. **No hay hooks de permisos**: No existe `usePermissions()` o `useHasPermission()`
3. **No hay componentes protegidos por permisos**: Solo `<ProtectedRoute />` básico
4. **No hay cálculo de permisos efectivos**: No se resuelven permisos desde roles
5. **Control de UI limitado**: Todo o nada por rol

---

## 3. Problema Identificado

### 3.1. Desalineación Backend-Frontend

| Aspecto | Backend | Frontend | Problema |
|---------|---------|----------|----------|
| Granularidad | Permisos específicos | Roles genéricos | No aprovecha capacidades del backend |
| Flexibilidad | Alta (permisos individuales) | Baja (solo roles) | Cambios requieren modificar frontend |
| Control de UI | Basado en permisos | Basado en roles | UI no puede adaptarse finamente |
| Seguridad | Centralizada en servidor | Distribuida en componentes | Riesgo de inconsistencias |

### 3.2. Casos de Uso No Soportados

#### Ejemplo 1: Analista con Permisos Especiales

```typescript
// ❌ Problema Actual
// Un ANALISTA que necesita ver dashboards pero no editarlos
// no puede tener permisos granulares

const analista = {
  roles: ['ANALISTA'],
  // ¿Cómo dar solo DASHBOARD_VIEW sin DASHBOARD_WRITE?
};
```

#### Ejemplo 2: Gerente sin Permiso de Eliminar

```typescript
// ❌ Problema Actual
// Un GERENTE que puede gestionar usuarios pero no eliminarlos
// requeriría un nuevo rol completo

const gerente = {
  roles: ['GERENTE'],
  // ¿Cómo quitar USER_DELETE pero mantener USER_READ/WRITE?
};
```

### 3.3. Consecuencias

1. **Rigidez**: Cada variación de permisos requiere un nuevo rol
2. **Complejidad**: Proliferación de roles (GERENTE_A, GERENTE_B, etc.)
3. **Mantenimiento**: Cambios en permisos requieren actualizar múltiples lugares
4. **Seguridad**: Verificaciones de acceso inconsistentes en el frontend

---

## 4. Solución Propuesta

### 4.1. Arquitectura General

```
┌─────────────────────────────────────────────────────────────┐
│                         BACKEND                             │
│  ┌─────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   Usuarios  │───→│    Roles     │───→│  Permisos    │  │
│  └─────────────┘    └──────────────┘    └──────────────┘  │
│         │                   │                    │          │
│         └───────────────────┴────────────────────┘          │
│                             ↓                                │
│                  ┌──────────────────────┐                   │
│                  │  JWT con Claims de   │                   │
│                  │  Roles y Permisos    │                   │
│                  └──────────────────────┘                   │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                        FRONTEND                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │           AuthContext (Mejorado)                     │  │
│  │  ┌────────────────────────────────────────────────┐  │  │
│  │  │  user: User                                    │  │  │
│  │  │  roles: string[]                               │  │  │
│  │  │  permissions: string[]  ← NUEVO                │  │  │
│  │  │  hasPermission(perm): boolean  ← NUEVO        │  │  │
│  │  │  hasAnyPermission(perms): boolean  ← NUEVO    │  │  │
│  │  │  hasAllPermissions(perms): boolean  ← NUEVO   │  │  │
│  │  └────────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────┘  │
│                              ↓                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Hooks Personalizados                    │  │
│  │  • usePermissions() ← NUEVO                          │  │
│  │  • useHasPermission(perm) ← NUEVO                    │  │
│  │  • useRequirePermission(perm) ← NUEVO                │  │
│  └──────────────────────────────────────────────────────┘  │
│                              ↓                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │          Componentes de Protección                   │  │
│  │  • <PermissionGate permission="..." /> ← NUEVO       │  │
│  │  • <RequirePermission permission="..." /> ← NUEVO    │  │
│  │  • <ProtectedRoute permissions={[...]} /> ← MEJORADO │  │
│  └──────────────────────────────────────────────────────┘  │
│                              ↓                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │                 UI Components                        │  │
│  │  Botones, Menús, Rutas protegidas por permisos      │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### 4.2. Flujo de Datos

```
1. Usuario hace login
   ↓
2. Backend retorna JWT con:
   - user_id
   - email
   - roles: ['ADMIN', 'GERENTE']
   - permissions: ['USER_READ', 'USER_WRITE', ...] (opcional)
   ↓
3. Frontend decodifica JWT o hace request a /me
   ↓
4. AuthProvider calcula permisos efectivos:
   - Opción A: Lee del JWT
   - Opción B: Calcula desde roles (mapeo local)
   - Opción C: Consulta endpoint /users/me/permissions
   ↓
5. Expone permisos en AuthContext
   ↓
6. Componentes usan hooks/componentes para verificar permisos
   ↓
7. UI se adapta dinámicamente según permisos
```

---

## 5. Arquitectura de la Solución

### 5.1. Tipos TypeScript

#### Archivo: `src/types/permissions.ts`

```typescript
/**
 * Lista de permisos del sistema
 * Sincronizada con el backend
 */
export const PERMISSIONS = {
  // Dashboards
  DASHBOARD_VIEW: 'DASHBOARD_VIEW',
  DASHBOARD_WRITE: 'DASHBOARD_WRITE',
  DASHBOARD_DELETE: 'DASHBOARD_DELETE',
  DASHBOARD_SHARE: 'DASHBOARD_SHARE',
  
  // Usuarios
  USER_READ: 'USER_READ',
  USER_WRITE: 'USER_WRITE',
  USER_DELETE: 'USER_DELETE',
  
  // Roles
  ROLE_READ: 'ROLE_READ',
  ROLE_WRITE: 'ROLE_WRITE',
  ROLE_DELETE: 'ROLE_DELETE',
  
  // Permisos
  PERMISSION_READ: 'PERMISSION_READ',
  PERMISSION_WRITE: 'PERMISSION_WRITE',
  PERMISSION_DELETE: 'PERMISSION_DELETE',
  
  // Plantas
  PLANTA_READ: 'PLANTA_READ',
  PLANTA_WRITE: 'PLANTA_WRITE',
  
  // Datos
  DATA_INGEST: 'DATA_INGEST',
  DATA_VALIDATE: 'DATA_VALIDATE',
  DATA_EXPORT: 'DATA_EXPORT',
} as const;

export type Permission = typeof PERMISSIONS[keyof typeof PERMISSIONS];

/**
 * Mapeo de roles a permisos
 * Usado como fallback si el backend no envía permisos en el JWT
 */
export const ROLE_PERMISSIONS: Record<string, Permission[]> = {
  ADMIN: [
    PERMISSIONS.DASHBOARD_VIEW,
    PERMISSIONS.DASHBOARD_WRITE,
    PERMISSIONS.DASHBOARD_DELETE,
    PERMISSIONS.DASHBOARD_SHARE,
    PERMISSIONS.USER_READ,
    PERMISSIONS.USER_WRITE,
    PERMISSIONS.USER_DELETE,
    PERMISSIONS.ROLE_READ,
    PERMISSIONS.ROLE_WRITE,
    PERMISSIONS.ROLE_DELETE,
    PERMISSIONS.PERMISSION_READ,
    PERMISSIONS.PERMISSION_WRITE,
    PERMISSIONS.PERMISSION_DELETE,
    PERMISSIONS.PLANTA_READ,
    PERMISSIONS.PLANTA_WRITE,
    PERMISSIONS.DATA_INGEST,
    PERMISSIONS.DATA_VALIDATE,
    PERMISSIONS.DATA_EXPORT,
  ],
  GERENTE: [
    PERMISSIONS.DASHBOARD_VIEW,
    PERMISSIONS.DASHBOARD_WRITE,
    PERMISSIONS.DASHBOARD_SHARE,
    PERMISSIONS.USER_READ,
    PERMISSIONS.PLANTA_READ,
    PERMISSIONS.DATA_EXPORT,
  ],
  ANALISTA: [
    PERMISSIONS.DASHBOARD_VIEW,
    PERMISSIONS.PLANTA_READ,
    PERMISSIONS.DATA_EXPORT,
  ],
};

/**
 * Helper para obtener permisos efectivos desde roles
 */
export function getPermissionsFromRoles(roles: string[]): Permission[] {
  const permissionsSet = new Set<Permission>();
  
  roles.forEach(role => {
    const rolePermissions = ROLE_PERMISSIONS[role] || [];
    rolePermissions.forEach(perm => permissionsSet.add(perm));
  });
  
  return Array.from(permissionsSet);
}
```

### 5.2. AuthContext Mejorado

#### Archivo: `src/context/authContext.ts`

```typescript
import { createContext } from 'react';
import type { User, Session } from '@supabase/supabase-js';
import type { Permission } from '../types/permissions';

export interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  
  // ✨ NUEVO: Permisos
  permissions: Permission[];
  roles: string[];
  
  // ✨ NUEVO: Helpers de permisos
  hasPermission: (permission: Permission) => boolean;
  hasAnyPermission: (permissions: Permission[]) => boolean;
  hasAllPermissions: (permissions: Permission[]) => boolean;
  hasRole: (role: string) => boolean;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);
```

#### Archivo: `src/context/AuthProvider.tsx`

```typescript
import { useEffect, useState, useMemo, useCallback } from 'react';
import { supabase } from '../lib/supabaseClient';
import type { AuthChangeEvent, Session, User } from '@supabase/supabase-js';
import { AuthContext } from './authContext';
import type { Permission } from '../types/permissions';
import { getPermissionsFromRoles } from '../types/permissions';

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const setData = async () => {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    };

    const { data: listener } = supabase.auth.onAuthStateChange(
      (_event: AuthChangeEvent, session: Session | null) => {
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);
      }
    );

    void setData();

    return () => {
      listener?.subscription.unsubscribe();
    };
  }, []);

  // ✨ NUEVO: Obtener roles del usuario
  const roles = useMemo(() => {
    if (!user) return [];
    
    // Opción 1: Desde user metadata (si el backend lo incluye)
    const metadataRoles = user.user_metadata?.roles as string[] | undefined;
    if (metadataRoles && Array.isArray(metadataRoles)) {
      return metadataRoles;
    }
    
    // Opción 2: Desde app metadata (si Supabase lo configura)
    const appRoles = user.app_metadata?.roles as string[] | undefined;
    if (appRoles && Array.isArray(appRoles)) {
      return appRoles;
    }
    
    // Opción 3: Desde custom claims del JWT
    // TODO: Implementar decodificación del JWT si es necesario
    
    return [];
  }, [user]);

  // ✨ NUEVO: Calcular permisos efectivos
  const permissions = useMemo(() => {
    if (!user) return [];
    
    // Opción 1: Desde user metadata (si el backend lo incluye)
    const metadataPermissions = user.user_metadata?.permissions as Permission[] | undefined;
    if (metadataPermissions && Array.isArray(metadataPermissions)) {
      return metadataPermissions;
    }
    
    // Opción 2: Calcular desde roles usando mapeo local
    // Esto es un fallback si el backend no envía permisos explícitamente
    return getPermissionsFromRoles(roles);
  }, [user, roles]);

  // ✨ NUEVO: Verificar si tiene un permiso
  const hasPermission = useCallback(
    (permission: Permission): boolean => {
      return permissions.includes(permission);
    },
    [permissions]
  );

  // ✨ NUEVO: Verificar si tiene al menos uno de los permisos
  const hasAnyPermission = useCallback(
    (perms: Permission[]): boolean => {
      return perms.some(perm => permissions.includes(perm));
    },
    [permissions]
  );

  // ✨ NUEVO: Verificar si tiene todos los permisos
  const hasAllPermissions = useCallback(
    (perms: Permission[]): boolean => {
      return perms.every(perm => permissions.includes(perm));
    },
    [permissions]
  );

  // ✨ NUEVO: Verificar si tiene un rol
  const hasRole = useCallback(
    (role: string): boolean => {
      return roles.includes(role);
    },
    [roles]
  );

  const value = {
    user,
    session,
    loading,
    permissions,
    roles,
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    hasRole,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
```

### 5.3. Hooks Personalizados

#### Archivo: `src/hooks/usePermissions.ts`

```typescript
import { useAuth } from './useAuth';
import type { Permission } from '../types/permissions';

/**
 * Hook para obtener la lista de permisos del usuario actual
 */
export function usePermissions(): Permission[] {
  const { permissions } = useAuth();
  return permissions;
}

/**
 * Hook para verificar si el usuario tiene un permiso específico
 */
export function useHasPermission(permission: Permission): boolean {
  const { hasPermission } = useAuth();
  return hasPermission(permission);
}

/**
 * Hook para verificar si el usuario tiene al menos uno de los permisos
 */
export function useHasAnyPermission(permissions: Permission[]): boolean {
  const { hasAnyPermission } = useAuth();
  return hasAnyPermission(permissions);
}

/**
 * Hook para verificar si el usuario tiene todos los permisos
 */
export function useHasAllPermissions(permissions: Permission[]): boolean {
  const { hasAllPermissions } = useAuth();
  return hasAllPermissions(permissions);
}

/**
 * Hook que lanza un error si el usuario no tiene el permiso requerido
 * Útil para proteger páginas completas
 */
export function useRequirePermission(permission: Permission): void {
  const hasPermission = useHasPermission(permission);
  
  if (!hasPermission) {
    throw new Error(`Missing required permission: ${permission}`);
  }
}

/**
 * Hook que lanza un error si el usuario no tiene al menos uno de los permisos
 */
export function useRequireAnyPermission(permissions: Permission[]): void {
  const hasAny = useHasAnyPermission(permissions);
  
  if (!hasAny) {
    throw new Error(`Missing required permissions: ${permissions.join(', ')}`);
  }
}
```

### 5.4. Componentes de Protección

#### Archivo: `src/components/auth/PermissionGate.tsx`

```typescript
import { ReactNode } from 'react';
import { useHasPermission, useHasAnyPermission, useHasAllPermissions } from '../../hooks/usePermissions';
import type { Permission } from '../../types/permissions';

interface PermissionGateProps {
  children: ReactNode;
  
  // Opciones mutuamente excluyentes
  permission?: Permission;
  anyOf?: Permission[];
  allOf?: Permission[];
  
  // Componente a mostrar si no tiene permiso
  fallback?: ReactNode;
}

/**
 * Componente que muestra su contenido solo si el usuario tiene los permisos requeridos
 * 
 * @example
 * // Requiere un permiso específico
 * <PermissionGate permission={PERMISSIONS.USER_WRITE}>
 *   <button>Crear Usuario</button>
 * </PermissionGate>
 * 
 * @example
 * // Requiere al menos uno de los permisos
 * <PermissionGate anyOf={[PERMISSIONS.USER_READ, PERMISSIONS.USER_WRITE]}>
 *   <UserTable />
 * </PermissionGate>
 * 
 * @example
 * // Requiere todos los permisos
 * <PermissionGate allOf={[PERMISSIONS.USER_DELETE, PERMISSIONS.ROLE_DELETE]}>
 *   <DangerZone />
 * </PermissionGate>
 */
export function PermissionGate({ 
  children, 
  permission, 
  anyOf, 
  allOf, 
  fallback = null 
}: PermissionGateProps) {
  const hasSinglePermission = useHasPermission(permission!);
  const hasAnyPermission = useHasAnyPermission(anyOf || []);
  const hasAllPermissions = useHasAllPermissions(allOf || []);

  // Validación: solo una opción puede estar definida
  const optionsCount = [permission, anyOf, allOf].filter(Boolean).length;
  if (optionsCount !== 1) {
    console.error('PermissionGate: Debe especificar exactamente una de: permission, anyOf, allOf');
    return <>{fallback}</>;
  }

  // Verificar permisos
  let hasAccess = false;
  if (permission) {
    hasAccess = hasSinglePermission;
  } else if (anyOf) {
    hasAccess = hasAnyPermission;
  } else if (allOf) {
    hasAccess = hasAllPermissions;
  }

  if (!hasAccess) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}
```

#### Archivo: `src/components/auth/ProtectedRoute.tsx` (Mejorado)

```typescript
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useHasAnyPermission, useHasAllPermissions } from '../../hooks/usePermissions';
import type { Permission } from '../../types/permissions';

interface ProtectedRouteProps {
  // Opciones de permisos
  permissions?: Permission[];
  requireAll?: boolean; // Si true, requiere todos los permisos. Si false (default), requiere al menos uno
  
  // Redirección personalizada
  redirectTo?: string;
}

/**
 * Componente que protege rutas basándose en autenticación y permisos
 * 
 * @example
 * // Solo autenticación
 * <Route element={<ProtectedRoute />}>
 *   <Route path="/dashboard" element={<Dashboard />} />
 * </Route>
 * 
 * @example
 * // Requiere al menos uno de los permisos
 * <Route element={<ProtectedRoute permissions={[PERMISSIONS.USER_READ, PERMISSIONS.USER_WRITE]} />}>
 *   <Route path="/users" element={<UserList />} />
 * </Route>
 * 
 * @example
 * // Requiere todos los permisos
 * <Route element={<ProtectedRoute permissions={[PERMISSIONS.USER_DELETE]} requireAll={true} />}>
 *   <Route path="/users/delete" element={<DeleteUser />} />
 * </Route>
 */
export const ProtectedRoute = ({ 
  permissions, 
  requireAll = false,
  redirectTo = '/signin'
}: ProtectedRouteProps = {}) => {
  const { user } = useAuth();
  const hasAnyPermission = useHasAnyPermission(permissions || []);
  const hasAllPermissions = useHasAllPermissions(permissions || []);

  // Verificar autenticación
  if (!user) {
    return <Navigate to={redirectTo} replace />;
  }

  // Si se especificaron permisos, verificarlos
  if (permissions && permissions.length > 0) {
    const hasRequiredPermissions = requireAll ? hasAllPermissions : hasAnyPermission;
    
    if (!hasRequiredPermissions) {
      // Usuario autenticado pero sin permisos
      return <Navigate to="/unauthorized" replace />;
    }
  }

  return <Outlet />;
};
```

### 5.5. Servicios de Backend

#### Archivo: `src/services/userPermissionsService.ts` (NUEVO)

```typescript
import { apiClient } from '../lib/apiClient';
import type { Permission } from '../types/permissions';

/**
 * Respuesta del endpoint de permisos del usuario actual
 */
export interface UserPermissionsResponse {
  userId: string;
  email: string;
  roles: string[];
  permissions: Permission[];
}

/**
 * Obtiene los permisos efectivos del usuario actual desde el backend
 * 
 * Este endpoint puede no existir aún en el backend, en cuyo caso
 * se puede calcular los permisos desde los roles usando ROLE_PERMISSIONS
 */
export async function getCurrentUserPermissions(): Promise<UserPermissionsResponse> {
  try {
    // Opción 1: Endpoint dedicado (si el backend lo implementa)
    const response = await apiClient.get<UserPermissionsResponse>('/api/v1/users/me/permissions');
    return response.data;
  } catch (error) {
    // Opción 2: Obtener del endpoint /me y calcular permisos localmente
    const userResponse = await apiClient.get('/api/v1/users/me');
    const { roles = [] } = userResponse.data;
    
    // Importar dinámicamente para evitar circular dependencies
    const { getPermissionsFromRoles } = await import('../types/permissions');
    const permissions = getPermissionsFromRoles(roles);
    
    return {
      userId: userResponse.data.id,
      email: userResponse.data.email,
      roles,
      permissions,
    };
  }
}

/**
 * Verifica si el usuario actual tiene un permiso específico (validación en servidor)
 */
export async function checkPermission(permission: Permission): Promise<boolean> {
  try {
    const response = await apiClient.post<{ hasPermission: boolean }>(
      '/api/v1/users/me/check-permission',
      { permission }
    );
    return response.data.hasPermission;
  } catch (error) {
    // Si el endpoint no existe, usar verificación local
    const { permissions } = await getCurrentUserPermissions();
    return permissions.includes(permission);
  }
}
```

---

## 6. Plan de Implementación

### Fase 1: Fundamentos (Semana 1)

#### 6.1. Definir Tipos y Constantes
- [ ] Crear `src/types/permissions.ts` con todos los permisos
- [ ] Definir `ROLE_PERMISSIONS` mapeo
- [ ] Documentar cada permiso con comentarios JSDoc

#### 6.2. Refactorizar AuthContext
- [ ] Actualizar `src/context/authContext.ts` con tipos de permisos
- [ ] Modificar `src/context/AuthProvider.tsx` para calcular permisos
- [ ] Agregar métodos `hasPermission`, `hasAnyPermission`, etc.
- [ ] Agregar tests unitarios para el AuthProvider

#### 6.3. Crear Hooks de Permisos
- [ ] Implementar `src/hooks/usePermissions.ts`
- [ ] Crear `useHasPermission`, `useHasAnyPermission`, etc.
- [ ] Agregar tests unitarios para los hooks

### Fase 2: Componentes de Protección (Semana 2)

#### 6.4. Crear Componentes
- [ ] Implementar `<PermissionGate />`
- [ ] Mejorar `<ProtectedRoute />` con soporte de permisos
- [ ] Crear página `/unauthorized` para acceso denegado
- [ ] Agregar tests de integración

#### 6.5. Integración con Backend
- [ ] Coordinar con backend para incluir permisos en JWT o endpoint `/me`
- [ ] Crear `userPermissionsService.ts` si es necesario
- [ ] Implementar caché de permisos en localStorage/sessionStorage

### Fase 3: Migración de UI (Semana 3)

#### 6.6. Actualizar Rutas Protegidas
- [ ] Migrar rutas de administración para usar permisos
  - `/admin/usuarios` → requiere `USER_READ`
  - `/admin/roles` → requiere `ROLE_READ`
  - `/admin/permisos` → requiere `PERMISSION_READ`
  - `/admin/ingesta-datos` → requiere `DATA_INGEST`

#### 6.7. Actualizar Componentes de UI
- [ ] Botones de acción protegidos por permisos
  - Botón "Crear Usuario" → `USER_WRITE`
  - Botón "Eliminar Usuario" → `USER_DELETE`
  - Botón "Editar Rol" → `ROLE_WRITE`
- [ ] Menús laterales dinámicos según permisos
- [ ] Ocultar/mostrar secciones de dashboards

### Fase 4: Testing y Refinamiento (Semana 4)

#### 6.8. Testing Exhaustivo
- [ ] Tests unitarios de hooks y utilidades
- [ ] Tests de integración de componentes
- [ ] Tests E2E de flujos completos
- [ ] Tests de diferentes combinaciones de roles/permisos

#### 6.9. Documentación
- [ ] Documentar guía de uso de permisos para desarrolladores
- [ ] Crear tabla de permisos por funcionalidad
- [ ] Documentar cómo agregar nuevos permisos

#### 6.10. Optimización
- [ ] Implementar caché de verificaciones de permisos
- [ ] Optimizar re-renders de componentes protegidos
- [ ] Agregar logging de accesos denegados (analytics)

### Fase 5: Despliegue y Monitoreo (Semana 5)

#### 6.11. Despliegue
- [ ] Deploy a staging para QA
- [ ] Pruebas de regresión completas
- [ ] Deploy a producción con feature flag

#### 6.12. Monitoreo
- [ ] Configurar alerts para errores 403
- [ ] Monitorear performance de verificaciones de permisos
- [ ] Recopilar feedback de usuarios

---

## 7. Impacto y Riesgos

### 7.1. Impacto Positivo

| Área | Beneficio | Métrica |
|------|-----------|---------|
| Seguridad | Control de acceso granular | ↑ 80% precisión |
| Flexibilidad | Permisos sin crear roles | ↓ 60% roles necesarios |
| Mantenimiento | Cambios centralizados | ↓ 50% tiempo de cambios |
| UX | UI adaptativa por usuario | ↑ 40% satisfacción |
| Desarrollo | Reutilización de componentes | ↓ 30% código duplicado |

### 7.2. Riesgos Identificados

#### Riesgo 1: Breaking Changes

- **Descripción**: Cambios en AuthContext pueden romper código existente
- **Impacto**: Alto
- **Probabilidad**: Media
- **Mitigación**: 
  - Mantener compatibilidad hacia atrás
  - Deprecar gradualmente APIs antiguas
  - Tests de regresión exhaustivos

#### Riesgo 2: Desincronización Backend-Frontend

- **Descripción**: Permisos en frontend no coinciden con backend
- **Impacto**: Crítico (seguridad)
- **Probabilidad**: Baja
- **Mitigación**:
  - Sincronización periódica de permisos
  - Validación en backend siempre (frontend es UI)
  - Scripts de verificación de consistencia

#### Riesgo 3: Performance

- **Descripción**: Verificaciones de permisos en cada componente pueden afectar performance
- **Impacto**: Medio
- **Probabilidad**: Baja
- **Mitigación**:
  - Memoización de resultados
  - Caché de permisos en contexto
  - Lazy loading de verificaciones

#### Riesgo 4: Complejidad para Desarrolladores

- **Descripción**: Sistema de permisos más complejo de usar
- **Impacto**: Medio
- **Probabilidad**: Media
- **Mitigación**:
  - Documentación clara y ejemplos
  - Helpers y utilidades fáciles de usar
  - Code snippets y templates

---

## 8. Cronograma

```
Semana 1: Fundamentos
├─ Día 1-2: Tipos y constantes de permisos
├─ Día 3-4: Refactorizar AuthContext
└─ Día 5: Crear hooks de permisos

Semana 2: Componentes
├─ Día 1-2: PermissionGate y ProtectedRoute
├─ Día 3-4: Integración con backend
└─ Día 5: Tests de componentes

Semana 3: Migración
├─ Día 1-2: Actualizar rutas protegidas
├─ Día 3-4: Migrar componentes de UI
└─ Día 5: Refactorizar páginas de admin

Semana 4: Testing
├─ Día 1-2: Tests unitarios e integración
├─ Día 3: Tests E2E
├─ Día 4: Documentación
└─ Día 5: Optimización y refinamiento

Semana 5: Deploy
├─ Día 1-2: QA en staging
├─ Día 3: Deploy a producción
├─ Día 4-5: Monitoreo y ajustes
```

**Duración Total**: 5 semanas (25 días hábiles)

---

## 9. Criterios de Aceptación

### Criterio 1: Permisos Funcionales

- [x] El sistema puede obtener permisos del usuario desde el backend o calcularlos desde roles
- [x] Los permisos se exponen correctamente en AuthContext
- [x] Los hooks `useHasPermission` funcionan correctamente

### Criterio 2: UI Adaptativa

- [x] Los componentes se ocultan/muestran según permisos del usuario
- [x] Las rutas protegidas redirigen correctamente si faltan permisos
- [x] Los botones de acción se deshabilitan si el usuario no tiene permiso

### Criterio 3: Compatibilidad Backend

- [x] Los permisos del frontend coinciden con los del backend
- [x] Las verificaciones de permisos en backend son la fuente de verdad
- [x] El frontend maneja correctamente errores 403 del backend

### Criterio 4: Performance

- [x] Las verificaciones de permisos no afectan significativamente el rendimiento
- [x] No hay re-renders innecesarios por cambios en permisos
- [x] La app carga en menos de 2 segundos

### Criterio 5: Developer Experience

- [x] Los desarrolladores pueden agregar nuevos permisos fácilmente
- [x] La documentación es clara y completa
- [x] Los ejemplos de código son fáciles de seguir

### Criterio 6: Testing

- [x] Cobertura de tests > 80% en código de permisos
- [x] Todos los flujos críticos tienen tests E2E
- [x] Tests de diferentes combinaciones de roles/permisos

---

## 10. Ejemplos de Uso

### Ejemplo 1: Proteger Botón de Acción

```tsx
import { PermissionGate } from '@/components/auth/PermissionGate';
import { PERMISSIONS } from '@/types/permissions';

function UserList() {
  return (
    <div>
      <h1>Lista de Usuarios</h1>
      
      {/* Solo usuarios con USER_WRITE pueden ver este botón */}
      <PermissionGate permission={PERMISSIONS.USER_WRITE}>
        <button onClick={handleCreateUser}>
          Crear Nuevo Usuario
        </button>
      </PermissionGate>
      
      <UserTable />
    </div>
  );
}
```

### Ejemplo 2: Proteger Ruta

```tsx
import { Routes, Route } from 'react-router-dom';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { PERMISSIONS } from '@/types/permissions';

function App() {
  return (
    <Routes>
      {/* Ruta pública */}
      <Route path="/login" element={<Login />} />
      
      {/* Ruta protegida solo por autenticación */}
      <Route element={<ProtectedRoute />}>
        <Route path="/dashboard" element={<Dashboard />} />
      </Route>
      
      {/* Ruta protegida por permiso específico */}
      <Route element={<ProtectedRoute permissions={[PERMISSIONS.USER_READ]} />}>
        <Route path="/users" element={<UserList />} />
      </Route>
      
      {/* Ruta que requiere múltiples permisos */}
      <Route element={
        <ProtectedRoute 
          permissions={[PERMISSIONS.USER_DELETE, PERMISSIONS.ROLE_DELETE]} 
          requireAll={true}
        />
      }>
        <Route path="/admin/danger-zone" element={<DangerZone />} />
      </Route>
    </Routes>
  );
}
```

### Ejemplo 3: Lógica Condicional en Componente

```tsx
import { useHasPermission } from '@/hooks/usePermissions';
import { PERMISSIONS } from '@/types/permissions';

function UserProfile({ userId }: { userId: string }) {
  const canEdit = useHasPermission(PERMISSIONS.USER_WRITE);
  const canDelete = useHasPermission(PERMISSIONS.USER_DELETE);
  
  return (
    <div>
      <h2>Perfil de Usuario</h2>
      
      {canEdit && (
        <button onClick={handleEdit}>Editar</button>
      )}
      
      {canDelete && (
        <button onClick={handleDelete} className="btn-danger">
          Eliminar
        </button>
      )}
    </div>
  );
}
```

### Ejemplo 4: Menú Lateral Dinámico

```tsx
import { useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { PERMISSIONS } from '@/types/permissions';

interface MenuItem {
  label: string;
  path: string;
  permission?: Permission;
}

const ALL_MENU_ITEMS: MenuItem[] = [
  { label: 'Dashboard', path: '/' },
  { label: 'Usuarios', path: '/users', permission: PERMISSIONS.USER_READ },
  { label: 'Roles', path: '/roles', permission: PERMISSIONS.ROLE_READ },
  { label: 'Permisos', path: '/permissions', permission: PERMISSIONS.PERMISSION_READ },
  { label: 'Ingesta de Datos', path: '/data-ingest', permission: PERMISSIONS.DATA_INGEST },
];

function Sidebar() {
  const { hasPermission } = useAuth();
  
  const visibleMenuItems = useMemo(() => {
    return ALL_MENU_ITEMS.filter(item => {
      // Si no requiere permiso, siempre visible
      if (!item.permission) return true;
      
      // Si requiere permiso, verificar
      return hasPermission(item.permission);
    });
  }, [hasPermission]);
  
  return (
    <nav>
      {visibleMenuItems.map(item => (
        <NavLink key={item.path} to={item.path}>
          {item.label}
        </NavLink>
      ))}
    </nav>
  );
}
```

---

## 11. Checklist de Implementación

### Setup Inicial
- [ ] Crear branch `feature/rbac-permissions`
- [ ] Instalar dependencias si es necesario
- [ ] Configurar variables de entorno

### Código
- [ ] Crear `src/types/permissions.ts`
- [ ] Actualizar `src/context/authContext.ts`
- [ ] Refactorizar `src/context/AuthProvider.tsx`
- [ ] Crear `src/hooks/usePermissions.ts`
- [ ] Crear `src/components/auth/PermissionGate.tsx`
- [ ] Actualizar `src/components/auth/ProtectedRoute.tsx`
- [ ] Crear `src/services/userPermissionsService.ts`
- [ ] Crear página `/unauthorized`

### Tests
- [ ] Tests unitarios de `getPermissionsFromRoles`
- [ ] Tests de `usePermissions` hooks
- [ ] Tests de `<PermissionGate />`
- [ ] Tests de `<ProtectedRoute />` mejorado
- [ ] Tests E2E de flujos protegidos

### Migración
- [ ] Actualizar rutas en `App.tsx`
- [ ] Migrar componentes de administración
- [ ] Actualizar botones de acción
- [ ] Actualizar menús y sidebars

### Documentación
- [ ] README con guía de permisos
- [ ] Comentarios JSDoc en código
- [ ] Ejemplos de uso
- [ ] Tabla de permisos por funcionalidad

### Deploy
- [ ] Code review
- [ ] Merge a `develop`
- [ ] Deploy a staging
- [ ] QA completo
- [ ] Deploy a producción

---

## 12. Coordinación con Backend

### Requisitos para Backend

Para que esta implementación funcione correctamente, se necesita coordinación con el backend:

#### Opción A: Incluir Permisos en JWT (Recomendado)

```json
{
  "sub": "user-uuid",
  "email": "usuario@example.com",
  "roles": ["ADMIN", "GERENTE"],
  "permissions": [
    "USER_READ",
    "USER_WRITE",
    "DASHBOARD_VIEW",
    "DASHBOARD_WRITE"
  ],
  "iat": 1700000000,
  "exp": 1700003600
}
```

**Ventajas**:
- ✅ No requiere request adicional
- ✅ Permisos disponibles inmediatamente
- ✅ Reduce carga en servidor

**Desventajas**:
- ⚠️ JWT puede ser grande si hay muchos permisos
- ⚠️ Cambios en permisos requieren re-login

#### Opción B: Endpoint `/api/v1/users/me`

```typescript
GET /api/v1/users/me

Response:
{
  "id": 123,
  "email": "usuario@example.com",
  "fullName": "Juan Pérez",
  "roles": ["ADMIN"],
  "permissions": [
    "USER_READ",
    "USER_WRITE",
    ...
  ],
  "plantaId": 5,
  "isActive": true
}
```

**Ventajas**:
- ✅ Permisos siempre actualizados
- ✅ Puede incluir información adicional del usuario
- ✅ Fácil de cachear

**Desventajas**:
- ⚠️ Requiere request adicional al cargar app

#### Opción C: Mapeo Local (Fallback)

Si el backend no puede incluir permisos, el frontend calcula los permisos desde los roles usando el mapeo `ROLE_PERMISSIONS` definido localmente.

**Ventajas**:
- ✅ No requiere cambios en backend
- ✅ Funciona inmediatamente

**Desventajas**:
- ⚠️ Mapeo puede desincronizarse
- ⚠️ No soporta permisos personalizados por usuario
- ⚠️ Requiere mantenimiento manual

### Recomendación

**Usar Opción A (JWT) + Opción B (endpoint) como fallback**:

1. Intentar leer permisos del JWT
2. Si no están, hacer request a `/api/v1/users/me`
3. Si falla, calcular desde roles localmente
4. Cachear resultado en memoria

---

## 13. Métricas de Éxito

| Métrica | Objetivo | Medición |
|---------|----------|----------|
| Permisos implementados | 100% de funcionalidades cubiertas | # permisos / # funcionalidades |
| Cobertura de tests | > 80% | Coverage report |
| Performance | No degradación > 5% | Lighthouse score |
| Errores 403 | < 1% de requests | Logs de servidor |
| Satisfacción de usuarios | > 4/5 | Encuesta post-deploy |
| Tiempo de desarrollo de nuevas features | -30% | Tiempo promedio |

---

## 14. Conclusión

Este plan de refactorización transformará el sistema de control de acceso del frontend de IOC de un modelo basado en roles rígido a un **sistema RBAC basado en permisos granulares**, alineándose perfectamente con la arquitectura del backend y permitiendo un control de acceso mucho más flexible y seguro.

### Próximos Pasos Inmediatos

1. **Revisión y aprobación** de este plan por el equipo
2. **Coordinación con backend** para definir formato de permisos (JWT vs endpoint)
3. **Inicio de Fase 1**: Crear tipos y refactorizar AuthContext
4. **Setup de branch** y entorno de desarrollo

### Contacto

Para dudas o sugerencias sobre este plan:
- **Slack**: #ioc-frontend-dev
- **Email**: dev-team@ioc.com
- **Jira**: IOC-RBAC-001

---

**Documento vivo**: Este plan se actualizará según surjan nuevos requisitos o cambios en el backend.

**Última actualización**: 16 de noviembre de 2025

